<?php
/*   
*   REXP - REGISTRO DE EXPERIMENTO
* 
*   MODULO: Iniciando conexao   
* 
*/
//  @require_once('inicia_conexao.php');  once = somente uma vez
//  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION) ) {
   session_start();
}
include('inicia_conexao.php');
//    MENU HORIZONTAL
include("includes/array_menu.php");
//
$_SESSION["m_horiz"] = $array_projeto;
//   Definindo a Raiz do Projeto
$_SESSION['pasta_raiz']='/rexp/';
//
//  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anota��o";
//
// $_SESSION['time_exec']=180000;
?>
<!DOCTYPE html >
<html lang="pt-br" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="language" content="pt-br" />
<meta name="author" content="SPFB&LAFB" />
<meta http-equiv="Cache-Control"  content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA"  content="NO-CACHE">
<meta name="ROBOTS"  content="NONE"> 
<!--  <meta HTTP-EQUIV="Expires" CONTENT="-1" >  -->
<!--  <meta HTTP-EQUIV="Expires" CONTENT="0" >  -->
<meta name="GOOGLEBOT" content="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no" />  
<title></title>
<!-- <script type="text/javascript"  language="javascript"   src="includes/domenu.php" ></script>   -->
<link  type="text/css"  href="css/estilo.css" rel="stylesheet"  />
<link  type="text/css"   href="css/style_titulo.css" rel="stylesheet"  />
<script  type="text/javascript" src="js/XHConn.js" ></script>
<script type="text/javascript"  src="js/functions.js" ></script>
<?php
$_SESSION['n_upload']="ativando";
// $_SESSION['http_host']= "http://sol.fmrp.usp.br".$_SESSION['pasta_raiz'];
//$_SESSION['http_host']= "http://sol.fmrp.usp.br".$_SESSION['pasta_raiz'];
$_SESSION['http_host']= $_SESSION['url_folder'];
//  Para mudar de pagina no MENU
require_once("includes/domenu.php");
//
?>
</head>
<body  id="logar_body" onload="javascript: dochange('Logar');"  oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"   onkeydown="javascript: no_backspace(event);"      >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho  -->
<div id="cabecalho" style="z-index:2;" >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<table width="100%" border="1" cellspacing="2" cellpadding="1" height="100%" style="vertical-align: middle;" >
    <tr>
     <td  class="titulo_usp" align="center"  style="width: 100%;  font-size: 40px;" >LOGANDO COMO:</td>
    </tr>
</table>
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape"   >
<?php include_once("includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
