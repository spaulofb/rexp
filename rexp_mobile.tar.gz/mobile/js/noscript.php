<?php
    //   Arquivo para verificar se o navegador esta habilitado para javascript - 20100720
?>
<noscript>
<div style="border: 2px groove #000000; margin: 2px; padding: 8px; text-align: center; width: 600px; ">
<p style="text-align: justify;" >Para completa funcionalidade deste <b>Site</b> � necess�rio habilitar o JavaScript.</p>
<p style="text-align: justify;" >Aqui est�o as <a href="http://www.enable-javascript.com/pt/" target="_blank">
 instru��es de como habilitar o JavaScript no seu navegador</a>.</p>
</div> 
</noscript>
