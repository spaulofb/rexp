-rw-r--r--.  1 soldbm dbm  3231 Jun  3 09:28 arquivo_do_gemac_downloads.php  // NAO ENCONTRADO SERA?
// NAO REMOVIDO 

-rw-r--r--.  1 soldbm dbm  9146 Jun  3 09:28 paginacao.php  // REMOVIDO

-rw-r--r--.  1 soldbm dbm   358 Jun  3 09:28 usuario_consultar_t1.php  // REMOVIDO
