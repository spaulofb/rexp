<?php
/*   
*   REXP - REGISTRO DE EXPERIMENTO
* 
*   MODULO: Iniciando conexao   
* 
*/
//  @require_once('inicia_conexao.php');  once = somente uma vez
//  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 
//
//
require_once('inicia_conexao.php');

//
$incluir_arq="";
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
    echo "Sess�o incluir_arq n�o est� ativa.";
    exit();
}
///
//    MENU HORIZONTAL
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
//
$_SESSION["m_horiz"] = $array_projeto;
//   Definindo a Raiz do Projeto
//  $_SESSION['pasta_raiz']='/rexp/';
$_SESSION["pasta_docs"]="doctos_img";
//
//  Titulo do Cabecalho - Topo
///  if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anota��o";
$_SESSION["titulo_cabecalho"]="Registro de Anota&ccedil;&atilde;o";
// $_SESSION['time_exec']=180000;
//
// Alterado em 20120912 - Voltar a function como dochange
$_SESSION["function"]="dochange";
//
//  $_SESSION[http_host]= "http://".$_SERVER["HTTP_HOST"]."/rexp/";
$_SESSION['http_host']= "http://".$_SERVER["HTTP_HOST"].$_SESSION['pasta_raiz'];
$_SESSION['raiz_central'] = $_SESSION["http_host"];
$http_host=$_SESSION['http_host'];
//
?>
<!DOCTYPE html>
<html lang="pt-BR" >
<head>
<meta charset="UTF-8" />
<meta name="author" content="SPFB&LAFB" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<meta NAME="ROBOTS" CONTENT="NONE"> 
<!--  <meta HTTP-EQUIV="Expires" CONTENT="-1" >  -->
<!--  <meta HTTP-EQUIV="Expires" CONTENT="0" >  -->
<meta NAME="GOOGLEBOT" CONTENT="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<title>Projeto</title>
<!-- <script type="text/javascript"  language="javascript"   src="includes/domenu.php" ></script>  -->
<!-- <script type="text/javascript"  language="javascript"   src="js/domenu.js" ></script> -->
<link  type="text/css"  href="<?php echo $http_host;?>css/estilo.css" rel="stylesheet"  />
<link  type="text/css"   href="<?php echo $http_host;?>css/style_titulo.css" rel="stylesheet"  />
<script  type="text/javascript" src="<?php echo $http_host;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $http_host;?>js/functions.js" ></script>
<script type="text/javascript"  src="<?php echo $http_host;?>js/cad_proj_expe.js" ></script>
<?php
$_SESSION['n_upload']="ativando";
//  Para mudar de pagina no MENU
require_once("{$_SESSION["incluir_arq"]}includes/domenu.php");
//
?>
</head>
<body  id="id_body"  oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"   onkeydown="javascript: no_backspace(event);"      >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho  -->
<div id="cabecalho" style="z-index:2;" >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<img src="imagens/anotando1.gif" />    
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape" >
<?php include("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
