#!/usr/bin/perl
   
print  "�Hello, World\n!"�;

# imprime Hello, World!
    