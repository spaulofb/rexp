<?php 
/*   REXP - CONSULTAR ANOTA??O DE PROJETO
*   
*   REQUISITO: O usu?rio deve ter PA>0 e PA<=50 
* 
*   LAFB&SPFB110908.1629
*/
//  ==============================================================================================
//  ATEN??O: SENDO EDITADO POR SPFB/20170920 --  incluces/anotacao_nova.php
//  ==============================================================================================
//
// Dica: #*funciona?*# Se o que quer ? apenas for?ar uma visualiza??o direta no navegador use
// header("Content-Disposition: inline; filename=\"nome_arquivo.pdf\";"); 
///
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 

///  HOST mais a pasta principal do site
$host_pasta="";
if( isset($_SESSION["host_pasta"]) ) $host_pasta=$_SESSION["host_pasta"];

///
$incluir_arq="";
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
    echo "Sessão incluir_arq não está ativa.";
    exit();
}
///
include("{$_SESSION["incluir_arq"]}inicia_conexao.php");
////
///    MENU HORIZONTAL
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) {
   $array_pa = $_SESSION["array_pa"];       
   $permit_anotador = $array_pa['anotador'];
   $permit_orientador = $array_pa['orientador'];
}
///
$_SESSION["m_horiz"] = $array_projeto;

$usuario_conectado = $_SESSION["usuario_conectado"];
if( isset($_SESSION["permit_pa"]) ) $permit_pa = $_SESSION["permit_pa"];
///
//   Caminho da pagina local
$pagina_local =  "http://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];

///  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anotação";
// $_SESSION['time_exec']=180000;
//
//  INCLUINDO CLASS - 
require_once("{$_SESSION["incluir_arq"]}includes/autoload_class.php");  
$funcoes=new funcoes();
$funcoes->usuario_pa_nome();
$_SESSION["usuario_pa_nome"]=$funcoes->usuario_pa_nome;
////
$_SESSION["m_titulo"]="Anotações";
$_SESSION["anotacao_numero"]=0;
///
//  Variavel verificar  ERROS
$php_errormsg='';
/*** 
     Alterado em  20171020
***/
////  $_SESSION["url_central"] = "http://".$_SESSION["http_host"].$_SESSION["pasta_raiz"];
/////  $_SESSION["url_central"] = $_SESSION["http_host"];
///  Verificando caminho http e pasta principal
if( isset($_SESSION["url_central"]) ) {
     $http_host = @trim($_SESSION["url_central"]);     
} else {
    echo "<p style='background-color: #000000;color:#FFFFFF;font-size:large;'> ERRO: grave falha na session url_central. Contato com Administrador.</p>";
    exit();
}
///
if( ! empty($php_errormsg) ) {
    $http_host="../";
}
///
////
?>
<!DOCTYPE html>
<html lang="pt-BR" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="language" content="pt-br" />
<meta name="author" content="LAFB/SPFB" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta name="ROBOTS" content="NONE"> 
<meta http-equiv="Expires" content="-1" >
<meta name="GOOGLEBOT" content="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<title>Projeto</title>
<link  type="text/css"  href="<?php echo $host_pasta;?>css/estilo.css" rel="stylesheet"  />
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/functions.js"  charset="utf-8" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/responsiveslides.min.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/resize.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/verifica_mobile.js" ></script>
<script  language="javascript"  type="text/javascript" >
///
charset="utf-8";
///
// /  Javascript - 20171020
/****  
   Definindo as  variaveis globais  -  20171020

        Define o caminho HTTP
***/  
var raiz_central="<?php echo  $_SESSION["url_central"];?>";       
///
///
function consulta_mostraanot(idselecproj, idopcao,string_array){
    //
    ///  Selecionar as ANOTA??ES DE PROJETOS de acordo com a op??o (todos ou pelo campo desejado)
    //
    //  LAFB/SPFB110831.1127
    //  LAFB/SPFB110909.0917
    //
    //  Parametros:
    //      idselecproj = Identifica??o do Select de escolha do projeto
    //      idopcao     = Identifica??o da Op??o de sele??o das Anota??es (TODOS, select (ano_incio, ano_final, anota??o)
    //
    //  Prepara os par?metros para ativa??o do srv_php
    /// Determina qual opcao do Select <idselecproj> foi selecionada:
        /// Verificando se a function exoc existe
    if(typeof exoc=="function" ) {
        ///  Ocultando ID  e utilizando na tag input comando onkeypress
         exoc("label_msg_erro",0);  
    } else {
        alert("funcion exoc nao existe. Corrigir");
        return
    }
     ///    

////   alert(" anotacao_consultar.php/69 -  idselecproj = "+idselecproj+" --  idopcao  =  "+idopcao+" - string_array = "+string_array)  

    var ultimos_cpos = idselecproj.search(/Alterar|Excluir/i);
    
    if( ultimos_cpos!=-1  ) {
        if( idselecproj.toUpperCase()=="ALTERAR" ) {
             ///  alert("anotacao_nova.php/85 ALTERAR -  idselecproj = "+idselecproj)  
             ///  top.location.href="../alterar/anotacao_alterar_nova.php";
             top.location.href=raiz_central+"alterar/anotacao_alterar_nova.php";
        } else if( idselecproj.toUpperCase()=="EXCLUIR" ) {
             //// alert("anotacao_nova.php/85  EXCLUIR -  idselecproj = "+idselecproj+" -- idopcao = "+idopcao+" --  string_array = "+string_array) 
             top.location.href=raiz_central+"remover/anotacao_remover_nova.php";           
        }    
        return;
    }
    /// 
    /// Verifica se a variavel e uma string
    if( typeof(idselecproj)=='string' ) {
        /***  string.replace - Melhor forma para eliminiar 
              espa?os no comeco e final da String/Variavel
        ***/    
        idselecproj = idselecproj.replace(/^\s+|\s+$/g,""); 
    }
    //  Recebido da pagina includes/tabela_consulta_anotacao_nova.php 
    if( idselecproj.toUpperCase()=="NOVA" ) {
           ///  alert("anotacao_nova.php/89  - IF NOVA  -  idopcao = "+idopcao)
           top.location.href=raiz_central+"cadastrar/anotacao_cadastrar_nova.php?cad_dados_anotacao('anotacao','projeto')";
           return;        
    }
    ///
    if( idselecproj.toUpperCase()!="DESCARREGAR" &&  idselecproj.toUpperCase()!="DETALHES" ) {
        if( typeof(idopcao)=='undefined' ) var op_selanot="";
        if( typeof(idopcao)!='undefined' ) var op_selanot=idopcao.toUpperCase();
           if( op_selanot=="TODOS" ) {
                var op_selcpoid = "";
                var op_selcpoval = "";
                var doc_elemto = document.getElementById(idselecproj);    
                var op_selecionada = doc_elemto.options[doc_elemto.options.selectedIndex];
                var op_projcod = op_selecionada.value;
                var op_projdesc = op_selecionada.text;
           } else {
                var doc_elemto = document.getElementById(idopcao);    
                var op_selecionada = doc_elemto.options[doc_elemto.options.selectedIndex];
                var op_selcpoid = op_selecionada.text;
                var op_selcpoval = op_selecionada.value;
           }
           ///        
    }    
    ////  Verificando o campo da tag Select para escolher Projeto
    if( document.getElementById("busca_proj") ) {
        var cpo_val = document.getElementById("busca_proj").value;
        if( cpo_val=="" ) {
             ///  ERRO
             var m_id_title="Selecione primeiro o Projeto";
             document.getElementById("label_msg_erro").style.display="block";
             document.getElementById("label_msg_erro").innerHTML="";
             var msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
             msg_erro += "<span style='color: #FF0000;'>ERRO:&nbsp;";
             var final_msg_erro = "&nbsp;</span></span>";
             var m_tit_cpo = "<span style='color: #000000;'>&nbsp;&nbsp;"+m_id_title+"</span>";
             msg_erro = msg_erro+'&nbsp;Corrigir campo.'+m_tit_cpo+final_msg_erro;
             document.getElementById("label_msg_erro").innerHTML=msg_erro;    
             return false;
        } else {
             document.getElementById("label_msg_erro").innerHTML="";
             document.getElementById("label_msg_erro").style.display="none";    
        }
        ///
    }
          
    /*   Iniciando o AJAX para selecionar os usuarios desejados  */
    var xAJAX_mostraanot = new XHConn();
    if ( !xAJAX_mostraanot ) {
          alert("XMLHTTP/AJAX n?o dispon?vel. Tente um navegador mais novo ou melhor.");
          return false;
    }
    //
    // Define o procedimento para processamento dos resultados dp srv_php
    var fndone_mostraanot = function (oXML) { 
          ///  Recebendo o resultado do php/ajax
          if( document.getElementById("nova_anotacao") ) {
                document.getElementById("nova_anotacao").style.display="none";
          } 
          var srv_ret = oXML.responseText;
          var lnip = srv_ret.search(/Nenhum|ERRO:/i);
          
 //  alert(" anotacao_nova.php/125 - idselecproj = "+idselecproj+" - lnip = "+lnip+"  /r/n/n Recebendo resultado do srv_mostraanot="+srv_ret)
          
          if( lnip==-1 ) {
             if( idselecproj.toUpperCase()=="DESCARREGAR" ) {
                   alert("\r\nCaso o Internet Explorer bloqueie o download, fa?a o seguinte:\r\n\r\n Op??o - Via Ferramentas do Internet Explorer\r\n 1 - Abra o Op??es do Internet Explorer e clique na aba Seguran?a.\r\n 2 - Clique no bot?o N?vel Personalizado e dentro de Configura??es de Seguran?a, localize o recurso Downloads \r\n3 - Em: Aviso autom?tico para downloads de arquivo e selecione Habilitar")
                   srv_ret = trim(srv_ret);
                   var array_arq = srv_ret.split("%");
                   self.location.href="../includes/baixar.php?pasta="+encodeURIComponent(array_arq[0])+"&file="+encodeURIComponent(array_arq[1]); 
                   ////  Botao para Nova Anotacao  -  aparecer
                   if( document.getElementById("nova_anotacao") ) {
                        document.getElementById("nova_anotacao").style.display="block";               
                   } 
             } else  if( idselecproj.toUpperCase()=="DETALHES" ) {               
                   ///  alert("  anotacao_consultar.php/135  myArguments = "+myArguments)                
                    ///     var showmodal =  window.showModalDialog("myArguments_anotacao_nova.php?myArguments="+myArguments,myArguments,"dialogWidth:760px;dialogHeight:600px;dialogTop: 50px;resizable:no;status:no;center:yes;help:no;");  
                  var myArguments = trim(srv_ret);
                  var showmodal =  window.showModalDialog("myArguments_anotacao_nova.php",myArguments,"dialogWidth:760px;dialogHeight:600px;dialogTop: 50px;resizable:no;status:no;center:yes;help:no;");  
                   ///  Botao para Nova Anotacao  -  aparecer
                   if( document.getElementById("nova_anotacao") ) {
                        document.getElementById("nova_anotacao").style.display="block";  
                   } 
            } else {
                 document.getElementById('label_msg_erro').style.display="block";    
                 if( document.getElementById("nova_anotacao") ) {
                      document.getElementById("nova_anotacao").style.display="block";   
                 }
                 //// document.getElementById('div_out').style.display="none";
                 if( document.getElementById("div_out") ) {
                    document.getElementById("div_out").style.display="block";                  
                    document.getElementById('div_out').innerHTML=srv_ret;
                 }                 
             }
          } else {
               if( document.getElementById("div_form") )   document.getElementById("div_form").style.display="block";
               if( document.getElementById("div_out") )   document.getElementById("div_out").style.display="none";
               //              
   //   alert(" anotacao_nova.php/174 - idselecproj = "+idselecproj.toUpperCase()+" - idopcao = "+idopcao+" \r\n Recebendo resultado do srv_mostraanot="+srv_ret)                 
               if( idselecproj.toUpperCase()=="TODOS"  || idselecproj.toUpperCase()=="BUSCA_PROJ" )  {
                    /// Separando a mensagem recebida
                    var pos1 = srv_ret.search(/INICIA/i);
                    var pos2 = srv_ret.search(/FINAL/i);
                    if( pos1!=-1 && pos1!=-2  ) {
                        srv_ret = srv_ret.replace(/ERRO:|CORRIGIR_ERRO:|INICIA|FINAL/ig,"");                      
                    }
                }
                ////
                if( document.getElementById("nova_anotacao") ) {
                     document.getElementById("nova_anotacao").style.display="block";    
                }         
                ////
                /***
                    document.getElementById('label_msg_erro').style.display="block";
                    document.getElementById('label_msg_erro').innerHTML=srv_ret;
                ***/
                ///  Enviando a mensagem de erro 
                exoc("label_msg_erro",1,mensag_erro); 
                ///
           }; 
    };
    // 
    //  Define o servidor PHP para consulta do banco de dados
    var srv_php = "anotacao_nova_ajax.php";
    var poststr = new String("");
    /*
    if( idselecproj.toUpperCase()=="DETALHES" ) {
        alert(" Final  anotacao_consultar.php/170 -  idselecproj = "+idselecproj+" --  idopcao  =  "+idopcao+" - string_array = "+string_array)      
    } */
        
    //  DESCARREGAR - UPLOAD abrindo o arquivo pdf e  Detalhes da Anotacao do Projeto
    if( idselecproj.toUpperCase()=="DESCARREGAR" || idselecproj.toUpperCase()=="DETALHES"   ) {
       var poststr = "grupoanot="+encodeURIComponent(idselecproj)+"&val="+encodeURIComponent(idopcao)+"&m_array="+encodeURIComponent(string_array); 
    }  else {
        var poststr = "cip="+encodeURIComponent(op_projcod)+"&grupoanot="+encodeURIComponent(op_selanot)+"&op_selcpoid="
                +encodeURIComponent(op_selcpoid)+"&op_selcpoval=" +encodeURIComponent(op_selcpoval) ;
    }

// alert("Ativando srv_mostraanot com poststr="+poststr)
    xAJAX_mostraanot.connect(srv_php, "POST", poststr, fndone_mostraanot);   
}
//  Verifica se foi selecionado o Projeto
function ativar(projeto_selec)  {
    projeto_selec = trim(projeto_selec);
    if( document.getElementById("div_out") )  {
                document.getElementById("div_out").innerHTML="";
                document.getElementById("div_out").style.display="none";      
    } 
    //
    if( document.getElementById("div_form") )   document.getElementById("div_form").style.display="block";                  
    //
    if( projeto_selec.length>0 ) {       
        document.getElementById("label_msg_erro").style.display="none";    
        document.getElementById('id_anotacao').style.display="block";
    } else {
        document.getElementById("label_msg_erro").style.display="block";    
        document.getElementById('id_anotacao').style.display="none";       
    }      
    //  Alterado em 20121026
    consulta_mostraanot("busca_proj", "TODOS");
    return;
}
//
</script>
<?php
///  Alterado em 20171004
///  require_once("{$_SESSION["incluir_arq"]}includes/dochange.php");
require("{$_SESSION["incluir_arq"]}includes/domenu.php");
//     Consultar Anotacao
if( isset($_GET["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_GET["m_titulo"];    
} elseif( isset($_POST["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_POST["m_titulo"];      
}
//   
?>
</head>
<body  id="id_body" oncontextmenu="return false" onselectstart="return false"  ondragstart="return false" onkeydown="javascript: no_backspace(event);"  >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho -->
<div id="cabecalho"  >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div id="corpo"  >
<!--  Mensagem de ERRO     -->
<section class="merro_e_titulo" >
<div  id="label_msg_erro"  >
</div>
<p class='titulo_usp' ><b>Lista de&nbsp;<?php echo ucfirst($_SESSION["m_titulo"]);?></b></p>
</section>
<?php
//     Verificano o PA - Privilegio de Acesso
// if( ( $permit_pa>$_SESSION['array_usuarios']['superusuario']  and $permit_pa<=$permit_anotador ) ) {    
if( ( $permit_pa>$array_pa['super']  and $permit_pa<=$permit_anotador ) ) {        
    // Para incluir nas mensagens
    //  include_once("../includes/msg_ok_erro_final.php");
    //
    //   Definindo a variavel usuario para mensagem
    //  $usuario="Orientador"; 
    //  if( $_SESSION["permit_pa"]!=$array_pa['orientador'] ) $usuario="Usu&aacute;rio"; 
    //    
    //   Conectar - CODIGO/USP
    $elemento=5; $elemento2=6;
    include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");     
     //
?>
<p class='titulo_usp' style='margin: 2px 0px 0px; padding: 2px 0px 0px; line-height:normal; ' ><b>Selecione o Projeto: </b>
<select name="busca_proj" id="busca_proj" title="Selecione o Projeto para Busca de Anota&ccedil;&otilde;es" onchange="javascript: ativar(this.value)"  >
    <!-- Identifica??o do Projeto [Fonte][ProcessoNo.][ - Titulo] -->
    <?php 
        if ($permit_pa<=$permit_orientador) {
            $sqlcmd = "SELECT a.codigousp,a.nome,b.cip,b.fonterec,b.fonteprojid,b.numprojeto,b.titulo,"
                ."b.anotacao FROM $bd_1.pessoa a, $bd_2.projeto b where a.codigousp=b.autor and "
                ." a.codigousp=".$usuario_conectado." order by b.titulo ";
        } else {
            $sqlcmd = "SELECT a.codigousp,a.nome,b.cip,b.fonterec,b.fonteprojid,b.numprojeto,b.titulo,"
                ."b.anotacao FROM $bd_1.pessoa a, $bd_2.projeto b where a.codigousp=b.autor and "
                ." b.cip in (select distinct cip from $bd_2.anotador "
                ." where codigo=".$usuario_conectado.")  order by b.titulo ";
        }
        $result = mysql_query($sqlcmd); 
        //                  
        if( ! $result ) {
            //  die('ERRO: Selecionando os projetos autorizados para esse Usu&aacute;rio: '.mysql_error());  
            /* $msg_erro .= "Selecionando os Projetos autorizados para esse {$_SESSION["usuario_pa_nome"]} - db/mysql:&nbsp; ".mysql_error();
            echo $msg_erro.$msg_final;  */            
            //  Parte do Class                
            echo $funcoes->mostra_msg_erro("Selecionando os Projetos autorizados para esse {$_SESSION["usuario_pa_nome"]} - db/mysql:&nbsp; ".mysql_error());
            exit();                  
        }
        //  Numero de Projetos Selecionados
        $nprojetos = mysql_num_rows($result);
        if ( $nprojetos<1 ) {
              echo "<option value='' >N&atilde;o existe Projeto vinculado a esse {$_SESSION["usuario_pa_nome"]}.</option>";
        } else {
              echo "<option value='' >Selecione o Projeto a ser acessado por esse {$_SESSION["usuario_pa_nome"]} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>";
              //
              while($linha=mysql_fetch_assoc($result)) {
                    $_SESSION["cip"]=$linha['cip'];
                    $_SESSION["anotacao_numero"]=$linha['anotacao']+1;
                    if( $_SESSION["anotacao_numero"]<1 ) $_SESSION["anotacao_numero"]=1;
                    $autor_nome = $linha['nome'];
                    /*  Desativado por nao ter valores nos campos fonterec e fonteprojid
                    $titulo_projeto = htmlentities($linha['fonterec'])."/".ucfirst(htmlentities($linha['fonteprojid']))
                                      .": ".$linha['titulo'];   */
                    $fonterec=htmlentities($linha['fonterec']);
                    $fonteprojid=  ucfirst(htmlentities($linha['fonteprojid']));         
                     //  PARTES do Titulo do Projeto - dividindo em sete partes - IMPORTANTE
                     $partes_antes=6;
                     $projeto_titulo_parte="";
                     $palavras_titulo = explode(" ",trim($linha['titulo']));
                     $contador_palavras=count($palavras_titulo);
                     for( $i=0; $i<$contador_palavras; $i++  ) {
                           $projeto_titulo_parte .="{$palavras_titulo[$i]} ";
                           if( $i==$partes_antes and $contador_palavras>$partes_antes  ) {
                                $projeto_titulo_parte=trim($projeto_titulo_parte);
                                $tamanho_campo=strlen($projeto_titulo_parte);
                                if( $tamanho_campo>40  ) $projeto_titulo_parte.="...";
                              //  $projeto_titulo_parte .="<span style='font-weight: bold;font-size: large;' >...</span>";
                                break;
                           }
                     }
                     $titulo_projeto="";
                     if( strlen(trim($fonterec))>=1  ) {
                           $titulo_projeto.= $fonterec."/";
                     }
                     if( strlen(trim($fonteprojid))>=1  ) {
                          $titulo_projeto.= $fonteprojid.": ";
                     }
                     $titulo_projeto .= trim($projeto_titulo_parte);                    
                    //  Usando esse option para incluir espaco sobre linhas
                    echo  "<option value='' disabled ></option>";                  
                    echo "<option  value=".$linha['cip']."  title='Orientador do Projeto: $autor_nome' >"
                        .$titulo_projeto."&nbsp;&nbsp;</option>";   
              }
        }
        ?>
        </select>
</p>
<div id="div_form" style="width:100%; overflow: hidden; height: 320px;  ">
<?php
//
//  Selecionar as anota??es de projeto pelo campo desejado
$opcao_cpos = Array("ano_inicio","ano_final","anotacao") ;
$opcao_ncpos = count($opcao_cpos);                
//
//  Salvar letrais iniciais em um conjunto para facilitar a busca
?>
<div id="id_anotacao" style="display: none; height: 340px; " >
<?php
} else {
   echo  "<p  class='titulo_usp' >Usu&aacute;rio n&atilde;o autorizado</p>";
}
?>
<!--  Recebe os dados - Tabela -->
<div id="div_out" style="width:100%; overflow: hidden; height: 280px; margin-bottom: 0px;">
</div>
<!--  Nova Anotacao - Botao  -->
<div id="nova_anotacao" style="width:100%; overflow: hidden; margin-top: 2px; height: 70px; ">
  <p style="margin-top: 0px; vertical-align: middle; " align="center"  >
    <button name="nova" id="nova" type="submit" class="botao3d" style="cursor: pointer; height: 30px; vertical-align: middle;"  title="Nova Anota??o"  acesskey="N"  alt="Nova Anota??o"  onclick="javascript: top.location.href='../cadastrar/anotacao_cadastrar_nova.php';"   >    
      Nova&nbsp;<img src="../imagens/enviar.gif" alt="Nova Anota??o"  style="vertical-align: middle;"  >
  </p>
</div>
</div>
<!-- Final id id_anotacao -->
</div>
<!-- Final id div_form -->
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape"  >
<?php include_once("../includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>