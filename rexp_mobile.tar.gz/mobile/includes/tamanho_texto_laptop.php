<?php
  //   Opcoes para o tamanho do texto na pagina
?>
<div style="position:relative;float:initial; text-align: right; font-weight:bold;font-size: 14px;" id="tamanho_texto"  >Tamanho de texto:&nbsp;
  <a href="#" title="diminuir" onclick="javascript:tamanho_texto('diminuir')" style="text-decoration:none; cursor:pointer;" >   <!--  <a href="#" title="diminuir" onclick="javascript:zoomIn()" style="text-decoration:none; cursor: pointer;" >  -->
  <span style="font-weight:bold; color:#003300;font-size: 14px;" id="a_pequeno"  >-A</span></a>&nbsp;
  	<a href="#" title="aumentar" onclick="javascript:tamanho_texto('aumentar')" style="text-decoration:none; cursor: pointer;" > 
   <!--  <a href="#" title="aumentar" onclick="javascript:zoomOut()" style="text-decoration:none; cursor: pointer;" >  -->
	<span style="font-weight:bold; color:#003300;font-size: 18px; margin-right: 20px;"  id="a_maior"  >+A</span></a>
</div>
