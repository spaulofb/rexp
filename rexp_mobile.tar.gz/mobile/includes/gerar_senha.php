<?php
//   Criando uma nova senha
//  function GenPwd($length = 7) {
function GenPwd($length = 8) {
  $password = "";
  $possible = "0123456789bcdfghjkmnpqrstvwxyz"; // nenhuma vogal
  $i = 0; 
  while( $i<$length) { 
     $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);
     //   Abaixo para nao criar senha com duplicatas
     //  Caso nao encontrou na variavel password algum caracter da char acrescentar
     if ( ! strstr($password, $char) ) { 
        $password .= $char;
        $i++;
     }
  }
  $m_pwd = strtoupper(trim($password));
  $verificar_senha=mysql_query("Select login,codigousp from usuario where "
                              ." upper(trim(senha))=password('$m_pwd')  ");
  //
  if( ! $verificar_senha  ) {
       mysql_free_result($verificar_senha);
       die("ERRO: Select verificar_senha  - ".mysql_error());
  } 
  $n_senhas=mysql_num_rows($verificar_senha);
  if( $n_senhas>=1 ) {
      mysql_free_result($verificar_senha);
      GenPwd();
  }                     
  return $password;
} 
?>
