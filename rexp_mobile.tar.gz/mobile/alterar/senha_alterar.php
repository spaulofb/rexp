<?php 
/*   REXP - ALTERAR SENHA  
*   
*   REQUISITO: Alterar a senha usuario/login
* 
*   SPFB&LAFB110825.1610    
*/
//  ==============================================================================================
///  ALTERA SENHA 
//  ==============================================================================================
//
//  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
//
// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 

//// Mensagens para enviar
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";
///   FINAL - Mensagens para enviar

///  Verificando SESSION incluir_arq
if( ! isset($_SESSION["incluir_arq"]) ) {
     $msg_erro .= "Sessão incluir_arq não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
$incluir_arq=$_SESSION["incluir_arq"];
///
///   Iniciando conexao
include("{$_SESSION["incluir_arq"]}inicia_conexao.php");
////
///  HOST mais a pasta principal do site - host_pasta
$host_pasta="";
if( isset($_SESSION["host_pasta"]) ) {
     $host_pasta=$_SESSION["host_pasta"];  
} else {
     $msg_erro .= "Sessão host_pasta não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
///  DEFININDO A PASTA PRINCIPAL 
///  $_SESSION["pasta_raiz"]="/rexp_responsivo/";     
///  Verificando SESSION  pasta_raiz
if( ! isset($_SESSION["pasta_raiz"]) ) {
     $msg_erro .= "Sessão pasta_raiz não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
$_SESSION["url_central"] = "http://".$_SESSION["http_host"].$_SESSION["pasta_raiz"];
$raiz_central=$_SESSION["url_central"];
///
//    MENU HORIZONTAL
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) {
   $array_pa = $_SESSION["array_pa"];    
   $permit_orientador = $array_pa['orientador'];
}
///   Definindo a sessao 
if( ! isset($_SESSION["projeto_autor_nome"]) ) $_SESSION["projeto_autor_nome"]="";
///
$_SESSION["m_horiz"] = $array_projeto;
///
//  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anotação";
/// $_SESSION['time_exec']=180000;
////  INCLUINDO CLASS - 
require_once("{$incluir_arq}includes/autoload_class.php");  
$funcoes=new funcoes();
///
?>
<!DOCTYPE html>
<html lang="pt-br" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="language" content="pt-br" />
<meta name="author" content="Sebasti?o Paulo" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta name="ROBOTS" content="NONE"> 
<meta http-equiv="Expires" content="-1" >
<meta name="GOOGLEBOT" content="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<title>REXP - Alterar senha</title>
<!--  <script type="text/javascript"  language="javascript"   src="../js/dochange_new.js" ></script>  -->
<link  type="text/css"  href="<?php echo $host_pasta;?>css/estilo.css"  rel="stylesheet"  />
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/functions.js"  charset="utf-8" ></script>
<!--  <script type="text/javascript"  src="<?php echo $host_pasta;?>js/anotacao_cadastrar.js" ></script>  -->
<script type="text/javascript" src="<?php echo $host_pasta;?>js/responsiveslides.min.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/resize.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/verifica_mobile.js" ></script>
<!--  <script type="text/javascript"  src="<?php echo $host_pasta;?>js/alterar_senha.js" ></script>  -->
<?php
/***    Arquivo javascript em PHP - alterado em 20171024
***/  
include("{$_SESSION["incluir_arq"]}js/alterar_senha_js.php");
///

$_SESSION["n_upload"]="ativando";
///  Para fazer mudar de pagina no Menu  -  alterado em 20171023
/// require_once("{$_SESSION["incluir_arq"]}includes/dochange.php");   
require("{$_SESSION["incluir_arq"]}includes/domenu.php");
///
?>
</head>
<body  id="id_body"  oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"    onkeydown="javascript: no_backspace(event);" >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"   >
<!-- Cabecalho -->
<div id="cabecalho"  >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<?php 
///   ALTERAR SENHA
if (isset($_GET["m_titulo"])) {
    if( strlen(trim($_GET["m_titulo"]))>1 )  $_SESSION['m_titulo']=$_GET["m_titulo"];  
}
if (isset($_POST["m_titulo"])) {
    if( strlen(trim($_POST["m_titulo"]))>1 )  $_SESSION['m_titulo']=$_POST["m_titulo"];      
}
///				  
?>
<!--  Tag div para mensagem  -->
<section class="merro_e_titulo" >
<div  id="label_msg_erro" >
</div>
<p class="titulo_usp" >Alterar Senha do C&oacute;digo de Acesso (Usu&aacute;rio/Login)</p>
</section>
<div  id="div_form"  style="width: 100%; overflow:auto; height: 416px;" >
<?php
///   Colocar as datas do Cadastro do Usuario e a validade
date_default_timezone_set('America/Sao_Paulo');
$dia = date("d");
$mes = date("m");
$ano = date("Y"); 
$ano_validade=$ano+2;
$_SESSION['datacad']="$ano-$mes-$dia";
$_SESSION['datavalido']="$ano_validade-12-31";
///
?>
<form name="form1" id="form1"  enctype="multipart/form-data"  method="post"  
 onsubmit="javascript: enviando_dados('submeter','SENHA',document.form1); return false"  >
  <table class="table_inicio" cols="4" align="center"   cellpadding="2"  cellspacing="2" style="font-weight:normal;color: #000000; border: none; "  >          
          <tr>
            <!--  Usuario para conectar -->
              <td  class="td_inicio1" style="vertical-align: middle; "  colspan="1"   >
                 <label for="login" style="vertical-align: middle; cursor: pointer;" title="C?digo do Usu?rio(Login)"   >Usu&aacute;rio(Login):&nbsp;</label>
              </td  >
			  <td class="td_inicio2"  colspan="3"  >
			  <input type="text" name="login"   id="login"   size="80"  maxlength="76" value="<?php echo $_SESSION['login_down']; ?>" autocomplete="off"  style="cursor: pointer;" readonly="readonly" disabled="disabled" />
			 </td>
            <!-- Final - Usuario -->
          </tr>

     <tr style="border: none;" >
       <!--  Verificando a Senha  -->  
       <td>&nbsp;</td>
       <td>
         <div id="div_forca_senha" name="div_forca_senha" style="background-color: rgb(255, 255, 255); width: 326px; margin:3px 0 3px 0;">Qualidade da Senha</div>
       </td>
     </tr>
          
     <tr class="td_inicio2" > 
        <!-- Incluir senha e redigitar_senha  --> 
        <td class="td_inicio1" >
           <label for="senha" style="cursor: pointer;"  >Nova Senha:&nbsp;</label>
        </td>
        <td class="td_inicio1"  style="text-align: left;"  >
           <input  type="password" class="required password" name="senha" id="senha" title="Digitar Senha (8 a 10 caracteres)" size="25" maxlength="12"  onKeyUp="this.value=trim(this.value);  verificaForca(this);"  onblur="javascript: alinhar_texto(this.id,this.value);  exoc('label_msg_erro',0,'');"  autocomplete="off"   > 
          <span class="example">(8 a 10 caracteres)</span>
        </td>
     </tr>
     <tr class="td_inicio2" > 
        <td class="td_inicio1" >
          <label for="redigitar_senha" style="cursor: pointer;"  >Redigitar Senha:&nbsp;</label>
        </td>
        <td class="td_inicio1"  style="text-align: left;" >
           <input  type="password" name="redigitar_senha"  id="redigitar_senha" class="required password" title="Redigitar Senha (8 a 10 caracteres)" size="25" maxlength="12"  onKeyUp="this.value=trim(this.value);  verificaForca(this);"  onblur="javascript: alinhar_texto(this.id,this.value); exoc('label_msg_erro',0,'');"  autocomplete="off"  >
        </td>
        <!-- Final -  Incluir senha e redigitar_senha  -->
     </tr>

     <!--  TAGS  type reset e  submit  --> 
     <tr  style="border: 1px solid #000000; width: 100%; vertical-align:top;  line-height:0px;" >
       <td colspan="4"  class="td_inicio1" nowrap style="background-color: #FFFFFF; padding: 1px; line-height:0px;">
		 <table border="0" cellpadding="0" cellspacing="0" align="center" style="width: 100%; line-height: 0px; margin:0px; padding: 2px 0 2px 0; border: none; vertical-align: top; " >
			    <tr style="border: none;">
				<td  align="CENTER" nowrap style="text-align:center; border:none;" >
			   <button name="limpar" id="limpar"  type="reset" onclick="javascript: document.getElementById('msg_erro').style.display='none';"  class="botao3d" style="cursor: pointer; "  title="Limpar"  acesskey="L"  alt="Limpar"     >    
      Limpar <img src="../imagens/limpar.gif" alt="Limpar" style="vertical-align:text-bottom;" >
   </button>
               <!-- Enviar -->				  
			      </td>
			   <td  align="center"  style="text-align: center; border:none; ">
			   <button name="enviar" id="enviar"   type="submit"  class="botao3d"  style="cursor: pointer; "  title="Enviar"  acesskey="E"  alt="Enviar"     >    
      Enviar&nbsp;<img src="../imagens/enviar.gif" alt="Enviar"  style="vertical-align:text-bottom;"  >
   </button>
			  </td>
              <!-- Final -Enviar -->
			   </tr>
              <!--  FINAL - TAGS  type reset e  submit  -->
			  </table>
			  </td>
            </tr>
         </table>
</form>
</div>
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape"  >
<?php include_once("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
