<?php
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
///

$pr_relatproj = $_SESSION["pr_relatproj"] = "/rexp/";
$incluir_arq="/var/www/html/rexp/mobile/";

/// $posicao=strripos($incluir_arq, "$pr_relatproj");
///  $posicao=strrpos($incluir_arq, "$pr_relatproj");
$posicao=strpos($incluir_arq, "$pr_relatproj");
$caminho_principal = substr_replace("$pr_relatproj",substr($incluir_arq,0,$posicao),0,0);

echo "<br/><b> --->>> ".substr($incluir_arq,0,$posicao).$pr_relatproj."       <<<---   </b><br/>";

echo $caminho_principal."<br/>";

$array=explode("$pr_relatproj",$incluir_arq);
$conc=$array[0].$array[1];

echo "<br/> array0 ".$array[0]."   -->>>  $conc ";

?>