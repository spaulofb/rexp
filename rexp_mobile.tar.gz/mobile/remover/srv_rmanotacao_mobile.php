<?php
//  AJAX da opcao Remover  - Servidor PHP para remover Anotacao do PROJETO
//  esse arquivo faz parte do anotacao_remover.php
//
//  LAFB&SPFB120803.1151
#
ob_start(); /* Evitando warning */
//
//  Verificando se session_start - ativado ou desativado
if(!isset($_SESSION)) {
   session_start();
}
// set IE read from page only not read from cache
//  header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control","no-store, no-cache, must-revalidate");
header("Cache-Control","post-check=0, pre-check=0");
header("Pragma", "no-cache");

//  header("content-type: application/x-javascript; charset=tis-620");
//  header("content-type: application/x-javascript; charset=iso-8859-1");
header("Content-Type: text/html; charset=ISO-8859-1",true);
//  Melhor setlocale para acentuacao - strtoupper, strtolower, etc...
setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8");
//
//   Para acertar a acentuacao
// $_POST = array_map(utf8_decode, $_POST);
// extract: Importa vari?veis para a tabela de s?mbolos a partir de um array 
extract($_POST, EXTR_OVERWRITE);  

//  Par?metros de controle para esse processo:
if( isset($_POST['cip']) ) $cip= $_POST['cip'];
if( isset($_SESSION["usuario_conectado"]) ) $usuario_conectado= $_SESSION["usuario_conectado"];
if( isset($_POST['grupoanot']) ) $opcao = strtoupper(trim($_POST['grupoanot']));
if( isset($_POST['op_selcpoid']) ) $op_selcpoid = $_POST['op_selcpoid'];
if( isset($_POST['op_selcpoval']) ) $op_selcpoval= $_POST['op_selcpoval'];
if( isset($_POST['nr_anotacao']) ) $nr_anotacao = $_POST['nr_anotacao'];
/*
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";
*/
$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";
$msg_final="</span></span>";
//
// Conectar 
$elemento=5; $elemento2=6;
include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");
require_once('/var/www/cgi-bin/php_include/ajax/includes/tabela_pa.php');
if( isset($_SESSION["array_pa"]) ) $array_pa=$_SESSION["array_pa"];        
//
//  INCLUINDO CLASS - 
require_once('../includes/autoload_class.php');  
$funcoes=new funcoes();
// $funcoes->usuario_pa_nome();
// $_SESSION["usuario_pa_nome"]=$funcoes->usuario_pa_nome;
//
//  UPLOAD -  do Servidor para maquina local

if( isset($idopcao) ) {
    if( ! isset($opcao) or strlen(trim($opcao))<1 ) $opcao=$idopcao;
}
//
$opcao_maiusc=strtoupper(trim($opcao));
//
if( $opcao_maiusc=="DESCARREGAR" )  {
    // Define o tempo m?ximo de execu??o em 0 para as conex?es lentas
    set_time_limit(0);
    $post_array = array("grupoanot","val","m_array");
    for( $i=0; $i<count($post_array); $i++ ) {
        $xyz = $post_array[$i];
        //  Verificar strings com simbolos: # ou ,   para transformar em array PHP
        $xyz=="m_array" ? $div_array_por = "#" : $div_array_por = ",";
        if ( isset($_POST[$xyz]) ) {
            $pos1 = stripos(trim($_POST[$xyz]),$div_array_por);
            if ( $pos1 === false ) {
                //  $$xyz=trim($_POST[$xyz]);
                //   Para acertar a acentuacao - utf8_encode
                $$xyz = utf8_decode(trim($_POST[$xyz])); 
            } else  $$xyz = explode($div_array_por,$_POST[$xyz]);
        }
    }    
    // $pasta = "/var/www/html/rexp3/doctos_img/A".$m_array[0];
    $pasta = "../doctos_img/A".$m_array[0];
    $pasta .= "/".$m_array[1]."/";     
    //  $output = shell_exec('for arq in `ls '.$pasta.'/*.*`; do mv $arq `echo $arq | tr  [:upper:] [:lower:] `; done');    
    $host  = "http://".$_SERVER['HTTP_HOST']; 
    $arquivo = trim($val);
       
    if( ! file_exists("{$pasta}".$arquivo) ) {
         /* $msg_erro .= "&nbsp;Esse Arquivo: ".$arquivo."  n&atilde;o tem no Servidor".$msg_final;
         echo $msg_erro;  */
         
         echo  $funcoes->mostra_msg_erro("&nbsp;Esse Arquivo: ".$arquivo."  n&atilde;o tem no Servidor");                  
    }  else   echo $pasta."%".$arquivo;
    //
    unset($opcao);
    exit();     
} elseif( $opcao_maiusc=="TODOS" ) {
    //
   $_SESSION["table_remover"] = "$bd_2.temp_remover_anotacao";
   $sql_temp = "DROP TABLE IF EXISTS   ".$_SESSION["table_remover"]."    ";  
   $drop_result = mysql_query($sql_temp); 
   if( ! $drop_result  ) {
        // die('ERRO: Falha removendo a tabela '.$_SESSION["table_remover"].' - '.mysql_error());  
        // Parte do Class
        echo $funcoes->mostra_msg_erro("Removendo a Tabela {$_SESSION["table_remover"]} - db/mysql:&nbsp; ".mysql_error());
        exit();                      
   }
   $_SESSION["selecionados"]="";
   //  Selecionar a anotacao para remover
   $sqlcmd ="CREATE TABLE  IF NOT EXISTS ".$_SESSION["table_remover"]."   ";
/*   $sqlcmd .= "SELECT numero as nr, alteraant as altera_nr, autor as anotador, "
             ."concat(substr(data,9,2),'/',substr(data,6,2),'/',substr(data,1,4)) as data_anot, "
             ."testemunha1, testemunha2, "
             ." titulo, relatext as arquivado_como FROM $bd_2.anotacao  ";
*/             
    //
    /*
    $sqlcmd .= "SELECT a.numero as nr,  a.alteraant as Altera, alteradapn as Alterada, a.titulo as T?tulo, b.nome as Anotador,   "
        ." concat(substr(a.data,9,2),'/',substr(a.data,6,2),'/',substr(a.data,1,4)) as Data, "
        ." a.relatext as Arquivo FROM $bd_2.anotacao a, $bd_1.pessoa b WHERE a.autor=b.codigousp and  ";
    */        
    $sqlcmd .= "SELECT a.numero as nr,  a.alteraant as Altera, alteradapn as Alterada, "
        ." a.titulo as T?tulo, b.nome as Anotador,   "
        ." concat(substr(a.data,9,2),'/',substr(a.data,6,2),'/',substr(a.data,1,4)) as Data "
        ." FROM $bd_2.anotacao a, $bd_1.pessoa b WHERE a.autor=b.codigousp and  ";

    //  if( $_SESSION["permit_pa"]==$_SESSION['array_usuarios']['orientador'] )  {
    if( $_SESSION["permit_pa"]==$array_pa['orientador'] )  {
        $where_cond = "  a.projeto=$cip   ";    
    } else   $where_cond = "  a.projeto=".$cip." and a.autor=".$usuario_conectado;
    
    $sqlcmd .= $where_cond." order by a.numero desc";
    //
    $result_rmanotacao = mysql_query($sqlcmd);
    if( ! $result_rmanotacao ) {
       //  die('ERRO: Falha consultando a tabela anota&ccedil;&atilde;o  - op&ccedil;&atilde;o='.$opcao.' - '.mysql_error().$orientador);
       
        echo $funcoes->mostra_msg_erro("Consultando a Tabela anota&ccedil;&atilde;o - db/mysql:&nbsp; ".mysql_error());            
        exit();        
    }       
    //  Selecionando todos os registros da Tabela temporaria
   $query2 = "SELECT * from  ".$_SESSION["table_remover"]."  ";
   $result_outro = mysql_query($query2);                                    
   if( ! $result_outro ) {
        // die("ERRO: Selecionando as Anota&ccedil;&otilde;es do Projeto  - ".mysql_error());  
        
        echo $funcoes->mostra_msg_erro("Selecionando as Anota&ccedil;&otilde;es do Projeto  - db/mysql:&nbsp; ".mysql_error());     
        exit();                 
   }        
   //  Pegando os nomes dos campos do primeiro Select
   $num_fields=mysql_num_fields($result_outro);  //  Obt?m o n?mero de campos do resultado
   $td_menu = $num_fields+1;   
   //  Total de registros
   $_SESSION["total_regs"] = mysql_num_rows($result_outro);
   if( $_SESSION["total_regs"]<1 ) {
       /* $msg_erro .= "&nbsp;Nenhuma Anota&ccedil;&atilde;o para esse Projeto ".$msg_final;        
        echo $msg_erro;  */
        
        echo $funcoes->mostra_msg_erro("INICIA&nbsp;Nenhuma Anota&ccedil;&atilde;o para esse Projeto.FINAL");            
        exit();
   }   
   $_SESSION['total_regs']==1 ? $lista_usuario=" <b>1</b> Anota&ccedil;&atilde;o " : $lista_usuario="<b>".$_SESSION['total_regs']."</b> Anota&ccedil;&otilde;es ";     
   $_SESSION["titulo"]= "<p class='titulo'  style='text-align: left; margin: 0px 0px 0px 4px; padding: 0px; '  >";
   $_SESSION["titulo"].= "Lista de $lista_usuario ".$_SESSION['selecionados']."</p>"; 
   //  Buscando a pagina para listar os registros        
   $_SESSION["num_rows"]=$_SESSION["total_regs"];  $_SESSION["name_c_id0"]="codigousp";    
   if( isset($titulo_pag) )  $_SESSION["ucfirst_data"]=$titulo_pag;
    $_SESSION["pagina"]=0;
   $_SESSION["m_function"]="remove_anotacao" ;  $_SESSION["conjunto"]="Anotacao#@=".$usuario_conectado."#@=".$cip;
   $_SESSION["opcoes_lista"] = "../includes/tabela_de_remocao_anotacao.php?pagina=";
   require_once("../includes/tabela_de_remocao_anotacao.php");                      
   //
   unset($opcao);
   exit();
} elseif( $opcao_maiusc=="REMOVER" ) {
     //   Fomrulario para recemover Anotacao
     if( ! isset($_POST['nr_anotacao']) ) $nr_anotacao=0;
     if( intval($nr_anotacao)<1  ) {
          echo "ERRO: Anota??o inv?lida.";
     }  else {
         //  Seleciona a Anotacao para Remover
         $sqlcmd = "SELECT a.cia, a.numero as nr, a.alteraant as altera_nr, a.autor as anotador, "
                      ."concat(substr(a.data,9,2),'/',substr(a.data,6,2),'/',substr(a.data,1,4)) as data_anot, "
                      ."a.testemunha1, a.testemunha2, "
                      ." a.titulo as tit_anotacao, a.relatext as arquivado_como,  "
                      ." b.autor as autor_projeto, b.titulo as tit_projeto "
                      ." FROM rexp.anotacao a, rexp.projeto b "
                      ." WHERE ( a.projeto=b.cip ) and a.projeto=$cip  and  a.numero=$nr_anotacao ";
            //
            $result_anotacao_rm = mysql_query($sqlcmd);
            if( ! $result_anotacao_rm ) {
                 if( isset($result_anotacao_rm) ) mysql_free_result($result_anotacao_rm);
                 echo  $funcoes->mostra_msg_erro("Falha consultando a tabela anota&ccedil;&atilde;o  - ".mysql_error());                  
            } else {
                ///
                //  Clicar o Formulario da Anotacao para ser excluida     
                $array_nome=mysql_fetch_array($result_anotacao_rm);
                foreach(  $array_nome as $key => $value ) {
                     $$key=$value;
                }
                //  Passando as variaveis para SESSION
                $_SESSION["autor_projeto"]=$autor_projeto; $_SESSION["projeto"]=$cip; 
                $_SESSION["anotacao"]=$nr_anotacao;  $_SESSION["arquivado_como"]=$arquivado_como;  
                //   Formulario da Anotacao para Excluir
                $texto1="<div class='caixa_box' >";
                $texto1.="Excluir essa Anota&ccedil;&atilde;o desse Projeto?";
                $texto1.="</div>";
                echo $texto1;
                $_SESSION["cols"]=4; $td1_width="35";  $tr_heigth="26px";
                /////          
          ?>
       <div class="td_inicio1" style="overflow: hidden;text-align: left;" >
         <span  class="titulo_pequeno"  >Anotador:&nbsp;</span>
        <!-- N. Funcional USP/Matricula - Autor/ANOTADOR -->
        <?php 
            //  Selecionando Anotador
            $res_anotador = mysql_query("SELECT codigousp,nome,categoria FROM $bd_1.pessoa WHERE "
                                    ."   codigousp=$anotador order by nome "); 
            if( ! $res_anotador ) {
                if( isset($res_anotador))  mysql_free_result($res_anotador);
                echo  $funcoes->mostra_msg_erro("Select Tabela  pessoa - db/mysql: ".mysql_error());                  
                exit();                
            }
            //  Cod/Num_USP/Autor/Anotador
            $m_linhas = mysql_num_rows($res_anotador);
            if ( $m_linhas<1 ) {
                $autor="== Nenhum encontrado ==";
            } else {
                  $_SESSION["anotador_codigousp"]=mysql_result($res_anotador,0,"codigousp");
                  $anotador_nome=mysql_result($res_anotador,0,"nome");
                  $anotador_categoria=mysql_result($res_anotador,0,"categoria");                    
                  if( isset($res_anotador))  mysql_free_result($res_anotador);
            }
            // Final da Num_USP/Nome Autor/Anotador
           //  Nome do Anotador do Projeto
           echo "<span style='color: #FFFFFF; font-size: small;' >$anotador_nome</span>";           
       ?>  
       <input type="hidden" name="autor" id="autor"  value="<?php echo $_SESSION["anotador_codigousp"];?>" />
      </div>

      <!--  Titulo da Projeto  -->
      <div  class="td_inicio1" style="height: auto;text-align: left;"  >
             <span class="titulo_pequeno"  style="text-align: left; vertical-align: top; cursor:pointer;" title="T?tulo do Projeto"   >
                T&iacute;tulo do Projeto:&nbsp;
            </span>
            <div align="justify" style="overflow: auto; width: 100%;">
             <textarea cols="90" rows="3" disabled="disabled" style="background-color: #FFFFFF; color: #000000;" >
               <?php echo nl2br($tit_projeto);?>
             </textarea>
            </div>
      </div>
      
      
     <div class="td_inicio3"   style="font-size: small;  text-align: center; color:#000000;overflow: hidden; " >
         <span style="background-color: #FFFFFF;color: #000000;padding: 2px;border: 2px solid #000000;" >Anota&ccedil;&atilde;o#&nbsp;
         <?php echo $nr;?>
      <!--  Data da Anotacao  -->
       &nbsp;-&nbsp;Data:&nbsp;<?php echo $data_anot;?>
       </span>
     </div>
     
      <!--  Titulo da Anotacao  -->
     <div  class="td_inicio1"  style="text-align: left;  background-color: #32CD99; " >
          <span class="titulo_pequeno"  style=" vertical-align: top; cursor:pointer;" >T&iacute;tulo da Anota&ccedil;&atilde;o:&nbsp;</span>
             <div align="justify" style="overflow: auto; width: 100%;">
             <textarea cols="90" rows="3" disabled="disabled" style="background-color: #FFFFFF; color: #000000;"  >
               <?php echo nl2br($tit_anotacao);?>
             </textarea>
             </div>                    
       </div>



    <div  class="td_inicio3"  width="<?php echo $td1_width;?>" style="padding: 1px;text-align: left; "    >
      <div  style="padding: 1px; color: #000000; font-size: small; vertical-align:bottom; cursor: pointer;"  >Testemunha (1):&nbsp;
        <!-- C?digo da Testemunha (1) da realiza??o -->
        <?php 
            $result1=mysql_query("SELECT codigousp,nome as testemunha1_nome,categoria FROM pessoa where codigousp=$testemunha1 order by nome ");
            //  C?digo da Testemunha (1) da realiza??o 
            $testemunhas_result = $result1;
            //  include("testemunhas.php"); 
            echo "<span style='color: #FFFFFF; font-size: small;' >".mysql_result($result1,0,'testemunha1_nome')."</span>";           
            //
            if( isset($result1) ) mysql_free_result($result1); 
            // FINAL - C?digo da Testemunha (1) da realiza??o 
         ?>  
       </div>  
      <div  style="padding: 1px;color: #000000; font-size: small; vertical-align:bottom; cursor: pointer;"  >Testemunha (2):&nbsp;
        <!-- C?digo da Testemunha (2) da realiza??o -->
        <?php 
            $result=mysql_query("SELECT codigousp,nome as testemunha2_nome,categoria FROM pessoa where codigousp=$testemunha2 order by nome ");
             //  C?digo da Testemunha (2) da realiza??o 
             $testemunhas_result = $result;
             //  include("testemunhas.php"); 
             echo "<span style='color: #FFFFFF; font-size: small;' >".mysql_result($result,0,'testemunha2_nome')."</span>";           
             //
             mysql_free_result($result); 
             // FINAL - C?digo da Testemunha (2) da realiza??o 
         ?>  
         </div>
         
    
    <div  class="td_inicio4"  >
        <span  style="font-weight: bold; color: #000000; "  >
           Arquivo da Anota&ccedil;&atilde;o:&nbsp;
           </span>
            <!-- Arquivo da Anotacao -->
         <span style='background-color: #FFFFFF; color: #000000; padding:1px 2px 1px 2px;' ><?php echo $arquivado_como;?></span>           
    </div>

     <!--  TAGS  type submit - opcoes:  excluir e cancelar  --> 
              <div  style="text-align:center; width: 100%; line-height: 0px; margin:0px; border: none; vertical-align: top; " >
                  <!-- Excluir -->                  
                <span  align="CENTER" nowrap style="text-align:center; border:none;" >
               <button name="excluir" id="excluir"  type="submit" onclick="javascript: remove_anotacao('anotacao','Excluindo','<?php echo $cia;?>');"  class="botao3d" style="cursor: pointer; "  title="Excluir"  acesskey="E"  alt="Excluir"     >    
      Excluir <img src="../imagens/limpar.gif" alt="Excluir" style="vertical-align:text-bottom;" >
       </button>
        <!-- Final - Excluir -->
                  </span>
                  <!-- Cancelar -->                  
               <span  align="center"  style="text-align: center; border:none; ">
               <button name="cancelar" id="cancelar"   type="submit"  class="botao3d" onclick="javascript: location.reload();"  style="cursor: pointer; "  title="Cancelar"  acesskey="C"  alt="Cancelar"     >    
      Cancelar&nbsp;<img src="../imagens/enviar.gif" alt="Cancelar"  style="vertical-align:text-bottom;"  >
   </button>
              </span>
              <!-- Final - Cancelar -->
              <!--  FINAL - TAGS  type reset e  submit  -->
              </div>
   </div>
   <!--  FINAL DO FORMULARIO PARA REMOVER ANOTACAO  -->                
   <?php
                ///
            }               
            ////         
     }
     //  FINAL - IF $opcao_maiusc=="REMOVER"
} elseif( $opcao_maiusc=="EXCLUINDO"  && strtoupper(trim($op_selcpoval))=="ANOTACAO"  ) {
          //  'C?digo de Identifica??o da Anota??o - cia
         if( ! isset($cia) ) $cia=0;
         if( intval($cia)<1 ) {
               // Faltando cia
               echo $funcoes->mostra_msg_erro("Faltando a CIA (C?digo de Identifica??o da Anota??o)");
          } else {
                //
               //  Seleciona a Anotacao para Remover
               $sqlcmd = "SELECT a.cia, a.numero as nr, a.alteraant as altera_nr, a.autor as anotador, "
                          ."concat(substr(a.data,9,2),'/',substr(a.data,6,2),'/',substr(a.data,1,4)) as data_anot, "
                          ."a.testemunha1, a.testemunha2, "
                          ." a.titulo as tit_anotacao, a.relatext as arquivado_como,  "
                          ." b.autor as autor_projeto, b.titulo as tit_projeto "
                          ." FROM $bd_2.anotacao a, $bd_2.projeto b "
                          ." WHERE ( a.projeto=b.cip ) and a.cia=$cia ";
                //
                $result_anotacao_rm = mysql_query($sqlcmd);
                if( ! $result_anotacao_rm ) {
                     if( isset($result_anotacao_rm) ) mysql_free_result($result_anotacao_rm);
                     echo  $funcoes->mostra_msg_erro("Falha consultando a tabela anota&ccedil;&atilde;o  - ".mysql_error());                  
                } else {
                     ///
                     //  Clicar o Formulario da Anotacao para ser excluida     
                     $array_nome=mysql_fetch_array($result_anotacao_rm);
                     foreach(  $array_nome as $key => $value ) {
                          $$key=$value;
                     }
                 }
                 //
                 //  Essa PARTE vem do arquivo  -  myArguments_remover.php
                 $m_projeto=$_SESSION["projeto"]; $m_anotacao = $_SESSION["anotacao"]; 
                 $anotador = $_SESSION["anotador_codigousp"];
                 //  Arquivo da Anotacao do Projeto - escolhido para excluir
                 //  $arquivado_como = trim($_SESSION["arquivado_como"]);
                 
                 // $dir ? O DIRETORIO ONDE IR? LISTAR 
                 //   onde   A: Autor do Projeot  -  variavel val = anotacao
                 $m_autor_projeto=$_SESSION["autor_projeto"];
                 //
                 // Definindo o caminho do arquivo dessa anotacao que sera removido tambem
                 $val=strtolower(trim($op_selcpoval));
                 $dir= '../doctos_img/A'.$m_autor_projeto."/$val";
                 $remover_arq = $dir."/".$arquivado_como;
                 $dh  = opendir($dir);
                 $exempt = array('.','..'); $conta_arq=0;
                 //  Removendo o arquivo PDF
                 while( false !== ($filename = readdir($dh))) {
                     if( in_array(strtolower($filename),$exempt) ) continue;
                     $filename_maiusc = strtoupper(trim($filename));
                     $conta_arq++;
                     if( ( substr($filename_maiusc,-3,3)=="PDF") && ( $filename_maiusc==strtoupper(trim($arquivado_como)) ) ) {
                            /// Removendo o arquivo da ANOTACAO
                            unlink(trim($remover_arq)); 
                            $conta_arq--;             
                      }           
                 }
                 //  Caso NAO TENHA mais ARQUIVOS na PASTA remove-la tambem
                 if( $conta_arq<1 ) {
                     if( is_dir($dir) ) { 
                        rmdir($dir); 
                     } else echo $dir.' n&atilde;o existe'; 
                 }
                 //  FINAL removendo o arquivo PDF

//      echo "-->>  arq srm_rmanot.php/347 ---  $bd_2.$tabela  >>>>   $texto  -- \$op_selcpoval=$op_selcpoval  -  \$m_autor_projeto=$m_autor_projeto  -- \$dir=$dir  -- \$arquivado_como = $arquivado_como  ";                 
                 
                 //  Start a transaction - ex. procedure 
                 $lnerro=0;
                 $tabela="anotacao";
                 $commit="commit";   
                 mysql_query('DELIMITER &&'); 
                 mysql_query('begin'); 
                 //  Execute the queries          
                 //  mysql_db_query - Esta funcao e obsoleta, nao use esta funcao - Use mysql_select_db() ou mysql_query()
                 mysql_query("LOCK TABLES $bd_2.$tabela  DELETE ");
                 //
                 //  Removendo o registro da anotacao
                 $sqlcmd = "DELETE from $bd_2.$tabela  WHERE cia=$cia ";
                 $res_reg =  mysql_query($sqlcmd);
                 if( ! $res_reg  ) $lnerro=1;
                 //
                 if( intval($lnerro)>=1 ) {
                      echo $funcoes->mostra_msg_erro("&nbsp;Removendo registro. Cancelado - db/mysql:&nbsp; ".mysql_error());
                      $commit="rollback";
                 }    
                 //                  
                 mysql_query($commit);
                 mysql_query("UNLOCK  TABLES");
                 //  Complete the transaction 
                 mysql_query('end'); 
                 mysql_query('DELIMITER');
                 //  Removido
                 if( intval($lnerro)<1 ) {
                      echo $funcoes->mostra_msg_ok("&nbsp;Removido.");
                 }
      
      }  /// Final do IF  isset(cia)
}
#
ob_end_flush(); 
#
?>