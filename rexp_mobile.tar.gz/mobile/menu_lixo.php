<?php
/*   
*   REXP - REGISTRO DE EXPERIMENTO
* 
*   MODULO: Iniciando conexao   
* 
*/
//  @require_once('inicia_conexao.php');  once = somente uma vez
//  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
///
/// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 
//
//
require_once('inicia_conexao.php');

//
$incluir_arq="";
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
    echo "Sess�o incluir_arq n�o est� ativa.";
    exit();
}
///
//    MENU HORIZONTAL
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
//
$_SESSION["m_horiz"] = $array_projeto;
//   Definindo a Raiz do Projeto
//  $_SESSION["pasta_raiz"]='/rexp/';
$_SESSION["pasta_docs"]="doctos_img";
//
//  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anota&ccedil;&atilde;o";
// $_SESSION['time_exec']=180000;
//
// Alterado em 20120912 - Voltar a function como dochange
$_SESSION["function"]="dochange";
//
//  $_SESSION[http_host]= "http://".$_SERVER["HTTP_HOST"]."/rexp/";
$_SESSION["http_host"]= "http://".$_SERVER["HTTP_HOST"].$_SESSION["pasta_raiz"];
$_SESSION["url_central"] = $_SESSION["http_host"];
$http_host=$_SESSION["http_host"];
//

///  IMPORTANTE: para acentuacao em php/jsvascript 
header("Content-Type: text/html; charset=utf-8");

///
?>
<!DOCTYPE html>
<html lang="pt-BR" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!--  <meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" />  -->
<meta name="author" content="SPFB&LAFB" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0" />
<meta http-equiv="PRAGMA"  content="NO-CACHE">
<meta  name="ROBOTS"  content="NONE"> 
<!--  <meta HTTP-EQUIV="Expires" CONTENT="-1" >  -->
<!--  <meta HTTP-EQUIV="Expires" CONTENT="0" >  -->
<meta  name="GOOGLEBOT"  content="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<title>Projeto</title>
<!-- <script type="text/javascript"  language="javascript"   src="includes/domenu.php" ></script>  -->
<!-- <script type="text/javascript"  language="javascript"   src="js/domenu.js" ></script> -->
<link  type="text/css"  href="<?php echo $http_host;?>css/estilo.css" rel="stylesheet"  />
<link  type="text/css"   href="<?php echo $http_host;?>css/style_titulo.css" rel="stylesheet"  />
<script  type="text/javascript" src="<?php echo $http_host;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $http_host;?>js/functions.js" ></script>
<script type="text/javascript"  src="<?php echo $http_host;?>js/cad_proj_expe.js" ></script>
<?php
$_SESSION['n_upload']="ativando";
///   Para mudar de pagina no MENU
///  require_once("{$_SESSION["incluir_arq"]}includes/domenu.php");
///
?>
<script type="text/javascript">
///
///  Retirando a acentua��o de um Input de texto
function retira_acentos(palavra) {
    com_acento = "����������������������������������������������";
    sem_acento = "aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC";
    nova="";
    for(i=0;i<palavra.length;i++) {
        if( com_acento.search(palavra.substr(i,1))>=0) {
            nova+=sem_acento.substr(com_acento.search(palavra.substr(i,1)),1);
        } else {
            nova+=palavra.substr(i,1);
        }
    }
    return nova;
}
///

/*
      Funcao principal para enviar dados via AJAX
*/
function dochange(source,val,m_array)  {
    // Verifica se a variavel e uma string
    if( typeof(source)=='string' ) {
        //  string.replace - Melhor forma para eliminiar espa�os no comeco e final da String/Variavel
        source = source.replace(/^\s+|\s+$/g,""); 
    }
    
///  alert(" includes/domenu.php/41 - Inicial:  source="+source+" -  val = "+val+" - m_array ="+m_array)
  
    var source_maiusc = source.toUpperCase();     
    /* if ( source!="Sair" ) {
         timedClose();
    } else 
    */
   //  if( source_maiusc=="APRESENTA��O" ) {
   if( source_maiusc=="APRESENTA��O" ) {
         top.location.href="menu.php";
         return;     
    } else if( source_maiusc=="ANOTA��O" ) {     
         ///  ANOTACAO NOVA - 20121026
          top.location.href="includes/anotacao_nova.php";
          return;                       
    } else if( source_maiusc=="ALTERAR_SENHA" ) {
         ///  Apenas quando for o ANOTADOR
         top.location.href="alterar/senha_alterar.php";
         return;                
    }
    //
    var login_down = "<?php echo $_SESSION['login_down'];?>";
    var senha_down = "<?php echo $_SESSION['senha_down'];?>";
    var n_upload = "<?php echo $_SESSION['n_upload'];?>";

    //  Escolhido menu opcao: Cadastrar, Consultar
    //  Encontra a variavel source_lista no arquivo menu.php e tb no includes/dochange.php
    // var source_lista = "CADASTRAR CONSULTAR REMOVER ALTERAR LOGADO";        
    var source_lista = /CADASTRAR|CONSULTAR|REMOVER|ALTERAR|LOGADO/gi;        
    var temp_opcao =source_maiusc;
    /// var pos = source_lista.indexOf(temp_opcao);
    var pos = temp_opcao.search(source_lista);
    var pasta_raiz ="<?php echo $_SESSION["pasta_raiz"];?>"; 
    //  var caminho="http://www-gen.fmrp.usp.br/rexp/";
    // var caminho="http://www-gen.fmrp.usp.br"+pasta_raiz;

    var caminho="<?php echo $_SESSION['url_folder'];?>"+"/";

    if( pos!=-1  ) { 
         if( typeof(val)!="undefined" ) {   
                ////    var opcao_selecionada = val.toLowerCase();
                ///   var opcao_selecionada = retira_acentos(encodeURI(val));
                var opcao_selecionada = retira_acentos(val);

  alert("includes/domenu.php/139  -->> caminho="+caminho+" - opcao_selecionada="+opcao_selecionada+" - val="+val+" - pos = "+pos);                
                
         }
    }
          
}
///
</script>
</head>
<body  id="id_body"  oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"   onkeydown="javascript: no_backspace(event);"      >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho  -->
<div id="cabecalho" style="z-index:2;" >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<img src="imagens/anotando1.gif" />    
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape" >
<?php include("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
