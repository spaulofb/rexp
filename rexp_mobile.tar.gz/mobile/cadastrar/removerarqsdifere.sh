#!/bin/bash 
16d15
< pessoal_cadastrar_original.php
/bin/rm -i  removerarqsdifere.sh
