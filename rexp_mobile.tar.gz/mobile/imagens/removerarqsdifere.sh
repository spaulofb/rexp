#!/bin/bash 
/bin/rm -i  anotando_mobile.png
