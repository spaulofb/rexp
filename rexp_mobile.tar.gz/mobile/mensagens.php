<?php
/*
*   REXP - REGISTRO DE ANOTA??O DE PROJETO
* 
*       MODULO: mensagens 
*  
*   LAFB/SPFB110827.1708 - Corre??es gerais
*/
$msg_erro = "<p class='texto_normal' style='color: #000; text-align: center;' >";
$msg_erro .= "CORRIGIR_ERRO:&nbsp;<span style='color: #FF0000;' >";

$msg_ok = "<p class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000;' >";

$msg_final="</span></p>";
//
?>
