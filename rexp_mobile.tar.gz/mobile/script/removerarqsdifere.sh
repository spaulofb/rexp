#!/bin/bash 
/bin/rm -i  cabecalho_rge_original.php
/bin/rm -i  cabecalho_rge_v0.php
/bin/rm -i  lixo.php
