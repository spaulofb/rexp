<!DOCTYPE html >
<html lang="pt-br" >
<head>
 <title>width e height</title>
<meta charset="utf-8" >
<meta name="author" content="SPFB&LAFB" /> 
<style type="text/css">
<!--
.idd {
  width: 100%;
  height: 100px;
  background-color: #a7fea8;
  text-align: center;
 }
-->
</style>
</head>
<body>

<p>Click the button to alert the string with removed whitespace.</p>

<button onclick="myFunction()">Try it</button>

<div id="mostra1" style="padding-top:.5em;" ></div>
<div id="mostra2" style="padding-top:.5em;" ></div>

<p><strong>Note:</strong> The trim() method is not supported in Internet Explorer 8 and earlier versions.</p>

<div class="idd">Web site: http://simplificandoaweb.com</div>

Texto xtrim:&nbsp;<div  id="a" ></div> 
Texto ytrim:&nbsp;<div  id="b" ></div>

<!-- Data inicio do Projeto -->

<form>
                                <label for="datainicio"  title="Data de Início do Projeto" >Data in&iacute;cio:&nbsp;</label>
<input type="date" name="datainicio"   id="datainicio" maxlength="10" pattern="[0-9]{2}\/[0-9]{2}\/[0-9]{4}$"
                                     title="Digitar Data in&iacute;cio - exemplo: 01/01/1998" oninvalid="setCustomValidity('Date Invalid ')" 
                                    required="required"   onchange="try{setCustomValidity('')}catch(e){}" />
<br/>
<label for="datefim" >Date:&nbsp;</label>
<input type="date" name="datefim" id="datefim" onblur="javascript: validatedate(this.value);"  />                                    
                                   <!-- Final - Data inicio do Projeto -->
<br/>
<br/>
<input type="date" name="dtf" id="dtf" value="DD/MM/YYYY"    />                                                               
<br/>                                   
<br/>
<input type="button" onclick="verificadata('dtf');" >        
 </form>
<div id="mostrar" style="padding-top: 6px;position:relative;" ></div>
<br/>
<select   title="Ordernar"  id="ordenar"   style="display: block; font-size:medium;" 
  onchange="javascript:  consulta_mostraproj('ordenar',todos.value,this.value)"  >
<option  value=""  >ordenar por</option>
<option  value="cip asc"  >cip - asc</option>
<option  value="cip desc"  >cip - desc</option>
<option  value="datainicio asc"  >Data in&iacute;cio - asc</option>
<option  value="datainicio desc"  >Data <?php echo utf8_decode("início"); ?> - desc</option>
<option  value="titulo asc"  >T&iacute;tulo - asc</option>
<option  value="titulo desc"  >T&iacute;tulo - desc</option>
</select>
  <p style="font-weight: bold;text-align: center;font-size: larger;"  >FINAL AQUI</p>
  <?php
     $crypt = crypt('79a809e6567dfc44');
     $password=$_POST['password']='paulo!(""';
     
     
     $hashed_password = hash('sha512', $_POST['password']);
     $encrypt_pass= md5($password);
      echo   " MD5 =  $encrypt_pass  --->>>   \$crypt = $crypt --- <br/> HASH = \$hashed_password = $hashed_password  ";
  ?>
 </body>
</html>