<?php
///  Cabecalho - Topo 
/// session_save_path('/home/gemac/tmp'); 
if( ! isset($_SESSION)) {
     session_start();
}
////
////  $raiz_imagem="http://". $_SERVER["HTTP_HOST"].$_SESSION["pasta_raiz"];
///  Definindo http ou https
$_SESSION["protocolo"] = $protocolo = (strpos(strtolower($_SERVER['SERVER_PROTOCOL']),'https') === false) ? 'http' : 'https';
$_SESSION["url_central"]=$url_central=$protocolo."://".$_SERVER["HTTP_HOST"].$_SESSION["pasta_raiz"];
$raiz_imagem=$_SESSION["url_central"];
///
?>
<table cellSpacing="0" cellPadding="0" border="0" >
  <tr>
     <td>
        <a href="#">
           <img class="img_cabecalho"  src="<?php echo $raiz_imagem;?>imagens/topo_rge_nova.gif"  height="80" >    
        </a>
     </td>
  </tr>
  <tr>
     <td  background="<?php echo $raiz_imagem;?>imagens/b1.gif"  height="21"  style="font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#FFFFFF;">
        <?php echo $_SESSION["titulo_cabecalho"];  ?>
    </td>
    </tr>
</table> 

