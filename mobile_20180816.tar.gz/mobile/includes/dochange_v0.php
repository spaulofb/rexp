<?php
/*   javascript chamando PHP - para a OPCAO CONSULTAR
     Verificando se sseion_start - ativado ou desativado
     Alterado em  20121026
*/   

if( !isset($_SESSION)) {
     session_start();
}
//
//  Caso ocorrer erro
$php_errormsg='';
//////  $_SESSION["http_host"]= "http://".$_SERVER["HTTP_HOST"].$_SESSION["pasta_raiz"];
/// $_SESSION["url_central"] = 'http://'.$_SESSION["http_host"];
$_SESSION["url_central"] = $_SESSION["http_host"];
$http_host = @trim($_SESSION["url_central"]); 
///
if( ! empty($php_errormsg) ) {
    $http_host="../";
}
///
?>
<script type="text/javascript">
//
//  Javascript - 20100621
/*
     Aumentando a Janela no tamanho da resolucao do video
*/
self.moveTo(-4,-4);
//  self.moveTo(0,0);
self.resizeTo(screen.availWidth + 8,screen.availHeight + 8);
//  self.resizeTo(1000,1000);
self.focus();
//   Verificando qual a resolucao do tela - tem que ser no minimo 1024x768
if ( screen.width<1024 ) {
    alert("A resolu??o da tela do seu monitor para esse site ?\n RECOMEND?VEL no m?nimo  1024x768 ")
}
//
/*
      Funcao principal para enviar dados via AJAX
*/
function dochange(source,val,m_array)  {
    /// Verificando se a function exoc existe 
    if(typeof exoc=="function" ) {
         ///  Ocultando ID  e utilizando na tag input comando onkeypress
         exoc("label_msg_erro",0);  
    } else {
        alert("funcion exoc nao existe - ADMINISTRADOR CORRIGIR.");
        return;        
    }
    ///
    ///  Verificando variaveis
    if( typeof(source)=="undefined" ) var source=""; 
    if( typeof(val)=="undefined" ) var val="";
    if( typeof(m_array)=="undefined" ) var m_array="";
    if( typeof(val)=="string" ) {
         var val_upper=val.toUpperCase();
        /// IMPORTANTE: para retirar os acentos da palavra
         var val=retira_acentos(val);
    } 
  
    /// Verifica se a variavel e uma string
    if( typeof(source)=='string' ) {
        ///  string.replace - Melhor forma para eliminiar espa?os no comeco e final da String/Variavel
         source = source.replace(/^\s+|\s+$/g,""); 
        /// IMPORTANTE: para retirar os acentos da palavra
         var source=retira_acentos(source);
    }
    //  Variavel com letras maiusculas
    var source_maiusc = source.toUpperCase();   
 
    ///  Variavel com letras minusculas
    var subcaminho = source.toLowerCase();

    /// IMPORTANTE: para retirar os acentos da palavra
    var source_sem_acentos=retira_acentos(source_maiusc);
    
     ///  Define o caminho HTTP
     var raiz_central="<?php echo $http_host;?>";                             

 alert("  dochange.php/71  --->> raiz_central = "+raiz_central+"  --- source = "+source+" - val = "+val+"  -- m_array = "+m_array+"  -- source_maiusc =  "+source_maiusc); 

    ///  Sair do programa     
    if( source_sem_acentos=="SAIR" ) {
         ///   timedClose();
        /*  Navegador/Browser utilizado
           var navegador =navigator.appName;
           var pos = navegador.search(/microsoft/gi);
       */ 
        ///  Sair do Site fechando o Site
         ///  Sair do Site fechando a Janela
         var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome'); 
         var is_firefox = navigator.userAgent.toLowerCase().indexOf('firefox'); 
         var navegador =navigator.appName;
         /***
         //    Alterado em 20131119
         //    var is_microsoft = navegador.search(/microsoft/gi);
         ****/
         var navegador_usado="<?php echo $_SESSION["navegador"];?>";
         var is_microsoft = navegador_usado.search(/microsoft|ie/gi);
         //  if( pos!=-1 ) {
         //  if( navegador.search(/microsoft/gi)!=-1 ) {        
         if( is_firefox!=-1 ) {
               //  Sair da pagina e ir para o Site da FMRP/USP
               // location.replace('http://www.fmrp.usp.br/');      
               parent.location.href=raiz_central+"reiniciar.php";          
         } else if( is_chrome!=-1  || is_microsoft!=-1  ) {
              // 20120912 - Melhor opcao para  sair do Chrome
              parent.location.href=raiz_central+"reiniciar.php";
              window.open('', '_self', ''); // bug fix
              window.close();            
         }
         ///
        return;     
    }
    ///
    
 alert(" dochange/111  ---  source_maiusc =  "+source_maiusc+"  --  source_sem_acentos = "+source_sem_acentos);
    
    ///
   if( source_sem_acentos=="APRESENTACAO" ) {
        /// top.location.href="../menu.php";
       location.href=raiz_central+"menu.php";
        return;     
    }
    /**********
     else if( source_sem_acentos=="ANOTACAO" ) {     
        //  ANOTACAO NOVA - 20170919
        /// top.location.href="../includes/anotacao_nova.php?m_titulo=Anota??es";
        location.href=raiz_central+"includes/anotacao_nova.php?m_titulo=Anotacoes";
        return;                       
    }  else if( source_sem_acentos=="ALTERAR_SENHA" ) {
        //  Apenas quando for o ANOTADOR
        //// top.location.href="../alterar/senha_alterar.php";
        location.href=raiz_central+"alterar/senha_alterar.php";
        return;                
    }
    ***/
        
    /// LOGIN e SENHA 
    var login_down = "";
    var senha_down = "";
    var n_upload = "";
    //  Escolhido MENU opcao: Cadastrar, Consultar, etc...
    //  Encontra a variavel source_lista no arquivo menu.php e tb no includes/dochange.php
    /*
    var source_lista = "CADASTRAR CONSULTAR REMOVER ALTERAR";        
    var array_menu_pri = ["CADASTRAR","CONSULTAR","REMOVER","ALTERAR"];    
    var array_length = array_menu_pri.length;
    */
    var source_lista = /CADASTRAR|CONSULTAR|REMOVER|ALTERAR|LOGADO/gi;        
    var temp_opcao =source.toUpperCase();
       //  var pos = source_lista.indexOf(temp_opcao);
    var pos = temp_opcao.search(source_lista);
    var pasta_raiz ="<?php echo $_SESSION["pasta_raiz"];?>"; 
    //  var caminho="http://www-gen.fmrp.usp.br/rexp/";
    var caminho="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>"+pasta_raiz;
    if( pos!=-1  ) {      
        if( typeof(val)!="undefined" ) {   
            var opcao_selecionada = val.toLowerCase();
            ///  Retirando os acentos da palavra
            var opcao_selecionada = retira_acentos(opcao_selecionada);
            if( opcao_selecionada.toUpperCase()=="USUARIO" ) opcao_selecionada="usuario";
            if( opcao_selecionada.toUpperCase()=="ANOTACAO" ) opcao_selecionada="anotacao";                
        }
        /*  Atribui a sua regex a uma vari?vel comum
        *    dentro dos [], voc? coloca os caracteres 
        *    ou sequ?ncia de caracteres que vai permitir
        */        
        var lnpos = temp_opcao.search(/LOGADO/gi);
        
 ////  alert(" dochange.php - LINHA/160 -->> (1) lnpos = "+lnpos+"  \r\n (2)"+caminho+subcaminho+"/"+opcao_selecionada+"_"+subcaminho);        
        
        if( lnpos!=-1 ) {                
             ///  Opcao para trocar de  usuario  (Chefe, Orientador, Anotador e etc...)          
             top.location.href= caminho+"logar.php";
        } else {
             window.parent.location.href= caminho+subcaminho+"/"+opcao_selecionada+"_"+subcaminho+".php?m_titulo="+val.toLowerCase();
        }    
        return;
    }
    ///
    m_array = "array_m_v_"+m_array;
    var poststr = "source="+encodeURIComponent(source)+"&val="+encodeURIComponent(val)+"&m_array="+encodeURIComponent(m_array);
    //
    /*   Aqui eu chamo a class  */
    var myConn = new XHConn();
        
    /*  Um alerta informando da n?o inclus?o da biblioteca   */
    if ( !myConn ) {
          alert("XMLHTTP não disponível. Tente um navegador mais novo ou melhor.");
          return false;
    }
    //
    //  Arquivo Recebendo as opcoes desejadas: Cadastrar, Sair, etc...
    var receber_dados = "proj_exp_ajax.php";
    ///
    /*  Melhor usando display do que visibility - para ocultar e visualizar   */
    //      document.getElementById('div1').style.visibility="visible";
    // document.getElementById(id).style.display="block";
    //  document.getElementById('parte1').style.visibility="hidden";
    //
    var inclusao = function (oXML) { 
                        ///  Recebendo os dados do arquivo AJAX
                        var dados_recebidos = oXML.responseText;
                        /// 
                        
   alert("  dochange/206 --  dados_recebidos = "+dados_recebidos);                        
                        
                       ///  Procurando 
                       var pos = temp_opcao.search(source_lista);                        
                       if( source_sem_acentos=="SAIR" ) {
                              ////  Sair do Site e abrir outrar janela nova  
                             /*   var newwindows=window.open(dados_recebidos);
                                 newwindows.creator=self;
                                 window.close();
                             */
                             ///  Sair do Site fechando a Janela
                              window.open('','_parent','');window.close();    
                             ///   
                       } else if( pos!= -1  ) {            
                               top.location.href=dados_recebidos;
                       } else {
                           var posver=-1;
                           /// Verificando se existe Projeto para cadastrar Anotacao
                           if( source_sem_acentos=="ANOTACAO" && val.toUpperCase()=="VERIFICANDO"  ) {
                               /// Verificando se foi recebido ERRO/Nenhum
                               posver=dados_recebidos.search(/ERRO|Nenhum/i);
                               if( posver!=-1 ) {
                                   if( document.getElementById('div_form') ) {
                                         document.getElementById('div_form').style.display="none";   
                                   }
                                   if( document.getElementById('label_msg_erro') ) {
                                         dados_recebidos = dados_recebidos.replace(/ERRO:/gi,'');
                                         document.getElementById('label_msg_erro').style.display="block";    
                                         document.getElementById('label_msg_erro').innerHTML=dados_recebidos;
                                   }
                               }
                           } else {
                                 /*
                                 document.getElementById('corpo').style.display="block";
                                  document.getElementById('corpo').innerHTML= oXML.responseText;
                                ***/
                                /// Enviando dados
                                /// Dados recebidos pelo arquivo AJAX
                                exoc("corpo",1,dados_recebidos);   
                                ///
                           }          
                      }
               }; 
            /* 
              aqui ? enviado mesmo para pagina receber.php 
               usando metodo post, + as variaveis, valores e a funcao   */
        var conectando_dados = myConn.connect(receber_dados, "POST", poststr, inclusao);   
        /*  uma coisa legal nesse script se o usuario n?o tiver suporte a JavaScript  
          porisso eu coloquei return false no form o php enviar sozinho   */
}
//
///   Tempo para fechar o site
// var timer;
// function timedClose() {
        //  clearTimeout(timer);
        //  timer = setTimeout("dochange('Sair')",tempo_exec);
        //  timer = setTimeout("dochange('Sair')",180000);
        //	return;
// }  
//  Final do timedClose
//
</script>
