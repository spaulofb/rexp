<?php
   /*  Tabela 1  */
?>
<p>msg_ok = <?php print $_SESSION["msg_ok"]; ?></p>
<table width="200" border="1" align="center" cellpadding="1" cellspacing="1"  class="tabela1">
  <tr>
    <th colspan="3" >Fazendo um teste - clicou em <?=$parte; ?></th>
    </tr>
  <tr>
    <td>1</td>
    <td>2</td>
    <td>3</td>
  </tr>
  <tr>
    <td>4</td>
    <td>5</td>
    <td>6</td>
  </tr>
</table>