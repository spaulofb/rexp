<!DOCTYPE html PUBLIC �-//W3C//DTD XHTML 1.0 Strict//EN�
 �http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd�>
 <html xmlns=�http://www.w3.org/1999/xhtml�>
 <head>
 <meta http-equiv="content-type"  content="text/html; charset=iso-8859-1"  />
  <title>Escrevendo na vertical para IE � aprendacss.wordpress.com </title>
  <style type=�text/css�>
 
 .verticalText{
   font-family:Arial,Helvetica,sans-serif;
   color:#000000;
   font-size:12px;
   writing-mode: tb-rl; filter: flipv(); fliph();
  }
 
 table tr th, table tr td {
   border: 1px solid #000;
  }
 
 table {
   border-collapse: collapse;
  }
 
 </style>
 </head>
 <body>
  <table>
   <tr>
    <th><span>Coluna 1</span></th>
    <th><span>Coluna 2</span></th>
    <th><span>Coluna 3</span></th>
    <th><span>Coluna 4</span></th>
    <th><span>Coluna 5</span></th>
   </tr>
   <tr>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
   </tr>
  </table>
 </body>
 </html>
