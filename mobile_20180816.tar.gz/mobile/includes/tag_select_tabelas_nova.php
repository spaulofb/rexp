<?php
//  Verificando se sseion_start - ativado ou desativado
if( !isset($_SESSION)) {
    session_start();
}
///   Arquivo para a Tag Select das Tabelas: Instituicao, Unidade, Depto, pessoa, categoria
$num_campos=mysql_num_fields($result);
if( intval($num_campos)==1 ) {
   $cpo_nome_descr=mysql_field_name($result,0);        
} elseif( intval($num_campos)>1 ) {
     $codigo_sigla=mysql_field_name($result,0);
     $cpo_nome_descr=mysql_field_name($result,1);
}
/*
while($linha=mysql_fetch_array($result)) {       
      //  htmlentities - o melhor para transferir na Tag Select
      $sigla= htmlentities($linha['sigla']);  
	  $nome= htmlentities($linha['nome']);  
      echo "<option  value=".urlencode($linha['sigla'])."  "
		      ."  title='$sigla - $nome'  >";
      echo  "&nbsp;".$linha['sigla']."&nbsp;</option>" ;
}
*/
while($linha=mysql_fetch_array($result)) {       
      ///  htmlentities - o melhor para transferir na Tag Select  
	  $nome= htmlentities($linha[$cpo_nome_descr]);  
      if( intval($num_campos)>1 ) {
          $sigla= htmlentities($linha[$codigo_sigla]);  
           echo "<option  value=".urlencode($linha[$codigo_sigla])."  "
              ."  title='$sigla - $nome'  >";
           $descricao = $sigla;         
      } 
      if( intval($num_campos)==1 ) {
           echo "<option  value=".urlencode($linha[$nome])."  "
              ."  title='$nome'  >";
           $descricao = $nome;         
      }    
     ////
     if( isset($_SESSION["onsubmit_tabela"]) ) {
         /*   Alterado em 20170123  - Em vez de nome passando para sigla    */
         ///  if( strtoupper(trim($_SESSION["onsubmit_tabela"]))=="PESSOAL" ) $descricao = $nome; 
        ////// $descricao = $sigla; 
         if( strtoupper(trim($_SESSION["onsubmit_tabela"]))=="PESSOAL" ) {
             if( isset($_SESSION["siglaounome"]) ) {
                 $siglaounome=$_SESSION["siglaounome"];
                 if( strtoupper($siglaounome)=="CATEGORIA" )  $descricao = $nome; 
             }
         }
     } 
     echo  $descricao."</option>" ;
}
?>