<?php
     //  Aviso da pagina em construcao
?>
<table width="100%" border="1" cellspacing="2" cellpadding="1" height="100%">
  <tr>
    <td  class="titulo_usp" align="center"  style="width: 100%;  font-size: 40px;" >Em</td>
	</tr>
	<tr>
	    <td  class="titulo_usp" align="center"  style="width: 100%;  font-size: 40px;" >Constru&ccedil;&atilde;o</td>
  </tr>
</table>
