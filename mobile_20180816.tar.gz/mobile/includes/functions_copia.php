<?php
function get_ftp_mode($file) {   
    $path_parts = pathinfo($file);
	
    if ( !isset($path_parts['extension']) ) return FTP_BINARY;
    switch (strtolower($path_parts['extension'])) {
        case 'am':case 'asp':case 'bat':case 'c':case 'cfm':case 'cgi':case 'conf':
        case 'cpp':case 'css':case 'dhtml':case 'diz':case 'h':case 'hpp':case 'htm':
        case 'html':case 'in':case 'inc':case 'js':case 'm4':case 'mak':case 'nfs':
        case 'nsi':case 'pas':case 'patch':case 'php':case 'php3':case 'php4':case 'php5':
        case 'phtml':case 'pl':case 'po':case 'py':case 'qmail':case 'sh':case 'shtml':
        case 'sql':case 'tcl':case 'tpl':case 'txt':case 'vbs':case 'xml':case 'xrc':
            return FTP_ASCII;
    }
    return FTP_BINARY;
}
//
//   extract: Importa vari�veis para a tabela de s�mbolos a partir de um array 
//   extract($_POST, EXTR_OVERWRITE);  
function mime_type($file) {
        
        $filetype = substr(strrchr($file,'.'),1);
        
        $mimetypes = array(
                        "ez" => "application/andrew-inset",
                        "atom" => "application/atom+xml",
                        "hqx" => "application/mac-binhex40",
                        "cpt" => "application/mac-compactpro",
                        "doc" => "application/msword",
                        "lha" => "application/octet-stream",
                        "lzh" => "application/octet-stream",
                        "exe" => "application/octet-stream",
                        "so" => "application/octet-stream",
                        "dms" => "application/octet-stream",
                        "class" => "application/octet-stream",
                        "bin" => "application/octet-stream",
                        "dll" => "application/octet-stream",
                        "oda" => "application/oda",
                        "pdf" => "application/pdf",
                        "ps" => "application/postscript",
                        "eps" => "application/postscript",
                        "ai" => "application/postscript",
                        "smi" => "application/smil",
                        "smil" => "application/smil",
                        "mif" => "application/vnd.mif",
                        "xls" => "application/vnd.ms-excel",
                        "ppt" => "application/vnd.ms-powerpoint",
                        "wbxml" => "application/vnd.wap.wbxml",
                        "wmlc" => "application/vnd.wap.wmlc",
                        "wmlsc" => "application/vnd.wap.wmlscriptc",
                        "bcpio" => "application/x-bcpio",
                        "vcd" => "application/x-cdlink",
                        "pgn" => "application/x-chess-pgn",
                        "cpio" => "application/x-cpio",
                        "csh" => "application/x-csh",
                        "dir" => "application/x-director",
                        "dxr" => "application/x-director",
                        "dcr" => "application/x-director",
                        "dvi" => "application/x-dvi",
                        "spl" => "application/x-futuresplash",
                        "gtar" => "application/x-gtar",
                        "gz" => "application/x-gzip",
                        "hdf" => "application/x-hdf",
                        "php" => "application/x-httpd-php",
                        "phps" => "application/x-httpd-php-source",
                        "js" => "application/x-javascript",
                        "skm" => "application/x-koan",
                        "skt" => "application/x-koan",
                        "skp" => "application/x-koan",
                        "skd" => "application/x-koan",
                        "latex" => "application/x-latex",
                        "cdf" => "application/x-netcdf",
                        "nc" => "application/x-netcdf",
                        "sh" => "application/x-sh",
                        "shar" => "application/x-shar",
                        "swf" => "application/x-shockwave-flash",
                        "sit" => "application/x-stuffit",
                        "sv4cpio" => "application/x-sv4cpio",
                        "sv4crc" => "application/x-sv4crc",
                        "tar" => "application/x-tar",
                        "tcl" => "application/x-tcl",
                        "tex" => "application/x-tex",
                        "texi" => "application/x-texinfo",
                        "texinfo" => "application/x-texinfo",
                        "roff" => "application/x-troff",
                        "t" => "application/x-troff",
                        "tr" => "application/x-troff",
                        "man" => "application/x-troff-man",
                        "me" => "application/x-troff-me",
                        "ms" => "application/x-troff-ms",
                        "ustar" => "application/x-ustar",
                        "src" => "application/x-wais-source",
                        "xht" => "application/xhtml+xml",
                        "xhtml" => "application/xhtml+xml",
                        "zip" => "application/zip",
                        "au" => "audio/basic",
                        "snd" => "audio/basic",
                        "midi" => "audio/midi",
                        "kar" => "audio/midi",
                        "mid" => "audio/midi",
                        "mp3" => "audio/mpeg",
                        "mp2" => "audio/mpeg",
                        "mpga" => "audio/mpeg",
                        "aifc" => "audio/x-aiff",
                        "aif" => "audio/x-aiff",
                        "aiff" => "audio/x-aiff",
                        "m3u" => "audio/x-mpegurl",
                        "rm" => "audio/x-pn-realaudio",
                        "ram" => "audio/x-pn-realaudio",
                        "rpm" => "audio/x-pn-realaudio-plugin",
                        "ra" => "audio/x-realaudio",
                        "wav" => "audio/x-wav",
                        "pdb" => "chemical/x-pdb",
                        "xyz" => "chemical/x-xyz",
                        "bmp" => "image/bmp",
                        "gif" => "image/gif",
                        "ief" => "image/ief",
                        "jpe" => "image/jpeg",
                        "jpeg" => "image/jpeg",
                        "jpg" => "image/jpeg",
                        "png" => "image/png",
                        "tif" => "image/tiff",
                        "tiff" => "image/tiff",
                        "djvu" => "image/vnd.djvu",
                        "djv" => "image/vnd.djvu",
                        "wbmp" => "image/vnd.wap.wbmp",
                        "ras" => "image/x-cmu-raster",
                        "pnm" => "image/x-portable-anymap",
                        "pbm" => "image/x-portable-bitmap",
                        "pgm" => "image/x-portable-graymap",
                        "ppm" => "image/x-portable-pixmap",
                        "rgb" => "image/x-rgb",
                        "xbm" => "image/x-xbitmap",
                        "xpm" => "image/x-xpixmap",
                        "xwd" => "image/x-xwindowdump",
                        "igs" => "model/iges",
                        "iges" => "model/iges",
                        "mesh" => "model/mesh",
                        "silo" => "model/mesh",
                        "msh" => "model/mesh",
                        "vrml" => "model/vrml",
                        "wrl" => "model/vrml",
                        "css" => "text/css",
                        "htm" => "text/html",
                        "html" => "text/html",
                        "asc" => "text/plain",
                        "txt" => "text/plain",
                        "rtx" => "text/richtext",
                        "rtf" => "text/rtf",
                        "sgml" => "text/sgml",
                        "sgm" => "text/sgml",
                        "tsv" => "text/tab-separated-values",
                        "wml" => "text/vnd.wap.wml",
                        "wmls" => "text/vnd.wap.wmlscript",
                        "etx" => "text/x-setext",
                        "xml" => "text/xml",
                        "xsl" => "text/xml",
                        "mpe" => "video/mpeg",
                        "mpeg" => "video/mpeg",
                        "mpg" => "video/mpeg",
                        "mov" => "video/quicktime",
                        "qt" => "video/quicktime",
                        "mxu" => "video/vnd.mpegurl",
                        "avi" => "video/x-msvideo",
                        "movie" => "video/x-sgi-movie",
                        "ice" => "x-conference/x-cooltalk"
                         );

         //  return implode('', array_keys(array_flip($mimetypes),$filetype));
		 return  $filetype." => ".$mimetypes[$filetype];
}
//  Definindo o tamanho do arquivo
function tamanho_arquivo($valor) {
	$i=0;
	$tipos = array("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");
	while( ($valor/1024)>1 ) {
	    $valor=$valor/1024;
	    $i++;
	}
	//  return substr($valor,0,strpos($valor,'.')+4)."&nbsp;".$tipos[$i];
     return substr($valor,0,strpos($valor,',')+4)."&nbsp;".$tipos[$i];
	 
	 /*
      echo tamanho_arquivo(filesize("/tmp/spfbezer/downloads.zip"));
     */
}
//  Corrigindo o campo  username/login 
function isUserID($username) {
    if (preg_match('/^[a-z\d_]{5,20}$/i', $username)) {
        return true;
    } else {
        return false;
    }
}   
//
?>