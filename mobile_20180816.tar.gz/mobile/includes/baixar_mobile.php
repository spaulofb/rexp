<?php
///  Alterado em 20180725
///  require('../inicia_conexao.php');
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
/// IMPORTANTE: para acentuacao php
header("Content-type: text/html; charset=utf-8");

//// Mensagens para enviar
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";
///   FINAL - Mensagens para enviar

///
extract($_POST, EXTR_OVERWRITE); 
///
///  Verificando SESSION incluir_arq - 20180618
$n_erro=0; $incluir_arq="";
if( ! isset($_SESSION["incluir_arq"]) ) {
     $msg_erro .= "Sessão incluir_arq não está ativa.".$msg_final;  
    ///  echo $msg_erro;
    ///  exit();
    $n_erro=1;
} else {
    $incluir_arq=trim($_SESSION["incluir_arq"]);    
}
if( strlen($incluir_arq)<1 ) $n_erro=1;
///
///   CASO OCORREU ERRO GRAVE
if( intval($n_erro)>0 ) {
     $msg_erro .= "Erro ocorrido na parte: $n_erro.".$msg_final;  
     echo $msg_erro;
     exit();
}
/***
*    Caso NAO houve ERRO  
*     INICIANDO CONEXAO - PRINCIPAL
***/
require_once("{$_SESSION["incluir_arq"]}inicia_conexao.php");

///
/// Define o tempo m?ximo de execu??o em 0 para as conex?es lentas
set_time_limit(0);

//  $pasta = '/tmp/spfbezer';
/*  $regs = explode("/",$_GET['file']);
   $pasta = "/".$regs[1]."/".$regs[2]."/";
   $_GET['file']=str_ireplace($pasta,"",$_GET['file']);

   Convertendo arquivo com letras maiusculas para minusculas:
     
   for arq in `ls *.*`; do mv $arq `echo $arq | tr  [:upper:] [:lower:] `; done
   ou
    for arq in `ls *.*`; do mv $arq `echo $arq | tr  A-Z a-z`; done
*/
//  $output = shell_exec('for arq in `ls '.$pasta.'/*.*`; do mv $arq `echo $arq | tr  [:upper:] [:lower:] `; done');
if( isset($_GET["pasta"]) ) {
  $pasta = $_GET["pasta"];    
} elseif( isset($_POST["pasta"]) ) {
   $pasta =  $_POST["pasta"]; 
}
// if( isset($_GET['file']) && file_exists("{$pasta}/".$_GET['file']) ) {
//  echo "\$_GET[pasta] = ".$_GET[pasta]."  -  \$_GET[file] = ".htmlentities($_GET[file]);
// exit();
//  if( isset($_GET['file']) && file_exists($_GET['file']) ) {
if( isset($_GET['file']) && file_exists("{$pasta}".$_GET['file']) ) {
        //  $file = html_entity_decode($_GET[file]);
        $file = htmlspecialchars($_GET['file']);
        $type = filetype("{$pasta}{$file}");
        $size = filesize("{$pasta}{$file}");
        header("Pragma: public"); // required
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false); // required for certain browsers 
		header("Content-Description: File Transfer");
        header('Content-Type: text/plain; charset=ISO-8859-1');
		header("Content-type: application/save");
		header("Content-Type: {$type}");
		header("Content-Length: {$size}");
	//	header("Content-Disposition: attachment; filename=$file");
        header('Content-Disposition: attachment; filename='. basename("{$pasta}{$file}"));

		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Expires: 0');

        readfile("{$pasta}{$file}");
		exit();	
} 

?>