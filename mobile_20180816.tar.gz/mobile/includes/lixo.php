<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Lang" content="en">
<meta name="author" content="">
<meta http-equiv="Reply-to" content="@.com">
<meta name="generator" content="PhpED 6.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="creation-date" content="06/01/2011">
<meta name="revisit-after" content="15 days">
<style type="text/css">
div.scrollTable{
    background: #ffffff;
    border: 1px solid#888;
}

div.scrollTable table.header, div.scrollTable div.scroller table{
      width:100%; 
      _width:100%; 
/*    width:1000px;
    _width:1000px;
    */
    border-collapse: collapse;
}

div.scrollTable table.header th, div.scrollTable div.scroller table td{
    border: 1px solid #444;
    padding: 3px 5px;
    font-family: "Times New Roman", Times,  Arial, Geneva, Helvetica, sans-serif, 'Courier New', Courier, monospace, Verdana,   Garamond, Georgia, serif;
}

div.scrollTable table.header th{
    background: #ddd;
}

div.scrollTable div.scroller{
    height: 200px;
    overflow: auto;
 }

div.scrollTable .coluna75px{
    width: 75px;
}

div.scrollTable .coluna100px{
    width: 100px;
}

div.scrollTable .coluna150px{
    width: 150px;
}
</style>
<title>Untitled</title>
<link rel="stylesheet" type="text/css" href="my.css">
<script type="text/javascript">
function tiraracento(variavel)  {
          /// Alterando acentos em UTF-8
          var map = array(
                    '�' => 'a',
                    '�' => 'a',
                    '�' => 'a',
                    '�' => 'a',
                    '�' => 'e',
                    '�' => 'e',
                    '�' => 'e',                    
                    '�' => 'i',
                    '�' => 'i',                    
                    '�' => 'o',
                    '�' => 'o',
                    '�' => 'o',
                    '�' => 'o',                    
                    '�' => 'u',
                    '�' => 'u',
                    '�' => 'c',
                    '�' => 'A',
                    '�' => 'A',
                    '�' => 'A',
                    '�' => 'A',
                    '�' => 'E',
                    '�' => 'E',
                    '�' => 'I',
                    '�' => 'O',
                    '�' => 'O',
                    '�' => 'O',
                    '�' => 'U',
                    '�' => 'U',
                    '�' => 'C',
                    '�' => 'N',
                    '�' => 'n',
                    '�' => 'Y',
                    '�' => 'y'
          );
          ////
          return strtr(variavel, map);  //// funciona corretamente
       ///      
}
///
</script>
</head>
<body>
<?php

$a="Sim�es A��es"; 

$array_cps_largura= array("NUMPROJETO" => 80, "NR" => 92, "T�TULO" => 600, "DETALHES" => 70, "DATA" => 90 );
$_SESSION["NUMPROJETO"]=$array_cps_largura['NUMPROJETO'];
$NUMPROJETO=$array_cps_largura['NUMPROJETO'];
echo "\$_SESSION[NUMPROJETO] = {$_SESSION["NUMPROJETO"]} <br>";    
?>
<p>1 - <?php   echo "html_entity_decode = ".html_entity_decode($a);?></p>
<p>2 - <?php   echo  "urlencode = ".urlencode($a);?></p>
<p>3 - <?php   echo  "htmlentities = ".htmlentities($a);?></p>
<p>4 - <?php   echo  "htmlspecialchars = ".htmlspecialchars($a);?></p>
<p>999 - <?php   echo "\$a = ".$a;?></p>
<script type="text/javascript">
   var b = "<?php echo $a;?>";
  alert(" a = "+b);
</script>

<div class="scrollTable">
    <table class="header">
        <tr>
            <th class="scrollTable" style="width:<?php echo $NUMPROJETO;?>px;text-align: justify;" >Nr/Projeto</th>
            <th style="width:<?php echo $array_cps_largura['NR'];?>px;" >Nr/Anota��o</th>
            <th style="width:<?php echo  $array_cps_largura['T�TULO'];?>px;">T�tulo/Anota��o</th>
            <th style="width:<?php echo  $array_cps_largura['DETALHES'];?>px;text-align: center;">Detalhes</th>
            <th style="width:<?php echo  $array_cps_largura['DATA'];?>px;text-align: center;">Data</th>
            <th></th>
        </tr>
    </table>
    <div class="scroller">
        <table>
            <tr>
            <td class="scrollTable" style="width:<?php echo $NUMPROJETO;?>px;text-align: right;" >11</td>
            <td style="width:<?php echo $array_cps_largura['NR'];?>px;" >125</td>
            <td style="width:<?php echo $array_cps_largura['T�TULO'];?>px;">T�tulo/Anota��o Feito na Anota��o Desenvolvido</td>
            <td style="width:<?php echo $array_cps_largura['DETALHES'];?>px;text-align: center;">Detalhes</td>
            <td style="width:<?php echo $array_cps_largura['DATA'];?>px;font-weight: bold;text-align: center;">25/11/2011</td>
           <td>&nbsp;</td>
            </tr>
        </table>
    </div>
</div> 
<br>
<div class="scrollTable">
    <table class="header">
        <tr>
            <th class="scrollTable" style="width:1%;text-align: justify;" >Nr/Projeto</th>
            <th style="width:2%;" >Nr/Anota��o</th>
            <th style="width:50%;">T�tulo/Anota��o</th>
            <th style="width:5%;text-align: center;">Detalhes</th>
            <th style="width:5%;text-align: center;">Data</th>
            <th></th>
        </tr>
    </table>
    <div class="scroller">
        <table>
            <tr>
            <td class="scrollTable" style="width:1%;text-align: right;" >11</td>
            <td style="width:2%;" >125</td>
            <td style="width:50%;">T�tulo/Anota��o Feito na Anota��o Desenvolvido</td>
            <td style="width:5%;text-align: center;">Detalhes</td>
            <td style="width:5%;font-weight: bold;text-align: center;">25/11/2011</td>
           <td>&nbsp;</td>
            </tr>
        </table>
    </div>
</div> 
<?php
/*
ob_start();  /// start reading the internal buffer
exec('ls -altsh /tmpe/',$output);
////  var_dump($output);          
var_dump(isset($output));          
$resultado = ob_get_contents(); /// assigning the internal buffer contents to variable
ob_end_clean(); 
echo "<br/><br/>".strlen($resultado)."<br/> $resultado  --->>> ".count($resultado)."<br/>";
*/
$cmd='ls -altsh /tmpe/';
exec($cmd."2>&1",$output);
exec($cmd . " 2>&1", $output);
var_dump($output); // $results now contains output from print_r
////  echo  "<br/><br/>--->>>  $results = $results   ".sizeof($results);
    
?>

</body>
</html>
