<?php
/*
*   REXP - REGISTRO DE EXPERIMENTO - ANOTAÇÃO DE PROJETO
* 
*       MODULO: index 
*  
*   LAFB/SPFB110827.1708 - Correções gerais

header("Pragma: no-cache");
header("Cache: no-cache");
header("Cache-Control: no-cache, must-revalidate");
*/
//  Verificando se sseion_start - ativado ou desativado
if( !isset($_SESSION)) {
     session_start();
}
//  Navegador permitido
require_once('php_include/ajax/includes/navegador_permitido.php');
// extract: Importando variáveis POST para a tabela de símbolos a partir de um array 
extract($_POST, EXTR_OVERWRITE); 
//
$eliminar=0;
if( isset($parte1) &&  isset($parte2) ) {
    if( $parte1!=$parte2 ) $eliminar=1;
}
if( $eliminar==1 ) exit();
// Eliminar todas as variaveis de sessions
if( ! isset($_POST["userid"]) ) {
  //  $_SESSION = array();
    //  session_destroy();
    if( isset($total) ) unset($total);
    if( isset($login_down) ) unset($login_down); 
    if( isset($senha_down) ) unset($senha_down); 
    if( isset($parte1) ) unset($parte1); 
    if( isset($parte2) ) unset($parte2); 

    /*
    if( isset($_POST) ) {
       $_POST = array();
       unset($_POST);     
    } 
    */     
}
//  PA - Ususarios 
$elemento=5; $elemento2=6;
require_once('php_include/ajax/includes/tabela_pa.php');
if( isset($_SESSION["array_pa"]) ) {
   $array_pa=$_SESSION["array_pa"];      
   $_POST["array_pa"]=$_SESSION["array_pa"];       
} 
//  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anotação";
//  Menu Horizontal
include_once("includes/array_menu.php");
// unset($_SESSION["m_horiz"]);
$_SESSION["m_horiz"] = $array_voltar;
//
//  email GEMAC  atual
//  $_SESSION["gemac"]='bezerralaf@gmail.com; spfbezer@fmrp.usp.br';
$_SESSION["gemac"]='gemac@sol.fmrp.usp.br';
//
//  INICIANDO COOMO CAMINHO PRINCIPAL - ATENCAO
$_SESSION["pasta_raiz"]="/rexp/";
$_SESSION["incluir_arq"]="/var/www/html{$_SESSION["pasta_raiz"]}";
//
//
?>
<!DOCTYPE html>
<html lang="pt-br" >
<head>
<meta charset="UTF-8" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<meta NAME="ROBOTS" CONTENT="all" > 
<meta HTTP-EQUIV="Expires" CONTENT="0" >
<meta NAME="GOOGLEBOT" CONTENT="NOARCHIVE"> 
<!--  <meta http-equiv="refresh" content="380"  />  -->
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<meta HTTP-EQUIV="REFRESH"  CONTENT="900" >
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RGE/SISTAM - Anotação de Projeto</title>
<link type="text/css" href="css/estilo.css" rel="stylesheet"  />
<link  type="text/css"   href="css/style_titulo.css" rel="stylesheet"  />
<script type="text/javascript" src="js/resize.js" ></script>
<script type="text/javascript" src="js/functions.js" ></script>
<script type="text/javascript" src="js/XHConn.js"  ></script>
<style type="text/css">
input{
       border:1px solid #CCCCCC; 
      cursor:pointer;
      padding:1px;
 }
fieldset,#inclusao   {
      margin:0px auto;
      width:25%;
}

#inclusao  {
	    margin:0px auto;
    	font-size: small; font-weight: bold;
        width :50%;
}
.label_campos { padding: 2px; vertical-align:bottom; font-size: medium; cursor: pointer;  }

</style>
<script type="text/javascript"  >
/*
     Aumentando a Janela no tamanho da resolucao do video
     Melhor jeito para todos os navegadores
     fazer logo quando inicia a pagina
*/
self.moveTo(-4,-4);
self.moveTo(0,0);
self.resizeTo(screen.availWidth + 8,screen.availHeight + 8);
//  self.resizeTo(1000,1000);
self.focus();
//
//   Verificando qual a resolucao do tela - tem que ser no minimo 1024x768
if ( screen.width<1024 ) {
    alert("A resolução da tela do seu monitor para esse site é\n RECOMENDÁVEL no mínimo  1024x768 ")
}
//   Verificando se o POP-UP esta desativado
//  var pop = window.open("about:blank","_blank","width=10,height=100,top=0,left=0");
/*
var pop = window.open("testa_popup.html","_blank","width=10,height=100,top=0,left=0");
if( null==pop || true==pop.closed) {
  h = 1;
  // document.write("ATENÇÃO! Eliminador de popups!");
  alert("ATENÇÃO! Desativar Bloqueador de POP-UP para esse Site.");
} 
*/
//
function doaction(tcaction)  {
/*
      Funcao Principal para preparação da ação necessária para enviar dados via AJAX

        tcaction = {"Submit";"Reset"}
*/
  var lcaction = tcaction.toUpperCase();
  //
  switch (lcaction) {
    case "SAIR":
        //  Sair do Site fechando a Janela
        var is_chrome = navigator.userAgent.toLowerCase().indexOf('chrome'); 
        var is_firefox = navigator.userAgent.toLowerCase().indexOf('firefox'); 
        var navegador =navigator.appName;
        var pos = navegador.search(/microsoft/gi);
        //  if( pos!=-1 ) {
        //  if( navegador.search(/microsoft/gi)!=-1 ) {        
        if( is_firefox!=-1 ) {
               //  Sair da pagina e ir para o Site da FMRP/USP
               ///  location.replace('http://www.fmrp.usp.br/');                
               location.replace('reiniciar.php');                
        } else if( is_chrome!=-1  || pos!=-1  ) {
             // 20120912 - Melhor opcao para  sair do Chrome
             location.replace('reiniciar.php');                
              window.open('', '_self', ''); // bug fix
              window.close();            
        }
        return;
        break;
    case "VOLTAR":  
       //  Voltar para a pagina inicial
       location.replace('http://sol.fmrp.usp.br/rexp');                
       return;      
       break;
    case "SUBMIT":
        m_login_down = document.getElementById("userid").value;
        m_senha_down = document.getElementById("userpassword").value;        
        m_confirm = document.getElementById("confirm").value;
        m_cod_img = document.getElementById("magica").value;  
        var poststr="login_down="+encodeURIComponent(m_login_down)+
            "&senha_down="+encodeURIComponent(m_senha_down)+"&codigo_down="+
            encodeURIComponent(m_confirm)+"&m_onload="+encodeURIComponent(lcaction)+
            "&m_cod_img="+encodeURIComponent(m_cod_img);
        var id_incluir = "inclusao";
        /*  
            Criando a classe de conexão AJAX  
        */
        var myConn = new XHConn();
        if ( !myConn ) {
            alert("XMLHTTP/AJAX não disponível. Tente um navegador mais novo ou melhor.");
            return false;
        }
       //
       //   Parâmetro identificando o procedimento a ser executado pelo AJAX:
        var receber_dados = "authent_user_ajax.php";
        //
        //  Função de processamento de resultados do AJAX:
        var inclusao = function (oXML) { 
            var dados_recebidos =  oXML.responseText;
            document.getElementById('label_msg_erro').style.display="none";
            var pos = dados_recebidos.search(/Nenhum|Erro/i);  
            if( pos!=-1 ) {
                  if( document.getElementById('conteudo') ) {
                      document.getElementById('conteudo').style.display="none";
                      document.getElementById('conteudo').innerHTML="";
                  }
                  //
                  if( document.getElementById('inclusao') ) {
                      document.getElementById('inclusao').style.display="none";
                      document.getElementById('inclusao').innerHTML="";                                       
                 }    
                 //
                 document.getElementById('label_msg_erro').style.display="block";
                 document.getElementById('label_msg_erro').innerHTML=dados_recebidos;
            } else {
                var pos_iniciar = dados_recebidos.search(/iniciando/i);
                if( pos_iniciar != -1 ) {
                    id_conteudo("Iniciar","iniciar",dados_recebidos);    
                } else {
                    var pos = dados_recebidos.search(/logar/i);
                    if( pos==-1  ) {
                        document.getElementById('inclusao').style.display="block";
                        document.getElementById('inclusao').innerHTML= dados_recebidos;    
                        //  Verificando se tem erros nos campos 
                        var poserro = dados_recebidos.search(/ERRO:|NENHUM/i);
                        //  Encontrou ERRO                                           
                        if( poserro!=-1  ){
                            if( document.getElementById("userid") ) {
                                document.getElementById("userid").onfocus();   
                            }
                        }
                        //
                    } else {
                        if( document.getElementById('conteudo') ) {
                            document.getElementById('conteudo').style.display="block";
                            document.getElementById('conteudo').innerHTML="";
                        }
                        if( document.getElementById('inclusao') ) {
                            document.getElementById('inclusao').style.display="block";
                            document.getElementById('inclusao').innerHTML= dados_recebidos;                                       
                        }    
                    }                                
                }                             
            }
        };              
        /*  enviando para pagina receber.php usando metodo post, + as variaveis, valores e a funcao   */
        //  myConn.connect("receber.php", "POST", poststr, inclusao); 
        myConn.connect(receber_dados, "POST", poststr, inclusao); 
        break;
    //
    case "RESET":

  //  alert("doaction/RESET="+lcaction)  ;

        var poststr = "m_onload="+encodeURIComponent(m_onload);
        var id_incluir = "codigo_img";
        document.getElementById("codigo_img").src = "imagens/loading.gif";
        /*  
            Criando a classe de conexão AJAX  
        */
        var myConn = new XHConn();
        if ( !myConn ) {
            alert("XMLHTTP/AJAX não disponível. Tente um navegador mais novo ou melhor.");
            return false;
        }
       //
       //   Parâmetro identificando o procedimento a ser executado pelo AJAX:
        var receber_dados = "authent_user_ajax.php";
        //
        //  Função de processamento de resultados do AJAX:
        var inclusao = function (oXML) { 
            var palavras = oXML.responseText;
                                           
           // alert("authent_user.php/152  -- palavrras =  "+palavras);

            var partes= palavras.split("#");
            var cod_img_src = partes[0];  var cod_img_value = partes[1];
            //  document.getElementById('codigo_img').src = oXML.responseText; 
            //  document.getElementById("codigo_img").src = partes[0] ;
            //  document.getElementById("codigo_img").setAttribute('src',partes[0]);
            document.getElementById("codigo_img").setAttribute('src',cod_img_src);
            //  document.getElementById("codigo_img").src = partes[0] ;
            //  aqui a input hidden de id="dados" recebe um valor 
            //  dinâmicamente  via código Javascript:  cria um objeto de
            // referência à tag input hidden
            if( document.getElementById("magica")  ) {
                var objetoDados = document.getElementById("magica");
                //  altera o atributo value desta tag
                //  objetoDados.value = partes[1]; 
                objetoDados.value = cod_img_value;                                    
            }
            return;
        }; 
        /*  enviando para pagina receber.php usando metodo post, + as variaveis, valores e a funcao   */
        //  var conectando_dados = myConn.connect("receber.php", "POST", poststr, inclusao);   
        var conectando_dados = myConn.connect(receber_dados, "POST", poststr, inclusao);   
        //  sleep(5000);
        break;
      //
    default:

       alert("CASE/default"+lcaction) ;
       break;
  
  }  //  Final do switch
   //
} // FInal da function doaction
//
//  
function pa_selecionado(opcao,valor)  {
  //
  var ativar_maiusc = opcao.toUpperCase();
  
// alert("authent_user.php#301  ativar_maiusc = "+ativar_maiusc+" ---  valor  =  "+valor)                              
  //
  var m_teste = valor.toUpperCase();
  //  
  //
  if( ativar_maiusc=="PA_SELECIONADO" ) {
       m_login_down = document.getElementById("userid").value;
       m_senha_down = document.getElementById("userpassword").value;        
       var poststr="opcao="+encodeURIComponent(ativar_maiusc)+"&permit_pa="+encodeURIComponent(valor)+"&login_down="+
            encodeURIComponent(m_login_down)+"&senha_down="+encodeURIComponent(m_senha_down);      
     // var id_incluir = "inclusao";
  }
  
   /*  aqui eu chamo a class  */
   var myConn = new XHConn();
        
   /* Um alerta informando da não inclusão da biblioteca  */
   if ( !myConn ) {
         alert("XMLHTTP não disponível. Tente um navegador mais novo ou melhor.");
         return false;
   }
   //
   //   var receber_dados = pa_selecionado_ajax.php -> Depois que selecionou um PA dos varios
   var receber_dados = "pa_selecionado_ajax.php";
   var inclusao = function (oXML) { 
             var dados_recebidos =  oXML.responseText;
             document.getElementById('label_msg_erro').style.display="none";
             var pos = dados_recebidos.search(/Nenhum|Erro/i);  
 
// alert("pa_selecionado#289 - pos = "+pos+"  - opcao = "+opcao+"  -- valor =  "+valor+"  -- dados_recebidos =  "+dados_recebidos)  ;                                                 
 
             if( pos!=-1 ) {
                 document.getElementById('label_msg_erro').style.display="block";
                 document.getElementById('label_msg_erro').innerHTML=dados_recebidos;
             } else {
                 if(  ativar_maiusc=="PA_SELECIONADO" ) {
                       var pos = dados_recebidos.search(/iniciando/i);
                        if( pos != -1 ) {
                                //  document.getElementById('inclusao').innerHTML= oXML.responseText;
                                id_conteudo("Iniciar","iniciar",dados_recebidos);    
                        }     
                  }                      
             }
        };              
   /* aqui é enviado mesmo para pagina receber methodo post,+ as variaveis, valores e informar onde vai atualizar */
   //  myConn.connect("receber.php", "POST", poststr, inclusao); 
 
// alert("pa_selecionado#308 - func_exec="+receber_dados+"  - poststr= "+poststr+"  -- inclusao="+inclusao);
 
   myConn.connect(receber_dados, "POST", poststr, inclusao); 
   /*  uma coisa legal nesse script se o usuario não tive suporte a JavaScript  
       porisso eu coloquei return false no form o php enviar sozinho */
   return;     
}  //  Final da Function PA_SELECIONADO
//  Limpar campos
function limpar_campos(tipo) {
    var tipo_maiusc= tipo.toUpperCase();
   	var elements = document.getElementsByTagName("input");
    for (var i = 0; i < elements.length; i++) {
	        var m_id_name = elements.item(i).name;
	        var m_id_type = elements[i].type;
            if(( typeof m_id_name=='undefined' ) || ( typeof m_id_type=='undefined' ) ) continue;
    	    if ( m_id_type=='button' || m_id_type=='image' || m_id_type=='reset' || m_id_type=='submit'  ) continue;
        	var m_id_value =  elements[i].value;
            //  LIMPAR todos os campos ou  usar o  TRIM
			if( tipo=="limpar" ) {
				document.getElementById(m_id_name).value="";
				//  document.getElementById(m_id_name).value="";
			} else if( tipo=="trim" ) {
				document.getElementById(m_id_name).value=trim(document.getElementById(m_id_name).value);
			}
	} 
    //  Limpar essas - DIVs 
    if(  document.getElementById("conteudo") ) document.getElementById("conteudo").style.display="none";
    if(  document.getElementById("inclusao") ) document.getElementById("inclusao").style.display="none";    
	if( tipo_maiusc=="TRIM" ) return true;
	if( tipo_maiusc=="LIMPAR" ) {
       if( document.getElementById("userid") ) document.getElementById("userid").focus();         
    }
	return false;
}   
//
//   Function Verificar  popup bloqueado
function _hasPopupBlocker(poppedWindow) {
    var result = false;
    
    alert(" poppedWindow = "+poppedWindow)

    try {
        if (typeof poppedWindow == 'undefined') {
            // Safari with popup blocker... leaves the popup window handle undefined
            result = true;
            alert("1 - result = "+result)
        }
        else if (poppedWindow && poppedWindow.closed) {
            // This happens if the user opens and closes the client window...
            // Confusing because the handle is still available, but it's in a "closed" state.
            // We're not saying that the window is not being blocked, we're just saying
            // that the window has been closed before the test could be run.
            result = false;
            alert("2 - result = "+result)
        }
        else if (poppedWindow && poppedWindow.test) {
            // This is the actual test. The client window should be fine.
            result = false;
            alert("3 - result = "+result)
        }
        else if ( poppedWindow==null ) {
            //  poppedWindow nulo
            result = true;
            alert("4 - result = "+result)
        }

    } catch (err) {
        //if (console) {
        //    console.warn("Could not access popup window", err);
        //}
    }
    alert("FIM - result = "+result)      
    return result;
}
//
function id_conteudo(ativ_desat,mensag,m_dados) {
    //  Navegador/Browser utilizado
    var navegador =navigator.appName;
    var pos = navegador.search(/microsoft/gi);
    document.getElementById("conteudo").innerHTML="";
    if( ativ_desat=="liga" ) document.getElementById("conteudo").innerHTML=mensag;
    //  Depois qdo foi ACEITO o Usuário 
    if( ativ_desat=="Iniciar" ) {
        limpar_campos("limpar");
        document.getElementById("form").innerHTML="";  //  Deu Certo
        document.getElementById("form").style.display="none";  //  Deu Certo	
        document.getElementById("conteudo").style.display="none";  //  Deu Certo	
        //  Mudando de pagina
        var http_host = m_dados.split("#");
        var LARGURA = screen.width;
        var ALTURA = screen.height;
        /* Caso o navegador nao for microsoft
           var navegador =navigator.appName;
           var pos = navegador.search(/microsoft/gi);
         */           
         
        //  if( pos!=-1 ) {
       // if( navegador.search(/microsoft/gi)!=-1 ) {
       
       //  alert(" http_host[1] = "+http_host[1])
       window.location.replace(http_host[1]);
     
       //     window.open('http://www-gen.fmrp.usp.br','_parent','');window.close(); 
       // } else {
        //   window.close();
       //    var win_new = window.open(http_host[1]); 
       //    win_new.focus();            
       // }   
        return;  
    }	
}
</script>
</head>
<body  onload="javascript: cpo1_focus(document.form);"    oncontextmenu="return false"   
    onselectstart="return false"  ondragstart="return false"  
    onkeydown="javascript: no_backspace(event);"   >
<?php
//  require para o Navegador que nao tenha ativo o Javascript
require("js/noscript.php");
//
include_once("includes/array_menu.php");
$_SESSION["m_horiz"] = $array_sair;
//
?>
<!-- PAGINA -->
<div class="pagina_ini" >
<!-- Cabecalho -->
<div id="cabecalho">
<?php include("script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
$_SESSION["function"]="doaction";
include("includes/menu_horizontal.php");
?>                     
<!-- Final do MENU  --> 
<!-- CORPO -->
<div id="corpo" style="text-align: center; width: 100%;"  >
  <div style="top:0px; margin-top: 0px; padding-top:0px; position:relative; width: 100%; " >
    <?php 
	   // Arquivo para definir o tamanho do texto na pagina
	   include_once("includes/tamanho_texto.php");
    ?>
    <div  id="label_msg_erro" style="display:none; position: relative;width: 100%; text-align: center; overflow:hidden;" >
    </div>
    <form name="form" id="form"   method="post"  onsubmit="javascript: doaction('SUBMIT'); return false;"  >
	 <table class="table_inicio"  align="center"   cellpadding="1"  cellspacing="2" 
	 style="font-weight:normal; font-size-adjust:none; width: 840px; text-align: center; "  >
            <tr   >
              <td  class="td_inicio1" width="20%"   >
              <label for="userid" class="label_campos" title="Digitar email" >Login(Email):&nbsp;</label>
              </td>
			  <td class="td_inicio2"  width="80%" >			  
			  <input type="text" name="userid"  id="userid"  size="100"  required="required"  maxlength="80"  title="Digitar email"  onfocus="javascript: id_conteudo('liga','Digitar email');"   onblur="javascript: id_conteudo('','');"  autocomplete="off"  tabindex="1"  />
               </td>
            </tr>
            <tr  >
              <td  class="td_inicio1"  >
               <label for="userpassword" class="label_campos" >Senha:&nbsp;</label>
               </td  >
			  <td class="td_inicio2" >
			  <input type="password" name="userpassword"   id="userpassword" size="16" maxlength="14"  required="required"  title='Digitar senha'   onfocus="javascript: id_conteudo('liga','Digitar senha');"  onblur="javascript: id_conteudo('','');"  autocomplete="off"  tabindex="2"    />
              </td>
            </tr>
            <tr style="vertical-align: middle;"  >
              <td  class="td_inicio1"  width="100%"  >
			      <img src="captcha_criar.php" alt="código captcha" height="36" width="128"/>
				  <input type="hidden"  id="magica" name="magica" value=""  />
                  </td>
				<td class="td_inicio2"  style="vertical-align: middle;"   >
				  <label  for="confirm" class="label_campos" >C&oacute;digo:&nbsp;</label>
				  <input align="left" name="confirm" type="text" id="confirm" size="8" required="required"
               maxlength="5"   onfocus="javascript: id_conteudo('liga','Digitar c&oacute;digo com 5 caracteres');"
               onblur="javascript: id_conteudo('','');"  title="Digitar c&oacute;digo com 5 caracteres"    autocomplete="off"   style="cursor:pointer;"  tabindex="3"    />		
			  </td>
            </tr>
            <!-- RESET E SUBMIT -->
            <tr align="center" style="border: none; vertical-align: bottom; margin: 0px; padding: 0px;" >
              <td colspan="2" align="CENTER" nowrap style=" vertical-align: bottom; text-align:center; border: none; line-height:0px;">
			  <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 2px 0px 0px 0px;  padding: 0px; width: 100%; line-height: 0px; border: none;" >
			    <tr style="border: none;">
				<td  align="CENTER" nowrap style="text-align:center; border:none;" >
			   <input type="reset"  class="botao3d"   style="font-size: medium;  cursor: pointer; border: none;"  name="limpar" id="limpar" title="Limpar"  acesskey="L"  value="Limpar"  alt="Limpar"  onfocus="javascript: limpar_campos('limpar','Limpar');"  onclick="javascript: doaction('RESET');"   />
               </td>
			   <td  align="center"  style="text-align: center; border:none; ">
			  <input type="submit" class="botao3d"  style="font-size: medium;  cursor: pointer; border:none;" name="enviar" id="enviar" title="Enviar"  acesskey="E"  value="Enviar"  tabindex="4"  alt="Enviar"  onfocus="javascript: id_conteudo('liga','Enviar');" onblur="javascript: id_conteudo('','');"  />
              </td>
			   </tr>                      
			  </table>			  
              </td>
            </tr>
            <tr align="center" style="margin: 0px; border: 1px solid #000000;"  >
              <td  align="center" nowrap style="padding: 4px; text-align: left;  border: none; ">    
               <a href="esqueci_senha.php"  style="text-decoration: none; cursor: pointer;" title="Clicar"  ><span style="color: #000000;"  >Esqueceu a senha?</span> Clique aqui.</a>
            </td>
            <td  align="CENTER" nowrap style=" padding: 4px; text-align:right; border: none; ">    
               <a href="cadastrar_auto_por_email.php"  style="text-decoration: none; cursor: pointer;" title="Clicar" target="_parent"  ><span style="color: #000000;"  >Ainda n&atilde;o &eacute; cadastrado?</span> Clique aqui.</a>
             </td>
            </tr>
         </table>
	  </form>
	    <div id="conteudo" style="text-align: center;" ></div>
        <div id="inclusao" style="text-align: center; display: none; "  ></div>
  </div>
</div>	  
<!-- Final Corpo -->
<!-- Rodape -->
<div id="rodape"  >
<?php include_once("includes/rodape_index.php"); ?>
</div>
<!-- Final do Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>