<?php
/*
        testecharset.html
        
        Copyright 2008 Marco Antonio <coyote@work>
        
        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.
        
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        
        You should have received a copy of the GNU General Public License
        along with this program; if not, write to the Free Software
        Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
        MA 02110-1301, USA.
*/        
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
///
$orderby=" nome desc";
$orderby=preg_replace('/NoMe/i', 'a.nome', $orderby);

echo "<br/> \$orderby = $orderby ";


//// preserve pre tag



/// include('inicia_conexao.php');
$_SESSION["ax"]="OKOK";
$_SESSION["cz"]="DDDDD";

if( isset($ax)  ) session_unregister("ax");

echo "\$_SESSION[ax] = {$_SESSION["ax"]} <br/>";
//////  if( isset($_SESSION["cz"]) ) unset($_SESSION["cz"]);
echo "\$_SESSION[cz] = {$_SESSION["cz"]} ";
////
?>
<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br">

<head>
    <title>sem t�tulo</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="generator" content="Geany 0.13" />

</head>
<body>
    Carro�a Ant�nio v�deo �
    
<?php
$nome="   Abel  Teste  ";
$mlen=strlen($nome);
echo "<br/>1 - $nome -> ".strlen($nome);
$nometrim=trim($nome);
echo "<br/>2 - $nometrim".strlen($nometrim);

echo "<br />";

$texto="'abacaxi'";

echo "<br />1  $texto";
echo "<br />2  ".trim($texto,"'");

$texto2="'abaca''''''xi'";
echo "<br />3  ".trim($texto2,"'");

echo "<br />";

var_dump(checkdate(12,31,-400));
echo "<br>";
var_dump(checkdate(2,29,2003));
echo "<br>";
var_dump(checkdate(2,29,2004));

echo "<br>";
var_dump(checkdate(2,25,0099));
echo "<br/>";

///  function_exists - verifica se a  function function NAO esta ativa
if( ! function_exists("ValidaData") ) {
    /// Verificando a Data 
     function ValidaData($dat){
            ///  Verificando formato da Data com barra
            if( preg_match("/\//",$dat) ) {
                 $data = explode("/","$dat"); ///  Divide  a string $dat em pedados, usando / como refer�ncia
            }
            ///  Verificando formato da Data com hifen
            if( preg_match("/\-/",$dat) ) {
                 $data = explode("-","$dat"); ///  Divide  a string $dat em pedados, usando - como refer�ncia
            }
            $res=1;  ///  1 = true (valida)
            $coluna1=$data[0];
            if( strlen($coluna1)<3 ) {
                $d = $data[0];
                $m = $data[1];
                $y = $data[2];
            } elseif( strlen($coluna1)==4 ) {
                $y = $data[0];
                $m = $data[1];
                $d = $data[2];
            }
            if( intval($y)>2100 ) $res=0;  ///  0 = false (vinalida)
            /*
            $d = $data[0];
            $m = $data[1];
            $y = $data[2];
              */
           /// Veerifica se a data � v�lida!
            /// 1 = true (v�lida)
             /// 0 = false (inv�lida)
             //// if( intval($res)==1 )  $res = checkdate($m,$d,$y);
            if( intval($res)==1 ) {
                 $res = checkdate($m,$d,"20146"); 
            }  
            ///
               if( $res==1 ) {
                    echo "<br/>data ok! dia=$d - mes=$m - ano=$y ";
               } else {
                     echo "<br/>data inv�lida!";
               }
               
            ////
            return $res;
     }
}
////


$data1="02/13/2014";

if( preg_match("/\//",$data1)  ) {
    ///
    $n_barra=substr_count($data1,"/");
    if(  intval($n_barra)==2  ) {
        echo "<br/>OK string symbol / data = $data1  <br/>";        
        
        $data1=preg_replace('/\//','-',$data1);
    } else {
        echo "<br/>ERRO string symbol / data = $data1";        
        break;
    }
       
} 
if( preg_match("/\-/",$data1)  ) { 
    echo "<br/>string symbol - data = $data1";
    $array_data = explode("-","$data1"); ///  Divide  a string $data1 em pedados, usando - como refer�ncia
}


ValidaData($data1);    

echo "<br/><br/>FINAL";

?>

<input type="button"  value="Teste"  title="Clicar" onclick="javascript:  teste();" >

<script type="text/javascript" >
if( typeof(teste)=="function"  )  {
 
  alert("TEM FUNCTION teste");   
    
    teste();
} else { 
    alert("CRIANDO  FUNCTION teste");
    function teste() {
        alert("TUDO CERTO");
    }
}
</script>
</body>
</html>
