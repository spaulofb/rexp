<?php
//  Cadastrar  PATRIMONIO/BEM
//
//  Verificando se sseion_start - ativado ou desativado
if( ! isset($_SESSION)) {
     session_start();
}
//
// Verificando conexao
//
include("{$_SESSION["incluir_arq"]}iniciar_conexao.php");
//  Recebe GET e passa SESSION  - m_nome_id
if( isset($_GET["m_nome_id"]) ) {
    $_SESSION["m_nome_id"]=$_GET["m_nome_id"];
} else {
    $_GET["m_nome_id"]="";
    $_SESSION["m_nome_id"]="";
}
//  Caminho da pagina local
$_SESSION["m_juntos_link"] = "http://{$_SERVER["HTTP_HOST"]}{$_SERVER["SCRIPT_NAME"]}";
//
//  echo "cadastrar_atributo.php23 - \$_SESSION[m_juntos_link] = {$_SESSION["m_juntos_link"]}   ";
//
$_SESSION["div_form"]="block";
///
?>
<!DOCTYPE html>
<html lang="pt-BR" >
<head>
<meta charset="UTF-8" />
<!--  <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" /> -->
<!--  <meta name="language" content="pt-br" /> -->
<meta name="author" content="LAFB&SPFB" />
<!-- <meta HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">  -->
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta name="ROBOTS" content="NONE"> 
<!--  <meta HTTP-EQUIV="Expires" CONTENT="-1" >  -->
<!--  <meta HTTP-EQUIV="Expires" CONTENT="0" >  -->
<meta  name="GOOGLEBOT"  content="NOARCHIVE"> 
<!--  <meta http-equiv="Expires" content="-1">  -->
<meta http-equiv="imagetoolbar"  content="no">  
<title>Controle de Bem Patrimonial</title>
<link rel="shortcut icon" href="../imagens/GEMAC.ICO" type="image/x-icon" />
<title>Controle Patrimonial</title>
<style type="text/css">
/*  Importante para importar no css pastas  */
@import url("<?php echo $_SESSION["url_central"];?>css/estilo_patrimonio.css");
@import url("<?php echo $_SESSION["url_central"];?>css/style_titulo_patrimonio.css");
</style>
<?php
// Buscar  arquivo  js   como  php
include("{$_SESSION["incluir_arq"]}js/jquery-1.2.6.php");
include("{$_SESSION["incluir_arq"]}js/funcoes_js.php");
include("{$_SESSION["incluir_arq"]}js/formata_data_js.php");
include("{$_SESSION["incluir_arq"]}js/cadastrar_patrimonio_js.php");
//  IMPORTANTE para incluir js qdo tiver variavel de PHP
include("{$_SESSION["incluir_arq"]}js/conecta_ajax.php");
// include("{$_SESSION["incluir_arq"]}js/XHConn2.php");
//  Menu Patrimonial - Selecionando Cadastrar, Editar, Consultar e etc...
include("{$_SESSION["incluir_arq"]}js/menu_patrimonial.php");
?>
<script language="JavaScript" type="text/javascript">
/*
     Aumentando a Janela no tamanho da resolucao do video
*/
self.moveTo(-4,-4);
//  self.moveTo(0,0);
self.resizeTo(screen.availWidth + 8,screen.availHeight + 8);
//  self.resizeTo(1000,1000);
self.focus();
//
//   Verificando qual a resolucao do tela - tem que ser no minimo 1024x768
/*
if ( screen.width<1024 ) {
    alert("A resolu��o da tela do seu monitor para esse site �\n RECOMEND�VEL no m�nimo  1024x768 ")
}
*/
//
</script>
</head>
<body  oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"  onkeydown="javascript: no_backspace(event);" >
<?php
include("{$_SESSION["incluir_arq"]}script/abertura_da_pagina.php"); 
if( isset($_GET["m_nome_id"]) ) {
    $_SESSION["m_nome_id"]=$_GET["m_nome_id"];
} else {
    $_SESSION["m_nome_id"]="";
}
/*
   Chamada da fun��o das tabelas - array multidimensional
*/
//  require("{$_SESSION["incluir_arq"]}script/array_multi.php");
//  include("{$_SESSION["incluir_arq"]}script/array_multi.php");
$_SESSION["m_editando"]=false;
//  Require para o Navegador que nao tenha ativo o Javascript
//   Posicao do arquivo noscript.php tem que ser depois da tag  BODY
//  require("{$_SESSION["incluir_arq"]}js/noscript.php");
include("{$_SESSION["incluir_arq"]}js/noscript.php");
//  Menu Horizontal
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
// unset($_SESSION["m_horiz"]);
$_SESSION["m_horiz"] = $array_patrimonial;
//  INCLUINDO CLASS - 
include("{$_SESSION["incluir_arq"]}includes/autoload_class.php");  
$funcoes=new funcoes();
//
?>
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho  -->
<div id="cabecalho" style="z-index:2; border: none;" >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_patrimonio.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
$_SESSION["function"]="dopatrim";
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal_patrimonio.php");
//
//  Destaivando variaveis de excluir,consultar e editar
$_SESSION["m_excluir"]=false;
$m_excluir = $_SESSION["m_excluir"];
$_SESSION["m_consultar"]=false;
$m_consultar = $_SESSION["m_consultar"];
$_SESSION["m_editando"]=false;
$m_editando = $_SESSION["m_editando"];
$encontrar="";
//
?>
<!-- CORPO -->
<div id="corpo" style="text-align: center; width: 100%; "  >
<label  id="label_msg_erro" style="display:none; position: relative;width: 100%; text-align: center; overflow:auto;" >
       <font  ></font>
</label>
<p class="tr_cabecalho" style="overflow:hidden;" ><b>Cadastrar/<?php echo $tit_pag;?></b>
<span class="pag_diminuir" style="margin-right: 10px;" >
Zoom:&nbsp;<select  style="font-size: xx-small; cursor: pointer;"  onchange="ChangeZoom(this,'div_form');" title="Selecionar">
        <option />80%
        <option />90%
        <option selected="selected" />100%
        <option />110%
        <option />115%        
    </select>
</span>
</p>
<hr style="border-bottom: 1px solid #000000; margin: 0px; padding: 0px;" />
<!--  DIV abaixo os Dados Antes de pedir o Arquivo para Upload   -->
<div id="div_form" style="width:100%; overflow: auto; height: 392px; display: <?php echo $_SESSION["div_form"];?>;" >
<?php
//   Colocar as datas do Cadastro do Usuario e a validade
date_default_timezone_set('America/Sao_Paulo');
$dia = date("d");
$mes = date("m");
$ano = date("Y"); 
$ano_validade=$ano+2;
$_SESSION['datacad']="$ano-$mes-$dia";
$_SESSION['datavalido']="$ano_validade-12-31";
//
if( isset($_GET["m_nome_id"]) ) $encontrar=$_GET["m_nome_id"];  
if( strtoupper($encontrar)=="PATRIMONIO" ) $encontrar="bem"; 
if( isset($encontrar) ) {
    $n_fields="";
    if( strlen($encontrar)>1 ) {
          $m_ordenar=' instituicao,unidade,depto,setor,bloco,sala,nome ';
         //  $result=mysql_query("SELECT  * from  {$_SESSION["bd_1"]}.$encontrar limit 0 ");            
         $query=mysql_query("SELECT  * from  {$_SESSION["bd_1"]}.$encontrar order by $m_ordenar ");            
         if( ! $query ) {
             echo $funcoes->mostra_msg_erro("Falha no select da Tabela $encontrar - db/Mysql:&nbsp; ".mysql_error());    
             //  echo "ERRO: Falha no select da Tabela ".$encontrar.": ".mysql_error();
             exit();
         } else  $n_fields = mysql_num_fields($query);
    }
} elseif( ! isset($encontrar) ) {
    echo $funcoes->mostra_msg_erro("Falha na vari�vel");    
    exit();                  
}  
$num_rows = mysql_num_rows($query);
$num_rows = (int) strlen(trim($num_rows)); 
$m_linhas = mysql_num_rows($query);
//  PRECISA da variavel total_deptos total de deptos
$total_registros = $m_linhas;
//   Criando array m_value_c
for( $i=0; $i<100 ; $i++ ) $m_value_c[$i] ="";   
if( $n_fields>=1 ) {
     //  Parte tentando pegar o tamanho maior da coluna (campo)
     $max_length="";
     for( $i=0; $i<$n_fields ; $i++ )  {
          $name_c_id[$i] = trim(mysql_field_name($query,$i));   
          $len_c[$i]  = mysql_field_len($query,$i);
          //   $nome_campo=$name_c_id[$i];
          //    $campo_len[$nome_campo]=mysql_field_len($query,$i);          
          if( $total_registros>=1 ) { 
              $m_value_c[$i] =  mysql_result($query,0,$i); 
              $max_length .= " MAX(LENGTH(TRIM($name_c_id[$i]))) as campo$i ";
              if( $i<($n_fields-1) ) $max_length.= ", "; 
          }
     }
}
//
$_SESSION['num_cols']=$n_fields;  
if( isset($_SESSION['num_cols']) ) $num_cols=$_SESSION['num_cols'];
$m_height = "100" ; $m_sem_nada="==== Nenhum registro cadastrado ====";
$m_onkeyup="this.value=trim(this.value);javascript:this.value=this.value.toUpperCase();";  
$m_style_disabled=' background-color:#000; color: #FFF;'; $new_style=""; $new_disabled="";        
$_SESSION["m_disabled"] = ""; $m_disabled = "";
//
// $line_height='line-height: 20px;';   
$line_height='line-height: 14px;';   
//  Definindo os nomes dos campos das Tabelas selecionadas no Mysql - IMPORTANTE 2013
$array_nome=mysql_fetch_array($query);
foreach( $array_nome as $key => $value ) $$key=$value;
$m_campo= array( 1 => "30", "50","50", "120","400");
if( $total_registros>=1 ) {
    //   Selecionando o maximo espaco ocupado em cada campo da tabela
    $sqlcmd="SELECT ".$max_length." FROM {$_SESSION["bd_1"]}.$encontrar order by  $m_ordenar ";
    $result_max_length = mysql_query($sqlcmd);          
    //
    if ( ! $result_max_length ) {
          echo $funcoes->mostra_msg_erro("Select m�ximo tamanho dos campos da tabela {$_SESSION["bd_1"]}.$encontrar - db/mysql:&nbsp; ".mysql_error());    
          exit();
    }           
    $total_fields =  mysql_num_fields($result_max_length);
    for( $i=0; $i<$total_fields ; $i++ )  {
        $campo_width[$name_c_id[$i]]=mysql_result($result_max_length,0,$i);
    }
}
//  Figuras de enviar dados ou resetar
$enviar_gif="{$_SESSION["url_central"]}imagens/enviar.gif";
$limpar_gif="{$_SESSION["url_central"]}imagens/limpar.gif";
/*
echo  " \$_SESSION[instituicao] = {$_SESSION["instituicao"]} <br> "
      ." \$_SESSION[unidade] = {$_SESSION["unidade"]}  <br> "
      ." \$_SESSION[depto] =  {$_SESSION["depto"]} "; 
exit();      
*/
      

// LISTANDO A VARIAVEL $name_c_id  com os campos da Tabela pessoal
?>
<FORM name="form" class="nome_form"   method="POST"  enctype="multipart/form-data"  style=" border: none;"  >
<TABLE id="tabela_dados_cecer" style="overflow: auto;border:none;" cellspacing="0" >       
  <tr style="margin: 0px; padding: 0px; top: 0px; border: none;">
    <td  nowrap="nowrap"  nowrap="nowrap"  style="margin: 0px; padding: 0px; top: 0px; border: none; "  >
      <TABLE id="table_iudsb" style="margin: 0px; padding: 0px; top: 0px; border: none;<?php echo $line_height;?>" >
        <tr>
        <td align="left" nowrap="nowrap" class="td_normal">
          <span class="td_informacao2" >
             Institui&ccedil;&atilde;o:<br />
             <Select  name="instituicao"  id="instituicao"  class="td_select" onchange="javascript: validar();"  onfocus="javascript: desativar();" required="required"  >
               <?php
                 //  INSTITUICAO
                 //  Esta funcao mysql_db_query esta obsoleta  usar  mysql_query
                 //  $result=mysql_db_query($dbname,"SELECT sigla FROM instituicao order by nome ");
                 $result=mysql_query("SELECT sigla FROM {$_SESSION["bd_1"]}.instituicao order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                    <option value='' >=== Sigla ===</option>
                    <?php
                        while($linha=mysql_fetch_array($result)) {
                            $sigla_instituicao=$linha['sigla'];   
                            $selected_instituicao="";
                            if( preg_match("/$sigla_instituicao/i",$_SESSION["instituicao"]) ) {
                                 $selected_instituicao=" selected='selected' ";
                            }
                           /*  IMPORTANTE - para os espacos e caracteres com acentos
                                option deve ser feito desse modo  */ 
                            echo '<option '.$selected_instituicao.'  value="'.$sigla_instituicao.'" >';
                            echo  htmlentities($sigla_instituicao);
                            echo '</option>';
                     }
                     ?>
                 </select>
                 </span>
                    <?php
                     if( isset($result) ) mysql_free_result($result); 
                  }
                    // Final do Instituicao
                  ?>
                  </td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                  <span class="td_informacao2" >
                       Unidade:<br />
               <Select name="unidade" id="unidade" class="td_select" onchange="javascript: validar();" required="requited">
               <?php
                  //  UNIDADE
                  //  Esta funcao mysql_db_query esta obsoleta  usar  mysql_query
                 //  $result=mysql_db_query($dbname,"SELECT sigla FROM unidade order by nome ");
                 $result=mysql_query("SELECT sigla FROM {$_SESSION["bd_1"]}.unidade order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                <option value=''  onkeypress="keyhandler(event);"  >===   Sigla   ===</option>
                    <?php
                        while($linha=mysql_fetch_array($result)) {       
                            $sigla_unidade=$linha['sigla'];     
                            $selected_unidade="";
                            if( preg_match("/$sigla_unidade/i",$_SESSION["unidade"]) ) {
                                 $selected_unidade=" selected='selected' ";
                            }
                            /*  IMPORTANTE - para os espacos e caracteres com acentos
                                option deve ser feito desse modo  */ 
                            echo  '<option '.$selected_unidade.'  value="'.$sigla_unidade.'" >';
                            echo  htmlentities($sigla_unidade);
                            echo '</option>';  
                     }
                     ?>
                  </select>
                   </span>
                    <?php
                      if( isset($result) ) mysql_free_result($result); 
                  }
                   // Final da Unidade
                  ?>                  
               </td>
               <td align="left" nowrap="nowrap" class="td_normal">
                <span class="td_informacao2" >
                       Departamento:<br />
                 <select  name="depto" id="depto" class="td_select" onchange="validar();" required="required"  >            
               <?php
                  //  DEPARTAMENTO
                 $result=mysql_query("SELECT * FROM {$_SESSION["bd_1"]}.depto order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                    <option value='' >====   Sigla-&nbsp;Nome   ====</option>
                    <?php
                        while($linha=mysql_fetch_array($result)) {     
                            $sigla_depto=$linha['sigla'];     
                            $selected_depto="";
                            if( preg_match("/$sigla_depto/i",$_SESSION["depto"]) ) {
                                 $selected_depto=" selected='selected' ";
                            }
                            /*  IMPORTANTE - para os espacos e caracteres com acentos
                                option deve ser feito desse modo  */ 
                            echo  '<option '.$selected_depto.'  value="'.$sigla_depto.'" >';
                            echo  htmlentities($sigla_depto)."&nbsp;-";
                            echo  "&nbsp;".ucfirst(htmlentities($linha['nome']));
                            echo  "&nbsp;</option>" ;
                     }
                     ?>
                 </select>
                 </span>
                    <?php
                    mysql_free_result($result); 
                  }
                  // Final do Departamento
                  ?>
                  </td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                 <span class="td_informacao2" >
                    Setor:<br />
                 <Select name="setor" id="setor"  class="td_select" onchange="validar();" required="required"   >
                  <?php
                  //  SETOR
                 $result=mysql_query("SELECT * FROM {$_SESSION["bd_1"]}.setor order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                     <option value='' >====   Sigla-&nbsp;Nome   ====</option>
                      <?php
                        while($linha=mysql_fetch_array($result)) {       
                        echo "<option value=".urlencode($linha['sigla'])." >";
                        echo  $linha['sigla']."&nbsp;-"
                              ."&nbsp;".ucfirst(htmlentities($linha['nome']));
                        echo  "&nbsp;</option>" ;
                     }
                     ?>
                 </select>
                   </span>
                <?php
                    mysql_free_result($result); 
                  }
                  ?>
                  </td>
                </tr>
                </table>
                <!-- FINAL da Tabela1 para campos -  Instituicao-Unidade-Depto-Setor -->                
                </td>
                </tr>

  <tr style="margin: 0px; padding: 0px; top: 0px; border: none; <?php echo $line_height;?>">
    <td  nowrap="nowrap"  nowrap="nowrap"  style="margin: 0px; padding: 0px; top: 0px; border: none; ">
    <!-- Tabela2 para campos -  Bloco, Salas e outros -->    
      <TABLE  style="margin: 0px; padding: 0px; top: 0px; border: none;<?php echo $line_height;?>" >
        <tr>
          <td align="left" nowrap="nowrap" class="td_normal">
            <!-- Bloco -->
              <span class="td_informacao2" >
                Bloco:<br />
                <input type="text" name="bloco" id="bloco" size="5"  maxlength="4"  class="td_select" 
               onkeyup="javascript:this.value=this.value.toUpperCase();"  style="cursor: pointer;" title="Digitar bloco"   onblur="javascript: acertar_espacos(this.id,this.value);"  >
              </span>
          </td>
          <td align="left" nowrap="nowrap" class="td_normal">
             <!-- SALA -->
              <span class="td_informacao2" >
                 Sala:<br />
                <input type="text" name="sala" id="sala" size="16"  maxlength="48" 
                class="td_select"  title="Digitar Sala" onblur="javascript: acertar_espacos(this.id,this.value);" >
                 </span>                 
          </td>
          <td  align="left" nowrap="nowrap"  class="td_normal"  >
             <!-- SALA TIPO -->
               <span class="td_informacao2" >
                   Sala Tipo:<br />
                <input type="text" name="salatipo" id="salatipo" title="Digitar Sala Tipo - ex.: Laborat&oacute;rio" 
                size="26"  maxlength="32" class="td_select" onblur="javascript: acertar_espacos(this.id,this.value);"  >
                </span>                  
          </td>       
          <td align="left" nowrap="nowrap" class="td_normal">
             <!-- N. Funcional USP -->
              <span class="td_informacao2" >
                Nome_Respons&aacute;vel/Categoria:<br />
               <select name="coduspresp"  id="coduspresp"  class="td_select"  onblur="validar();"  title="N&uacute;mero Funcional USP - Nome do Respons&aacute;vel" required="required"  >            
               <?php
                  //  Num_USP/Nome Responsavel
                 $result=mysql_query("Select codigousp,nome,categoria  from {$_SESSION["bd_1"]}.pessoal order by nome");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                  ?>
                    <option value='' >====   Nome_Respons&aacute;vel/Categoria   ====</option>
                    <?php
                     while($linha=mysql_fetch_array($result)) {       
                             echo "<option value=".htmlentities($linha['codigousp'])." >";
                             echo  ucfirst(htmlentities($linha['nome']));
                             echo  "  -  ".$linha['categoria']."&nbsp;</option>" ;
                     }
                     ?>
                    </select>
                    </span>
                    <?php
                    mysql_free_result($result); 
                  }
               // Final da Num_USP/Nome Responsavel
             ?>                  
          </td>
          <td align="left" nowrap="nowrap" class="td_normal">
            <!-- CLP -->
              <span class="td_informacao2" >
                 CLP:<br />
                <input type="text" name="clp"  id="clp" size="14"  maxlength="12"  required="required" 
                 class="td_select" onkeyup="this.value=trim(this.value);javascript:this.value=this.value.toUpperCase();" style="margin-left: 0;"  onchange="return validar();"  title="CLP - C&oacute;digo Local do Patrimonio - Ex.: 17RGE1234567">
              </span>
          </td>
          <td align="left" nowrap="nowrap" class="td_normal">
            <!-- Chapa Patrimonio USP -->
               <span class="td_informacao2" >
                    Chapa/USP:<br />
                <input type="text" name="chapausp" id="chapausp" size="26"  maxlength="20" title="Chapa do Patrimonio"
                  class="td_select"  onkeyup="this.value=trim(this.value)" style="margin-left: 0;"  
                  onchange="return validar();" >
               </span>
          </td>
        </tr>        
      </table>
     </td>
  </tr>   
  
  <tr>
   <td colspan="14" align="left" class="td_normal" nowrap="nowrap" >
      <!-- TABELA para campos -  Grupo - Nome-Modelo-Marca  -->    
        <TABLE align="left"  style="margin-left: 0px; border: 0;"  cellspacing="0" style="<?php echo $line_height;?>" >
          <tr>
            <td align="left" nowrap="nowrap" class="td_normal">
               <span class="td_informacao2" >
                 Grupo:<br />
                <Select name="grupo" class="td_select"  id="grupo" onblur="validar();" title="Grupo de Patrimonio" >                        <?php
                  //  Grupo de Patrimonio
                  //  Esta funcao mysql_db_query esta obsoleta  usar  mysql_query
                 /*
                 $result=mysql_db_query($dbname,"SELECT codigo,descricao,count(*) as n "
                         ." from grupo group by codigo,descricao having n<2");   */
                 $result=mysql_query("SELECT codigo,descricao,count(*) as n "
                         ." from {$_SESSION["bd_1"]}.grupo  group  by  codigo,descricao having n<2");   
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                    <option value='' >====   Grupo   ====</option>
                    <?php
                        while($linha=mysql_fetch_array($result)) {       
                        echo "<option value=".htmlentities($linha['codigo'])." >";
                        echo  $linha['codigo']."&nbsp;-"
                              ."&nbsp;".htmlentities($linha['descricao']);
                        echo  "&nbsp;</option>" ;
                     }
                     ?>
                    </select>
                    </span>
                    <?php
                    if( isset($result) )  mysql_free_result($result); 
                  }
                  // Final do Grupo de Patrimonio
                  ?>    
            </td>
            <td align="left" nowrap="nowrap" class="td_normal">
               <!-- Nome -->                  
                <span class="td_informacao2" >
                    Nome:<br />
                <input type="text" name="nome" id="nome" size="44"  maxlength="64" required="required" 
                 class="td_select" title="Nome do Patrimonio"  style="font-size: x-small;" 
                  onblur="javascript: acertar_espacos(this.id,this.value);" >
              </span>
            </td>
            <td align="left" nowrap="nowrap" class="td_normal">
               <!-- Modelo -->                  
                <span class="td_informacao2" >
                    Modelo:<br />
                 <input type="text" name="modelo" id="modelo" size="30"  maxlength="40" 
                  class="td_select" title="Modelo do Patrimonio"  style="font-size: x-small;"  
                   onblur="javascript: acertar_espacos(this.id,this.value);">
                </span>
            </td>
            <td align="left" nowrap="nowrap" class="td_normal">
               <!-- Marca -->                  
                 <span class="td_informacao2" >
                    Marca:<br />
                  <input type="text" name="marca" id="marca" size="26"  maxlength="48" 
                    class="td_select" title="Marca do Patrimonio" style="font-size: x-small;" 
                    onblur="javascript: acertar_espacos(this.id,this.value);" >
                 </span>          
            </td>
          </tr>
        </TABLE>
        <!-- FINAL da TABELA para campos -  Grupo-Nome-Modelo-Marca -->
       </td>
      </tr>
 
      <tr style="line-height: 0;" >                                
        <td colspan="14" align="left" class="td_normal" nowrap="nowrap" >
           <!--  TABELA  para campos - FORNECEDOR -->    
             <TABLE align="left" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000"  style="margin: 0px; padding-top: 0px; text-align: left;<?php echo $line_height;?> "  >
               <tr>
                 <td align="left" nowrap="nowrap" class="td_normal">
                 <span class="td_informacao2" style="width: 30px; ">
                 Selecionar Fornecedor:<br />
                 <Select name="fornecedor" id="fornecedor" title="Selecionar Fornecedor" 
                      class="td_select"  onchange="javascript: validar();" >
                  <?php
                  //  Selecionar Fornecedor
                  //  Esta funcao mysql_db_query esta obsoleta  usar  mysql_query
                 //  $result=mysql_db_query($dbname,"SELECT  codigo,nome FROM fornecedor order by nome ");
                 $result=mysql_query("SELECT  codigo,nome FROM {$_SESSION["bd_1"]}.fornecedor order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                        echo "<option value='outro' >";
                     echo  "&nbsp;OUTRO&nbsp;</option>" ;
                 } else {
                   ?>
                     <option value='' >====   Fornecedor   ====</option>
                   <?php
                     while($linha=mysql_fetch_array($result)) {       
                            $nome_fornecedor=trim($linha['nome']);                          
                            /*  IMPORTANTE - para os espacos e caracteres com acentos
                              option deve ser feito desse modo  */
                            echo '<option value="'.$nome_fornecedor.'" >';
                            echo  htmlentities($nome_fornecedor);
                            echo  "&nbsp;</option>" ;
                     }
                     echo "<option value='outro' >";
                     echo  "&nbsp;OUTRO&nbsp;</option>" ;
                     ?>
                 </select>
                   </span>
                <?php
                    mysql_free_result($result); 
                  }
                  ?>
                  </td>
                    <td align="left" bordercolor="#FFFFFF"  nowrap="nowrap"  class="td_normal" id="tab_fornecedor" style="width: 220px; display: none; "  >
                     <!-- Fornecedor -->
                     <span  class="td_informacao2" style="margin-left: 0px; cursor: pointer; text-align: left; " ><br />
                 <input align="left" type="text" name="m_fornecedor" id="m_fornecedor"  
                 size="85" maxlength="60" class="td_select" style="margin-left: 0px;text-align: left;"  disabled="disabled" title="Digitar fornecedor" onblur="javascript: acertar_espacos(this.id,this.value);" >
                 </span>                 
                 </td>                    
               </tr>
            </table>
          <!--  FINAL da TABELA para campos - FORNECEDOR -->
        </td>
      </tr>
      
      <tr>
        <td colspan="14" align="left" class="td_normal" nowrap="nowrap" >
          <!--  TABELA  para campos -  NOTA FISCAL -->    
            <TABLE align="left" border="0" cellpadding="0" cellspacing="0"  style="margin: 0px; padding-top: 1px; text-align: left;">
             <tr>
              <td align="left" class="td_normal" id="tab_fornecedor" nowrap="nowrap" style="margin-left: 0px; padding-left: 0px; margin-right: 0px;padding-right: 0px;  text-align: left;"  >
                <!-- Nota Fiscal -->                  
                 <span class="td_informacao2" style="width: 30px; <?php echo $line_height;?>">
                    Nota Fiscal:<br />
                <input align="left" type="text" name="notafiscal" id="notafiscal"  size="26"  title="Nota Fiscal" 
                 maxlength="12"  class="td_select" style="margin-left: 0px; text-align: left;"
                  onblur="javascript: acertar_espacos(this.id,this.value);" >
                    </span>
                    </td>
                    <td  nowrap="nowrap"  class="td_normal" style="padding-right: 2px;"  >
                        <!-- Data Nota Fiscal -->                  
                  <span   class="td_informacao2"  style="width: 30px; <?php echo $line_height;?>">
                   Nota Data Fiscal:<br />
                  <input  type="date" name="notadata" id="notadata" size="10" maxlength="12" class="td_select" title="Data Nota Fiscal - exemplo: 01/01/1998 " style="cursor: pointer; "  />
                  </span>
                  </td>
                  <td  nowrap="nowrap"  class="td_normal" style="border-style: solid; border-width: 1px; border-right-width: 0px; padding-left: 6px; width: 70px; vertical-align:middle;"   >
                  <span class="td_informacao2" style="padding-right: 2px; color: #008000;  ">Garantia:<br />(data)</span>                   </td>
                  <td  nowrap="nowrap"  class="td_normal" style="border-style: solid; border-width: 1px; border-left-width: 0px; border-right-width: 0px;"  >
                   <!-- Data Garantia Inicial -->                  
                   <span  class="td_informacao2"  style="width: 30px; <?php echo $line_height;?>" >
                  Inicial:<br />
                   <input  type="date" name="garantiai" id="garantiai" size="10" maxlength="12" class="td_select" title="Data Garantia Inicial - exemplo: 01/01/1998 " style="cursor: pointer;"  />
                   </span>
                  </td>
                  <td  nowrap="nowrap"  class="td_normal" style="border-style: solid; border-width: 1px; border-left-width: 0px; padding-left: 4px;">
                    <!-- Data Garantia Final -->                  
                     <span class="td_informacao2" style="width: 30px; <?php echo $line_height;?>" >
                     Final:<br />
                     <input  type="date" name="garantiaf" id="garantiaf" size="10" maxlength="12" class="td_select" title="Data Garantia Final - exemplo: 01/01/1998 " style="cursor: pointer;"  />
                    </span>
                  </td>
                  <td  nowrap="nowrap"  class="td_normal" style="padding-left: 12px;"   >
                      <!-- Data da instala��o do bem -->                  
                    <span  class="td_informacao2" style="width: 30px; <?php echo $line_height;?>" >
                     Data da Instala&ccedil;&atilde;o:<br />
                     <input  type="date" name="instaldata" id="instaldata" size="12" maxlength="12" class="td_select" title="Data da Instala��o - exemplo: 01/01/1998 " style="cursor: pointer;" />
                    </span>                  
                  </td>
             </tr>
           </table>
          <!--  FINAL da TABELA para campos da NOTA FISCAL e datas  -->
        </td>
      </tr>
      
      <tr>
        <td colspan="14" align="left" class="td_normal" nowrap="nowrap" >
           <!-- Tabela para campos -  N_Serie-N_Processo e outros -->    
             <TABLE  style="margin-left: 0px; border: 0;  " >
               <tr>
                 <td align="left" nowrap="nowrap" class="td_normal">
                  <!-- Numero de Serie -->                  
                  <span  class="td_informacao2" style="margin-left: 0px; <?php echo $line_height;?>" >
                    N. S&eacute;rie:<br />
                   <input type="text" name="serie" id="serie" size="32" maxlength="24" 
                    onkeyup="this.value=trim(this.value)" style="margin-left: 0; cursor: pointer;" class="td_select"  
                    onchange="return validar();" title="N&uacute;mero de S&eacute;rie" >
                  </span>                    
                 </td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                   <!-- Numero do Processo -->
                   <span  class="td_informacao2"  style="margin-left: 0px; <?php echo $line_height;?>" >
                    N. Processo:<br />
                  <input align="left" type="text" name="nuprocesso" id="nuprocesso" size="16" maxlength="15" 
                  onkeyup="this.value=trim(this.value)" style="margin-left: 0px; cursor: pointer;" class="td_select" onchange="return validar();" title="N&uacute;mero do Processo" >
                 </span>        
                 </td>                    
                 <td align="left" nowrap="nowrap" class="td_normal">
                   <!-- Documento Identificacao -->                  
                   <span  class="td_informacao2" style="margin-left: 0px; <?php echo $line_height;?>" >
                    Docto. Identifica&ccedil;&atilde;o:<br />
                <input type="text" name="identdocto" id="identdocto" size="34" maxlength="32" 
                   class="td_select" title="Documento Identifica&ccedil;&atilde;o"  
                   onblur="javascript: acertar_espacos(this.id,this.value);" >
                   </span>
                 </td>
                 <td  nowrap="nowrap"  class="td_normal"  >&nbsp;</td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                   <!-- Data Compra -->                  
                   <span  class="td_informacao2" style="margin-left: 0px; <?php echo $line_height;?>" >
                     Data Compra:<br />
                    <input  type="date" name="datacompra" id="datacompra" size="12" maxlength="12" class="td_select" title="Data Compra - exemplo: 01/01/1998 " style="cursor: pointer;" />
                   </span>
                 </td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                   <!-- Valor em R$ da Compra -->                  
                    <span  class="td_informacao2" style="margin-left: 0px; <?php echo $line_height;?>" >
                     Valor R$:<br />
                <input type="text"  name="valor"  id="valor" pattern="^[$\-\s]*[\d\.]*?([\,]\d{0,2})?\s*$"  length="15"  class="td_select" value="0,00" title="Valor R$"  onkeypress="return(FormataReais(this,'.',',',event))"   onblur="return(FormataReais(this,'.',',',event));" required="required" >
                    </span>                
                 </td>
                 <td align="left" nowrap="nowrap" class="td_normal">
                   <!-- Parte do CLP -->                  
                    <span  class="td_informacao2" style="margin-left: 0px; <?php echo $line_height;?>" >
                     Parte do CLP:<br />
                    <input type="text" name="partede"  id="partede" size="16"  maxlength="12" class="td_select"
                 title="Parte do CLP - C&oacute;digo Local do Patrimonio - Ex.: 17RGE1234567" 
                 onkeyup="this.value=trim(this.value);javascript:this.value=this.value.toUpperCase();"  
                  style="margin-left: 0;"  onchange="return validar();">
                    </span>                    
                 </td>
                </tr>
               </table>
               <!--  FINAL da  Tabela para campos - -N_Serie-N_Processo e outros -->    
             </td>
           </tr>

           <tr style="line-height: 0;" >
            <td align="left" class="td_normal" nowrap="nowrap" >
              <!--  TABELA6 para campos - Tipo de Posse - Fonte de Posse e outros-->    
              <TABLE  cellpadding="0" cellspacing="0" align="left" style="margin: 0px; border: none;<?php echo $line_height;?> " >
                <tr align="left">
                  <td align="left"  nowrap="nowrap"  class="td_normal" style="margin-right: 0px; padding-right: 0px;">
                    <!-- Tipo de Posse -->                  
                     <span  class="td_informacao2" style="margin-left: 0px; " >
                      Tipo de Posse:<br />
                     <input type="text" name="tipoposse" id="tipoposse"  size="34" maxlength="32"   onkeyup="this.value=trim(this.value)"  title="Tipo de Posse"  class="td_select"  onchange="return validar();" >
                    </span>                    
                  </td>
                  <td align="left"  nowrap="nowrap"  class="td_normal" style="margin-right: 0px; padding-right: 0px;"  >
                    <!-- Fonte de Posse -->
                    <span  class="td_informacao2" > 
                    Fonte de Posse:<br />
                  <Select  name="fonteposse" id="fonteposse" class="td_select" title="Fonte de Posse do Patrimonio (sigla) - Exemplo: USP" style="font-size: xx-small;"  onchange="validar();" >            
                  <?php
                  //  Fonte de Posse - Financiadora
                 //  Esta funcao mysql_db_query esta obsoleta  usar  mysql_query                  
                 $result=mysql_query("SELECT * FROM  {$_SESSION["bd_1"]}.financiadora order by nome ");
                 $m_linhas = mysql_num_rows($result);
                 if ( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                 } else {
                   ?>
                    <option value='' >====   Sigla-&nbsp;Nome   ====</option>
                    <?php
                       while($linha=mysql_fetch_array($result)) {       
                           echo "<option value=".urlencode($linha['sigla'])." >";
                           echo  $linha['sigla']."&nbsp;-"
                                 ."&nbsp;".ucfirst(htmlentities($linha['nome']));
                           echo  "&nbsp;</option>" ;
                       }
                     ?>
                 </select>
                 </span>
                    <?php
                     if( isset($result) ) mysql_free_result($result); 
                  }
                  // Final do Fonte de Posse - Financiadora
                  ?>
                  </td>                    
                  <td align="left" nowrap="nowrap" class="td_normal">
                     <!-- Documento Identificacao Posse -->                  
                    <span class="td_informacao2" >
                     Docto. Identifica&ccedil;&atilde;o de Posse:<br />
                     <input type="text" name="identposse" id="identposse"  size="44" maxlength="32" 
                      class="td_select"  title="Documento Identifica&ccedil;&atilde;o de Posse" 
                       onblur="javascript: acertar_espacos(this.id,this.value);" >
                    </span>                    
                  </td>
                  <td align="left" nowrap="nowrap" class="td_normal">
                     <!-- Situacao Atual -->                  
                    <span class="td_informacao2" >
                    Situa&ccedil;&atilde;o atual:<br />                    
                    <Select name="situacao"  id="situacao" style="font-size: x-small;" title="Situa&ccedil;&atilde;o atual"  size="1" lang="pt" required="required">
                       <option value="" selected="selected" >Selecionar</option>
                       <option value="Ativo">Ativo</option>
                       <option value="Inoperante">Inoperante</option>
                       <option value="Semi Inoperante">Semi Inoperante</option>                    
                    </select>
                    </span>
                  </td>            
                </tr>
              </table>
              <!--  FINAL da TAB6 para campos - Tipo de Posse - Fonte de Posse e outros -->        
            </td>
          </tr>

          <tr  >
           <td colspan="14" align="left" nowrap="nowrap" valign="top"   >
             <!--  TABELA  para campos - ATRIBUTOS -->    
               <TABLE cellpadding="3" cellspacing="0" border="1" style="margin: 0px; padding: 0px; text-align: left;" >
                 <tr valign="middle" >
                   <td  nowrap="nowrap"   valign="middle"  >
                    <!-- Adicionar Atributo - Ativar Botao -->                  
                    <span  class="td_informacao2" style="cursor: pointer; text-align: left;padding: 0px 5px 0px 5px;"  title="Adicionar Atributo"  >
                      Adicionar Atributo:
                    </span>
                   </td>
                   <td  align="left"  valign="top" style="left: 0px; text-align: 0px;" >
                    <!-- Adicionar Atributo - Ativar Botao -->                  
                    <span  title="Adicionar Atributo" class="td_informacao2"  style="left: 0px; text-align: left;"  >
                    <input type="checkbox" name="m_botao_atributo" id="m_botao_atributo" class="botao3d"  title="Clicar para adicionar atributo"  style="margin-left: 0px;" onclick="javascript: validar();"    />
                    </span>
                   </td>
                   
               <td align="left" nowrap="nowrap" class="td_normal" style="padding: 0px 4px 0px 4px;" >
                    <span class="td_informacao2" >
                       Selecionar Atributo:&nbsp;
                     <Select name="atributo" id="atributo"  class="td_select" onchange="validar();" disabled="disabled"  >
                    <?php
                     //  Selecionar ATRIBUTO
                     $result=mysql_query("SELECT  distinct codigo FROM {$_SESSION["bd_1"]}.atributo order by codigo ");
                     $m_linhas = mysql_num_rows($result);
                     if( $m_linhas<1 ) {
                        echo "<option value='' >==== Nenhum encontrado ====</option>";
                     } else {
                   ?>
                       <option value='' >====   Atributo   ====</option>
                    <?php
                       while($linha=mysql_fetch_array($result)) {       
                            $atributo_codigo=trim($linha['codigo']);                          
                            /*  IMPORTANTE - para os espacos e caracteres com acentos
                              option deve ser feito desse modo  */
                            //  echo "<option value=".urlencode($linha['codigo'])." >";
                            echo '<option value="'.$atributo_codigo.'" >';
                            echo  htmlentities($linha['codigo']);
                            echo  "&nbsp;</option>" ;
                       }
                       echo "<option value='outro' >";
                       echo  "&nbsp;OUTRO&nbsp;</option>" ;
                     ?>
                 </select>
                 </span>
                 <?php
                     mysql_free_result($result); 
                  }
                  ?>
                  </td>
                </tr>            
              </table>
            </td>
          </tr>

          
          
          <tr  >
           <td colspan="14" align="left" class="td_normal" nowrap="nowrap"  >
            <TABLE  cellpadding="1" cellspacing="0" width="100%" style="margin: 0px; border: 1px solid #000000;" >
                 <tr>
           <!--       <td class="td_normal" id="tab_atrib" nowrap="nowrap" style="display: none; background-color: #FFFFFF;width:auto;" >  -->
                  <td class="td_normal" style="background-color: #FFFFFF;" >                  
                     <!-- Codigo do Atributo -->
                     <label  class="td_informacao2" for="m_atributo" id="label_m_atributo" style="cursor: pointer;display: none;" >C&oacute;digo:&nbsp;
                     <input type="text" name="m_atributo" id="m_atributo" size="35" maxlength="24" class="td_select"
                         onkeyup="javascript: this.value=trim(this.value);this.value=this.value.toUpperCase();" title="Digitar C�digo"  onblur="javascript: acertar_espacos(this.id,this.value);document.getElementById('label_msg_erro').style.display='none';" disabled="disabled">
                    </label>             
                  </td>                    
      <!--            <td class="td_normal" id="tab_descr" nowrap="nowrap"  style="display: none; background-color: #FFFFFF;width:auto;" >  -->
                  <td class="td_normal"  style="background-color: #FFFFFF;" >
                  
                    <!-- Descricao do Atributo -->                  
                    <label class="td_informacao2" for="m_atrib_descr" id="tab_descr" style="cursor: pointer;display: none;"  >Descri&ccedil;&atilde;o:&nbsp;
                    <input type="text" name="m_atrib_descr" id="m_atrib_descr" size="86" maxlength="64"
                     class="td_select" title="Digitar Descri&ccedil;&atilde;o" onblur="javascript: acertar_espacos(this.id,this.value);" disabled="disabled">
               </label>
                  </td>
                  
                  <td align="left" class="td_normal"  nowrap="nowrap" >
                  <button type="submit" name="m_incluir_atributo" id="m_incluir_atributo" class="botao3d"  style="width:auto;position:relative; display: none; "
                    title="Salvar Atributo"  acesskey="S" onclick="javascript: atributo_incluir('clp','m_atributo','m_atrib_descr');return false;"  >
                    Salvar<img src="<?php echo  $enviar_gif;?>" alt="Salvar Atributo"  style="vertical-align:text-bottom;" >
                    </button>                 
                  </td>
                  <td align="left" class="td_normal"  nowrap="nowrap" > 
                  <button type="submit" name="m_limpar_atributo" id="m_limpar_atributo" class="botao3d" 
                   style="width:auto;position:relative; display: none; " title="Clicar para limpar atributo"  
                   acesskey="L" onclick="javascript: desativar_atributo(); return false; " disabled="disabled" >
                    Limpar<img src="<?php echo  $limpar_gif;?>" alt="Clicar para limpar atributo"  style="vertical-align:text-bottom;" >
                  </button>                 
 
                  </td>  
                 </tr>
               </table>
             <!--  FINAL da TABELA para campos - ATRIBUTOS -->    
          </td>
        </tr>  

        
    <tr  >
      <!--  Mostrar Atributos incluidos -->
       <td colspan="14" align="left" valign="top" class="td_normal" nowrap="nowrap" id="td_label_atributos" >
       <label id="label_atributo_incluidos" style="display:none; position: relative;width: 100%;text-align: center;">
         </label>
         <!-- FINAL -  Mostrar Atributos incluidos -->             
      </td>
    </tr>
    
    
    
    <tr style="position: relative; text-align:center;line-height: 0;border: none;" >
       <!--  Botoes para Salvar ou Cancelar Patrimonio -->
      <td colspan="14" align="center"  valign="top" class="td_normal" nowrap="nowrap" style="position: relative; text-align:center; line-height: 0px; border: none;" >
          <TABLE cellspacing="1" cellspacing="1" style="position: relative; text-align:center;" >
            <tr valign="top"  >
              <td align="center" valign="top"  nowrap="nowrap"  class="td_normal" style="width: 140px; margin: 0px; padding: 0px; white-space:nowrap;" >
                <label id="label_salvar_patrimonio">
                   <button type="submit" name="m_salvar_patrimonio" id="m_salvar_patrimonio"  
                   class="botao3d"  style="width:auto;" title="Salvar Patrimonio"  
                   acesskey="S" onclick="javascript: salvar_patrimonio('m_salvar_patrimonio'); return false; " >    
                Salvar&nbsp;Patrimonio<img src="<?php echo "{$_SESSION["url_central"]}imagens/enviar.gif";?>" alt="Salvar Patrimonio"  style="vertical-align:text-bottom;" >
                   </button>
                </label>
              </td>
              <td  align="center" valign="top"  nowrap="nowrap"  class="td_normal" style="width: 140px; margin: 0px; padding: 0px; white-space:nowrap; "  >
               <label id="label_cancelar_patrimonio"  >
                 <button type="reset"  name="m_cancelar_patrimonio" id="m_cancelar_patrimonio"  onclick="javascript: ../iniciar.php"  class="botao3d" style="width:auto; "   title="Cancelar"  acesskey="C" >    
                 Cancelar&nbsp;<img src="<?php echo "{$_SESSION["url_central"]}imagens/limpar.gif";?>" alt="Cancelar" style="vertical-align:text-bottom;" >
                   </button>
               </label>
              </td>
            </tr>
          </TABLE>
         <!--  FINAL - Botoes para Salvar ou Cancelar Patrimonio -->             
      </td>
    </tr>
    <tr>
      <td colspan="14" >
         <label id="label_patrimonio_incluido" style="display:none; position: relative; text-align: center;" >
            <font  id="m_patrimonio_incluido"  style="margin-top: 0px; padding-top: 0px; margin-bottom: 0px; padding-bottom: 0px; line-height: 0px; top: 60px; text-align: center; overflow: scroll;"  >
            </font>                          
         </label>
      </td>
    </tr>                        
  </table>
</FORM> 
<!-- FINAL dos campos para Cadastrar dados PATRIMONIO/BEM - FORM -->
</div>
<!-- Final da div id=div_form  -->
</div>      
<!-- Final Corpo -->
<!-- Rodape -->
<div id="rodape"   >
<?php include_once("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA - class=pagina_ini   -->
</body>
</html>
