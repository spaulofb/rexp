<?php
//  Consultar INSTITUICAO
//  Verificando se sseion_start - ativado ou desativado
if( ! isset($_SESSION)) {
     session_start();
}
//
// Verificando conexao
//
include("{$_SESSION["incluir_arq"]}iniciar_conexao.php");
//  Recebe GET e passa SESSION  - m_nome_id
if( isset($_GET["m_nome_id"]) ) {
    $_SESSION["m_nome_id"]=$_GET["m_nome_id"];
} else {
    $_GET["m_nome_id"]="";
    $_SESSION["m_nome_id"]="";
}
//  Caminho da pagina local
$_SESSION["m_juntos_link"] = "http://{$_SERVER["HTTP_HOST"]}{$_SERVER["SCRIPT_NAME"]}";
//
//  echo "cadastrar_atributo.php23 - \$_SESSION[m_juntos_link] = {$_SESSION["m_juntos_link"]}   ";
//
$_SESSION["div_form"]="block";
//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"  >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<!--  <meta name="language" content="pt-br" /> -->
<meta name="author" content="LAFB&SPFB" />
<!-- <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">  -->
<META http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<META NAME="ROBOTS" CONTENT="NONE"> 
<!--  <META HTTP-EQUIV="Expires" CONTENT="-1" >  -->
<!--  <META HTTP-EQUIV="Expires" CONTENT="0" >  -->
<META NAME="GOOGLEBOT" CONTENT="NOARCHIVE"> 
<!--  <meta http-equiv="Expires" content="-1">  -->
<META http-equiv="imagetoolbar" content="no">  
<title>Controle de Bem Patrimonial</title>
<link rel="shortcut icon" href="../imagens/GEMAC.ICO" type="image/x-icon" />
<title>Controle Patrimonial</title>
<style type="text/css">
/*  Importante para importar no css pastas  */
@import url("<?php echo $_SESSION["url_central"];?>css/estilo_patrimonio.css");
@import url("<?php echo $_SESSION["url_central"];?>css/style_titulo_patrimonio.css");
</style>
<?php
// Buscar  arquivo  js   como  php
include("{$_SESSION["incluir_arq"]}js/jquery-1.2.6.php");
include("{$_SESSION["incluir_arq"]}js/funcoes_js.php");
include("{$_SESSION["incluir_arq"]}js/consultar_instituicao_js.php");
//  IMPORTANTE para incluir js qdo tiver variavel de PHP
include("{$_SESSION["incluir_arq"]}js/conecta_ajax.php");
include("{$_SESSION["incluir_arq"]}js/menu_patrimonial.php");
?>
<script type="text/javascript" >
/* <![CDATA[ */
function criarJanela(id) {
     var ele = document.getElementById(id); 
     var m_top = 100; 
     var left = -20; 
     m_top += ele.offsetTop; 
     left += ele.offsetLeft; 
     //
     janelaCriada = window.open("","_blank","toolbar=no, location=no, directories=no, status=no, scrollbars=no, resizable=no, width=300, height=10, top="+m_top+", left="+left);
     janelaCriada.document.write("<p align='center' ><b>Usar * para mostrar todos registros.</b></p>");   
     janelaCriada.setTimeout("self.close();",3000);    
}
/* ]]> */
</script>
</head>
<body  oncontextmenu="return false" onselectstart="return false" onload="javascript: dochange('<?php echo $_GET["m_nome_id"];?>','iniciando')"  ondragstart="return false"  
 onkeydown="javascript: no_backspace(event);"   >
<?php
include("{$_SESSION["incluir_arq"]}script/abertura_da_pagina.php"); 
if( isset($_GET["m_nome_id"]) ) {
    $_SESSION["m_nome_id"]=$_GET["m_nome_id"];
} else {
    $_SESSION["m_nome_id"]="";
}
/*
   Chamada da fun��o das tabelas - array multidimensional
*/
//  require("{$_SESSION["incluir_arq"]}script/array_multi.php");
include("{$_SESSION["incluir_arq"]}script/array_multi.php");
$_SESSION["m_editando"]=false;
//  Require para o Navegador que nao tenha ativo o Javascript
//   Posicao do arquivo noscript.php tem que ser depois da tag  BODY
//  require("{$_SESSION["incluir_arq"]}js/noscript.php");
include("{$_SESSION["incluir_arq"]}js/noscript.php");
//  Menu Horizontal
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
// unset($_SESSION["m_horiz"]);
$_SESSION["m_horiz"] = $array_patrimonial;
//
?>
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho  -->
<div id="cabecalho" style="z-index:2; border: none;" >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_patrimonio.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
$_SESSION["function"]="dopatrim";
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal_patrimonio.php");
//
//  Destaivando variaveis de excluir,consultar e editar
$_SESSION["m_excluir"]=false;
$m_excluir = $_SESSION["m_excluir"];
$_SESSION["m_consultar"]=false;
$m_consultar = $_SESSION["m_consultar"];
$_SESSION["m_editando"]=false;
$m_editando = $_SESSION["m_editando"];
$encontrar="";
//
?>
<!-- CORPO -->
<div id="corpo" style="text-align: center; width: 100%; "  >
<label  id="label_msg_erro" style="display:none; position: relative;width: 100%; text-align: center; overflow:auto;" >
       <font  ></font>
</label>
<p class="tr_cabecalho" style="overflow:hidden; top: 0px; margin-top: 0px; " ><b>Consultar/<?php echo $tit_pag;?></b></p>
<hr style="border-bottom: 1px solid #000000; margin: 0px; padding: 0px;" />
<!--  DIV abaixo os Dados Antes de pedir o Arquivo para Upload   -->
<div id="div_form" style="width:100%; overflow: hidden; display:<?php echo $_SESSION["div_form"];?>; " >
</div>
<!-- Final da div id=div_form  -->
<!-- div id=campos_selecionado  -->
<div id="campos_selecionado" style="width:100%; display: none; position: relative; " >
</div>
<!-- Final div id=campos_selecionado  -->
<!-- div id=mostrar_tabela  -->
<div id="mostrar_tabela" style="width:100%; display: none;" >
</div>
<!-- Final div id=mostrar_tabela  -->
</div>      
<!-- Final Corpo -->
<!-- Rodape -->
<div id="rodape"   >
<?php include_once("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA - class=pagina_ini   -->
</body>
</html>