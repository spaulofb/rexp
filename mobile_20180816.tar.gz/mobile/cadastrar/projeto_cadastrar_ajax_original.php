<?php
///
//   Arquivo para CADASTRAR  - AJAX
//
///  INICIANDO FUNCTIONS
///  Funcao para busca com acentos
if( ! function_exists("stringParaBusca") ) {
    function stringParaBusca($str) {
        //Transformando tudo em minúsculas
        $str = trim(strtolower($str));

        //Tirando espaços extras da string... "tarcila  almeida" ou "tarcila   almeida" viram "tarcila almeida"
        while ( strpos($str,"  ") )
            $str = str_replace("  "," ",$str);
        
        //Agora, vamos trocar os caracteres perigosos "ã,á..." por coisas limpas "a"
        $caracteresPerigosos = array ("Ã","ã","Õ","õ","á","Á","é","É","í","Í","ó","Ó","ú","Ú","ç","Ç","à","À","è","È","ì","Ì","ò","Ò","ù","Ù","ä","Ä","ë","Ë","ï","Ï","ö","Ö","ü","Ü","Â","Ê","Î","Ô","Û","â","ê","î","ô","û","!","?",",","“","”","-","\"","\\","/");
        $caracteresLimpos    = array ("a","a","o","o","a","a","e","e","i","i","o","o","u","u","c","c","a","a","e","e","i","i","o","o","u","u","a","a","e","e","i","i","o","o","u","u","A","E","I","O","U","a","e","i","o","u",".",".",".",".",".",".","." ,"." ,".");
        $str = str_replace($caracteresPerigosos,$caracteresLimpos,$str);
        
        //Agora que não temos mais nenhum acento em nossa string, e estamos com ela toda em "lower",
        //vamos montar a expressão regular para o MySQL
        $caractresSimples = array("a","e","i","o","u","c");
        $caractresEnvelopados = array("[a]","[e]","[i]","[o]","[u]","[c]");
        $str = str_replace($caractresSimples,$caractresEnvelopados,$str);
        $caracteresParaRegExp = array(
            "(a|ã|á|à|ä|â|&atilde;|&aacute;|&agrave;|&auml;|&acirc;|Ã|Á|À|Ä|Â|&Atilde;|&Aacute;|&Agrave;|&Auml;|&Acirc;)",
            "(e|é|è|ë|ê|&eacute;|&egrave;|&euml;|&ecirc;|É|È|Ë|Ê|&Eacute;|&Egrave;|&Euml;|&Ecirc;)",
            "(i|í|ì|ï|î|&iacute;|&igrave;|&iuml;|&icirc;|Í|Ì|Ï|Î|&Iacute;|&Igrave;|&Iuml;|&Icirc;)",
            "(o|õ|ó|ò|ö|ô|&otilde;|&oacute;|&ograve;|&ouml;|&ocirc;|Õ|Ó|Ò|Ö|Ô|&Otilde;|&Oacute;|&Ograve;|&Ouml;|&Ocirc;)",
            "(u|ú|ù|ü|û|&uacute;|&ugrave;|&uuml;|&ucirc;|Ú|Ù|Ü|Û|&Uacute;|&Ugrave;|&Uuml;|&Ucirc;)",
            "(c|ç|Ç|&ccedil;|&Ccedil;)" );
        $str = str_replace($caractresEnvelopados,$caracteresParaRegExp,$str);
        
        //Trocando espaços por .*
        $str = str_replace(" ",".*",$str);
        
        //Retornando a String finalizada!
        return $str;
    }
}    
///
///  Funcao para minuscula para Maiuscula
if( ! function_exists("stringParaBusca2") ) {
    function  stringParaBusca2($str) {
     /*
         $a1 ="àáâãäåæçèéêëìíîïñòóôõöøùúûüý";
         $a1_len = strlen($a1);
         $a2 ="ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÑÒÓÔÕÖØÙÚÛÜÝ";
         //  $pessoa_nome2=trim($pessoa_nome);
        for( $i=0; $i<$a1_len; $i++ ) {
              $char1[]=substr($a1,$i,1);
                $char2[]=substr($a2,$i,1);
        }
        $m_count = count($char1);
        $texto=$str;
        for( $x=0; $x<$m_count ; $x++ ) {
            //   $str = str_replace($char1[$x],$char2[$x],$str);
             // First check if there is a "5" at position 0.
            $offset = 0; // initial offset is 0
            $fiveCounter = 0;
            if( strpos($str, $char1[$x])==0 ) continue;

           // Check the rest of the string for 5's
           while( $offset=strpos($str, $char1[$x],$offset+1) ) {
               $texto=substr_replace($texto,$char2[$x],$offset,1); 
               $chars .=  $char1[$x]." - ";        
           }
         //     $str = str_replace($char1,$char2,$str);
            //  $texto .= "<br>  - $str ".$char1." - ".$char2;
        
        
        }
      */
        //  Usar para substituir caracteres com acentos para Maiuscula
       $substituir = array(
                            '/&aacute;/i' => 'Á',
                            '/&Eacute;/i' => 'É',
                            '/&Iacute;/i' => 'Í',
                            '/&Oacute;/i' => 'Ó',
                            '/&Uacute;/i' => 'Ú',
                            '/&Atilde;/i' => 'Ã',
                            '/&Otilde;/i' => 'Õ',
                            '/&Acirc;/i' => 'Â',
                            '/&Ecirc;/i' => 'Ê',
                            '/&Icirc;/i' => 'Î',
                            '/&Ocirc;/i' => 'Ô',
                            '/&Ucirc;/i' => 'Û',
                            '/&Ccedil;/i' => 'Ç',
                            '/&Agrave;/i' => 'À'
                            );
        
        
        
        //  $texto =strtoupper($str);
       $substituir0 = array(
                            '/á/' => '&aacute;',
                            '/é/' => '&eacute;',
                            '/í/' => '&iacute;',
                            '/ó/' => '&oacute;',
                            '/ú/' => '&uacute;',
                            '/ã/' => '&atilde;',
                            '/õ/' => '&otilde;',
                            '/â/' => '&acirc;',
                            '/ê/' => '&ecirc;',
                            '/î/' => '&icirc;',
                            '/ô/' => '&ocirc;',
                            '/û/' => '&ucirc;',
                            '/ç/' => '&ccedil;',
                            '/Á/' => '&Aacute;',
                            '/É/' => '&Eacute;',
                            '/Í/' => '&Iacute;',
                            '/Ó/' => '&Oacute;',
                            '/Ú/' => '&Uacute;',
                            '/Ã/' => '&Atilde;',
                            '/Õ/' => '&Otilde;',
                            '/Â/' => '&Acirc;',
                            '/Ê/' => '&Ecirc;',
                            '/Î/' => '&Icirc;',
                            '/Ô/' => '&Ocirc;',
                            '/Û/' => '&Ucirc;',
                            '/Ç/' => '&Ccedil;',
                            '/à/' => '&agrave;',
                            '/À/' => '&Agrave;'
                            );

    /*
        $substituir2 = array('/á/' => 'Á',
                            '/é/' => 'É',
                            '/í/' => 'Í',
                            '/ó/' => 'Ó',
                            '/ú/' => 'Ú',
                            '/ã/' => 'Ã',
                            '/õ/' => 'Õ',
                            '/â/' => 'Â',
                            '/ê/' => 'Ê',
                            '/î/' => 'Î',
                            '/ô/' => 'Ô',
                            '/û/' => 'Û',
                            '/ç/' => 'Ç',
                            '/ñ/' => 'Ñ',
                            '/ò/' => 'Ò',
                            '/ò/' => 'Ò',                        
                            '/ö/' => 'Ö',                        
                            '/ø/' => 'Ø',                                                
                            '/ù/' => 'Ù',                                                                        
                            '/ü/' => 'Ü',                                                                                                
                            '/ý/' => 'Ý'
                        );
                        */
                        
            $substituir2 = array('á' => 'Á',
                            'é' => 'É',
                            'í' => 'Í',
                            'ó' => 'Ó',
                            'ú' => 'Ú',
                            'ã' => 'Ã',
                            'õ' => 'Õ',
                            'â' => 'Â',
                            'ê' => 'Ê',
                            'î' => 'Î',
                            'ô' => 'Ô',
                            'û' => 'Û',
                            'ç' => 'Ç',
                            'ñ' => 'Ñ',
                            'ò' => 'Ò',
                            'ò' => 'Ò',                        
                            'ö' => 'Ö',                        
                            'ø' => 'Ø',                                                
                            'ù' => 'Ù',                                                                        
                            'ü' => 'Ü',                                                                                                
                            'ý' => 'Ý'
                        );
                        
                            
        ///  $texto = preg_replace(array_keys($substituir2),array_values($substituir2),$str);
        $texto = preg_replace(array_keys($substituir),array_values($substituir),$str);
        /// 
        return $texto;
        /// 
    }
}    
///
///  function_exists - verifica se a  function function NAO esta ativa
if( ! function_exists("ValidaData") ) {
    /// Verificando a Data 
     function ValidaData($dat){
            ///  Verificando formato da Data com barra
            if( preg_match("/\//",$dat) ) {
                 $data = explode("/","$dat"); ///  Divide  a string $dat em pedados, usando / como referência
            }
            ///  Verificando formato da Data com hifen
            if( preg_match("/\-/",$dat) ) {
                 $data = explode("-","$dat"); ///  Divide  a string $dat em pedados, usando - como referência
            }
            $res=1;  ///  1 = true (valida)
            $coluna1=$data[0];
            if( strlen($coluna1)<3 ) {
                $d = $data[0];
                $m = $data[1];
                $y = $data[2];
            } elseif( strlen($coluna1)==4 ) {
                $y = $data[0];
                $m = $data[1];
                $d = $data[2];
            }
            if( intval($y)>2100 ) $res=0;  ///  0 = false (vinalida)
            /*
            $d = $data[0];
            $m = $data[1];
            $y = $data[2];
              */
           /// Veerifica se a data é válida!
            /// 1 = true (válida)
             /// 0 = false (inválida)
             //// if( intval($res)==1 )  $res = checkdate($m,$d,$y);
            if( intval($res)==1 ) {
                 $res = checkdate($m,$d,$y); 
            }  
            ///
            /*
               if( $res==1 ) {
                    echo "<br/>data ok! dia=$d - mes=$m - ano=$y ";
               } else {
                     echo "<br/>data inválida!";
               }
              */ 
            ////
            return $res;
     }
}
////  FINALIZANDO AS FUNCTIONS
///
////
///  INICIANDO  A PAGINA AJAX
ob_start(); /* Evitando warning */
//  Verificando se SESSION_START - ativado ou desativado
if(!isset($_SESSION)) {
   session_start();
}
// set IE read from page only not read from cache
//  header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control","no-store, no-cache, must-revalidate");
header("Cache-Control","post-check=0, pre-check=0");
header("Pragma", "no-cache");

//  header("content-type: application/x-javascript; charset=tis-620");
/// header("content-type: application/x-javascript; charset=iso-8859-1");
///  header("Content-Type: text/html; charset=ISO-8859-1",true);
header("Content-type: text/html; charset=utf-8");

///   Colocar as datas do Cadastro do Usuario e a validade
date_default_timezone_set('America/Sao_Paulo');

///  Melhor setlocale para acentuacao - strtoupper, strtolower, etc...
///  setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8");

//
//   Para acertar a acentuacao
//  $_POST = array_map(utf8_decode, $_POST);
// extract: Importa variáveis para a tabela de símbolos a partir de um array 
extract($_POST, EXTR_OVERWRITE);  
/// Mensagens para enviar 
$msg_erro = "<span class='texto_normal' style='color: #FF0000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #000000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";
/// Final - Mensagens para enviar 
///
$incluir_arq="";
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
     $msg_erro .= "Sessão incluir_arq não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
//// Verificando -  Conexao 
$elemento=5; $elemento2=6;
//// include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");     
include("php_include/ajax/includes/conectar.php");     

////  require_once('/var/www/cgi-bin/php_include/ajax/includes/tabela_pa.php');
require_once("php_include/ajax/includes/tabela_pa.php");
///
///  HOST mais a pasta principal do site - host_pasta
$host_pasta="";
if( isset($_SESSION["host_pasta"]) ) {
     $host_pasta=$_SESSION["host_pasta"];  
} else {
     $msg_erro .= "Sessão host_pasta não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
///  DEFININDO A PASTA PRINCIPAL 
/////  $_SESSION["pasta_raiz"]="/rexp_responsivo/";     
///  Verificando SESSION  pasta_raiz
if( ! isset($_SESSION["pasta_raiz"]) ) {
     $msg_erro .= "Sessão pasta_raiz não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
$_SESSION["url_central"] = "http://".$_SESSION["http_host"].$_SESSION["pasta_raiz"];
$raiz_central=$_SESSION["url_central"];
///  Conjunto de arrays 
/// include_once("../includes/array_menu.php");
include_once("{$_SESSION["incluir_arq"]}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) $array_pa = $_SESSION["array_pa"];    
///
/// Conjunto de Functions
// require_once("../script/stringparabusca.php");	
///  
///  require_once("../includes/functions.php");    
require_once("{$_SESSION["incluir_arq"]}includes/functions.php");  

///  Definindo as variaveis
$post_array = array("source","val","m_array");
for( $i=0; $i<count($post_array); $i++ ) {
    $xyz = $post_array[$i];
    //  Verificar strings com simbolos: # ou ,   para transformar em array PHP    
    $xyz=="m_array" ? $div_array_por = "#" : $div_array_por = ",";
    if ( isset($_POST[$xyz]) ) {
	    $pos1 = stripos(trim($_POST[$xyz]),$div_array_por);
	   if ( $pos1 === false ) {
	       //  $$xyz=trim($_POST[$xyz]);
		   //   Para acertar a acentuacao - utf8_encode
           $$xyz = utf8_decode(trim($_POST[$xyz])); 
	   } else  $$xyz = explode($div_array_por,$_POST[$xyz]);
	}
}
//
///   Para acertar a acentuacao - utf8_encode
//   $source = utf8_decode($source); $val = utf8_decode($val); 

if( strtoupper($val)=="SAIR" ) $source=$val;

$_SESSION["source"]=trim($source);
$source_upper=strtoupper($_SESSION["source"]);
if( isset($val) ) $val_upper=strtoupper(trim($val));
///
///  INCLUINDO CLASS - 
require_once("{$_SESSION["incluir_arq"]}includes/autoload_class.php");  
if( class_exists('funcoes') ) {
    $funcoes=new funcoes();
}
///
///   Sair do programa
if( $source_upper=="SAIR" ) {
    // Eliminar todas as variaveis de sessions
    $_SESSION=array();
    session_destroy();
    if( isset($total) ) unset($total);
    if( isset($login_senha) ) unset($login_senha); 
    if( isset($login_down) ) unset($login_down); 
    if( isset($senha_down) )  unset($senha_down); 
	//
	//  echo  "<a href='http://www_gen.fmrp.usp.br'  title='Sair' >Sair</a>";
    response.setHeader("Pragma", "no-cache"); 
    response.setHeader("Cache-Control", "no-cache"); 
    response.setDateHeader("Expires",0); 
	//  echo  "http://www_gen.fmrp.usp.br/";
	exit();
}
//
//  Serve tanto para o arquivo projeto  quanto para o experimento
//  if(  ( $source_upper=="COAUTORES" ) or  ( $source_upper=="COLABS" ) ) {	
if( ( $source_upper=="CORESPONSAVEIS" ) or  ( $source_upper=="COLABS" ) ) {	
    ///  $m_co = "Co-responsáveis";
    /// $m_co = "Co-resp.";
    $m_co = "Co-resp.";
    ///  if( $source_upper=="COLABS" )    $m_co = "Colaboradores";
    if( $source_upper=="COLABS" ) $m_co = "Colab.";
    ///  Cod/Num_USP/Coautor
    $elemento=5;
    /*   Atrapalha e muito essa programacao orientada a objeto
        include('/var/www/cgi-bin/php_include/ajax/includes/class.MySQL.php');
       $result = $mySQL->runQuery("select codigousp,nome,categoria from pessoa  order by nome ");
   */
    ///  include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");
    include("php_include/ajax/includes/conectar.php");
    ////  mysql_select_db($db_array[$elemento]);
    ///  mysql_db_query - Esta funcao e obsoleta, nao use esta funcao - Use mysql_select_db() ou mysql_query()
   /////           
    mysql_query("SET NAMES 'utf8'");
    mysql_query('SET character_set_connection=utf8');
    mysql_query('SET character_set_client=utf8');
    mysql_query('SET character_set_results=utf8');
    ///                         
    $result=mysql_query("Select codigousp,nome,categoria from $bd_1.pessoa  order by nome ");
    if( ! $result ) {
         //// die('ERRO: Select pessoa - falha: '.mysql_error());  
         echo $funcoes->mostra_msg_erro("Select tabela pessoa falha&nbsp;-&nbsp;db/mysql:&nbsp;".mysql_error());
         exit();   
    }
    /// Numero de registros
    $m_linhas = mysql_num_rows($result);
    if( intval($m_linhas)<1 ) {
        echo "Nenhum encontrado";
        exit();      
    }
    /// Definindo alguns campos
    while( $linha=mysql_fetch_assoc($result) ) {
          $arr["codigousp"][]=htmlentities($linha['codigousp']);
          $arr["nome"][]=  ucfirst(htmlentities($linha['nome']));
          $arr["categoria"][]=$linha['categoria'];
    }
    $count_arr = count($arr["codigousp"])-1;	 
    $x_float2 = (float) (.5);  $acrescentou=0;
    $n_tr = (float) ($val/2);
    if(  ! is_int($n_tr) ) {
         $n_tr=$n_tr+$x_float2;
         $acrescentou=1;
    }
    ///  $n_y=0;$texto=0; $n_tr= (int) $val;
	$n_y=0;$texto=0; $n_tr= (int) $n_tr;
    for( $x=1; $x<=$n_tr; $x++ ) {
          $n_y=$texto; $n_td=4;
          ///  if( $n_tr==1 ) $n_td=2;
          /// $n_td=2;
          $n_tot=$n_td/2;
          for( $y=1; $y<=$n_tot ; $y++ ) {
                $texto=$n_y+$y;
                if( ( $acrescentou==1 ) and  ( $texto>$val ) ) {
                    ////  echo "<td class='td_inicio1' >&nbsp;</td>"; 
                    continue;
                }
                $n_tot2=1;
                for( $z=1; $z<=$n_tot2 ; $z++ ) {
                ?>
                   <article class="projetoarticle3" >
                      <label for="ncoautor[<?php echo $texto;?>]"  >&nbsp;<?php echo "$m_co $texto";?>:</label>
                      <span>
                        <!-- N. Funcional USP - COautor ou Colaborador  -->
                       <select name="ncoautor[<?php echo $texto;?>]" id="ncoautor[<?php echo $texto;?>]"  class="td_select"    style="overflow:auto;font-size: small;"  title="<?php echo "$m_co $texto"; ?>"  >  
                       <?php
                        if( intval($m_linhas)<1 ) {
                             echo "<option value='' >== Nenhum encontrado ==</option>";
                        } else {
                             echo "<option value='' >== Selecionar ==</option>";
                            /// for ( $jk=0 ; $jk<$m_linhas ; $jk++) {
                            for( $jk=0; $jk<=$count_arr; $jk++ ) {
					             /// $m_codigousp = htmlentities($arr["codigousp"][$jk]);
                                 $m_codigousp = htmlentities($arr["codigousp"][$jk]);
                                 $m_categoria=$arr["categoria"][$jk];
				                 $m_categ = "Categ.: ".html_entity_decode(utf8_decode($m_categoria));	
                                 ////  $m_nome=ucfirst(htmlentities($arr["nome"][$jk]));		   		   
                                 ///  $m_nome=ucfirst(html_entity_decode($arr["nome"][$jk]));  
                                 $m_nome=trim($arr["nome"][$jk]);
                                 /*  IMPORTANTE: comando para para converter acentos 
                                         html_entity_decode(utf8_decode($m_nome))
                                 */
                                 echo "<option  value=".$m_codigousp." >".html_entity_decode(utf8_decode($m_nome));
                                 echo  "&nbsp;-&nbsp;".$m_categ."&nbsp;</option>" ;
                                 ///
                            }
                      ?>
                      </select>
                      <?php
                      }
                      /// Final da Num_USP/Coautor
                    ?>  
                   </span>
                   </article>
                      <?php                      
                  } /// Final do If TD  - numero USP/Coautor
               }
           }            
           ////
     exit();
}   ///  FINAL do IF  $source_upper=="CORESPONSAVEIS"  or   $source_upper=="COLABS" 
///
///  Cadastrar um PROJETO  
if( $val_upper=="PROJETO" ) {    
        /*     
         AGORA o Melhor jeito de acertar a acentuacao - htmlentities(utf8_decode
         e de depois usa o  - html_entity_decode 
    */
     $campo_nome = htmlentities(utf8_decode($campo_nome));
     $campo_value = htmlentities(utf8_decode($campo_value));
     $campo_nome = substr($campo_nome,0,strpos($campo_nome,",enviar"));
     $array_temp = explode(",",$campo_nome);
     $array_t_value = explode(",",$campo_value);
     $count_array_temp = sizeof($array_temp);
     for( $i=0; $i<$count_array_temp; $i++ )   $arr_nome_val[$array_temp[$i]]=$array_t_value[$i];
     //
     //   Vericando se o NOme se ja esta cadastrado  na Tabela usuario
     //   Importante no PHP strtoupper, str trim  e no MYSQL  replace,upper,trim
     $m_titulo=strtoupper(trim($arr_nome_val['titulo']));
     $fonterec=strtoupper(trim($arr_nome_val['fonterec']));    
     $fonteprojid=strtoupper(trim($arr_nome_val['fonteprojid']));    
     $m_autor=strtoupper(trim($arr_nome_val['autor']));
     $_SESSION["numprojeto"]=strtoupper(trim($arr_nome_val['numprojeto']));
     //   MELHOR JEITO PRA ACERTAR O CAMPO NOME
     //   function para caracteres com acentos passando para Maiusculas
     //  '/&aacute;/i' => 'Á',
     //  $m_texto=strtoupper($pessoa_nome);
     $m_titulo = stringParaBusca2($m_titulo);
     $fonterec = stringParaBusca2($fonterec);    
     $m_autor=stringParaBusca2($m_autor);
     $m_titulo =html_entity_decode(trim($m_titulo));
     $fonterec =html_entity_decode(trim($fonterec));
     $fonteprojid=strtoupper(trim($arr_nome_val['fonteprojid']));    
     $m_autor =html_entity_decode(trim($m_autor));
     ///  Corrigir onde tiver strtotime - usado somente para ingles       
     $data_de_hoje = date('d/m/Y');
     $data_de_hoje = explode('/',$data_de_hoje);
     $time_atual = mktime(0, 0, 0,$data_de_hoje[1], $data_de_hoje[0], $data_de_hoje[2]);
     // Usa a função criada e pega o timestamp das duas datas:
     $time_inicial="";
     $m_datainicio=""; $m_datafinal="";
     if( isset($arr_nome_val["datainicio"]) ) {
          if( strlen(trim($arr_nome_val["datainicio"]))>5 ) {
               /// Divide a string $datainicio em pedados, usando / como referência
             ///    $dt_inicio = explode('/',$arr_nome_val["datainicio"]);
   
              ///  $time_inicial = mktime(0, 0, 0,$dt_inicio[1], $dt_inicio[0], $dt_inicio[2]);            
               $m_datainicio=trim($arr_nome_val['datainicio']);
               /// Veerifica se a data é válida!
               ///  1 = true (válida)
              ///   0 = false (inválida)
               $res=1;
               if( preg_match("/\//",$m_datainicio)  ) {
                    $n_barra=substr_count($m_datainicio,"/");
                    $m_datainicio=preg_replace('/\//','-',$m_datainicio);
                    if( intval($n_barra)<>2  ) $res=0;
               } 
               ///            
               sleep(3);
               if( preg_match("/\-/",$m_datainicio)  ) { 
                        $n_hifen=substr_count($m_datainicio,"-");
                        if( intval($n_hifen)<>2 ) $res=0;  
               }    
               //// Caso NAO ocorreu erroa acima executar function
              if( intval($res)==1 ) $res=ValidaData($m_datainicio);
             ///  Verificando formato da Data com barra
             ///  Ocorreu ERRO
             if( intval($res)<1 ) {
                   $msg_erro .= "Data inicial inv&aacute;lida  ".$arr_nome_val["datainicio"].$msg_final;
                   echo $msg_erro;
                   exit();   
              }
              
              /*
               $ano_dtinicio=substr($m_datainicio,6,4);
               $mes_dtinicio=substr($m_datainicio,3,2);
               $dia_dtinicio=substr($m_datainicio,0,2);
               */
               
             ////  $m_datainicio=substr($m_datainicio,6,4)."-".substr($m_datainicio,3,2)."-".substr($m_datainicio,0,2);
               //  $m_datainicio=substr($m_datainicio,4,4)."-".substr($m_datainicio,2,2)."-".substr($m_datainicio,0,2);
          }
         // IF abaixo Correto
         if( strlen(trim($arr_nome_val["datainicio"]))>=1 and  strlen(trim($arr_nome_val["datainicio"]))<6 ) { 
                $msg_erro .= "Data inicial inv&aacute;lida  ".$arr_nome_val["datainicio"].$msg_final;
                echo $msg_erro;
                exit();   
          }        
     }
     ////
     $m_final="";
     if( isset($arr_nome_val["datafinal"]) ) {     
        /*
        if( $time_inicial>$time_atual ) {
            $msg_erro .= "Data do in&iacute;cio do Projeto posterior a data atual.  Corrigir".$msg_final;
            echo $msg_erro;
            exit();
        }
        */
         /* Converter Data PHP para Mysql   */
         if( strlen(trim($arr_nome_val['datafinal']))>5 ) {
              ///  $m_final=$arr_nome_val['datafinal'];
              /// Divide a string $datainicio em pedados, usando / como referência
              ///  $m_final=explode('/',$arr_nome_val["datafinal"]);
                $m_datafinal=trim($arr_nome_val['datafinal']);
               /// Veerifica se a data é válida!
               ///  1 = true (válida)
              ///   0 = false (inválida)
               $res=1;
               if( preg_match("/\//",$m_datafinal)  ) {
                    $n_barra=substr_count($m_datafinal,"/");
                    $m_datafinal=preg_replace('/\//','-',$m_datafinal);
                    if( intval($n_barra)<>2  ) $res=0;
               } 
               ///            
               sleep(3);
               if( preg_match("/\-/",$m_datafinal)  ) { 
                        $n_hifen=substr_count($m_datafinal,"-");
                        if( intval($n_hifen)<>2 ) $res=0;  
               }    
               //// Caso NAO ocorreu erroa acima executar function
              if( intval($res)==1 ) $res=ValidaData($m_datafinal);
             ///  Verificando formato da Data com barra
             ///  Ocorreu ERRO
             if( intval($res)<1 ) {
                   $msg_erro .= "Data final inv&aacute;lida  ".$arr_nome_val['datafinal'].$msg_final;
                   echo $msg_erro;
                   exit();   
              }
               /////   $m_final=substr($m_final,6,4)."-".substr($m_final,3,2)."-".substr($m_final,0,2);         
          }
          //// IF abaixo Correto
          if( strlen(trim($arr_nome_val["datafinal"]))>=1 and  strlen(trim($arr_nome_val["datafinal"]))<6 ) { 
               $msg_erro .= "Data final inv&aacute;lida  ".$arr_nome_val["datafinal"].$msg_final;
               echo $msg_erro;
               exit();   
          }                  
     }
     ///  $time_final = geraTimestamp($data_final);
     // $dt_atual= strtotime($data_de_hoje);
     //  $dt_inicio= strtotime($arr_nome_val["datainicio"]);
     //  Variavel para incluir na Tabela anotador no campo PA
     $lnpa = $_SESSION["permit_pa"];
    //  Verificando campos 
    //  coresponsaveis para incluir na Tabela corespproj
    $m_erro=0;
    if( isset($arr_nome_val["coresponsaveis"]) ) {
        $coresponsaveis =$arr_nome_val["coresponsaveis"];  
        if( $coresponsaveis>=1 ) {
            $n_coresponsaveis=explode(",",$m_array);
            $count_coresp = count($n_coresponsaveis);
            for( $z=0; $z<$count_coresp ; $z++ ) {
                if( strlen($n_coresponsaveis[$z])<1 ) {
                    $m_erro=1;
                    break;
                } 
            }                
        }
        if( $m_erro==1 ) {
              $msg_erro .= "&nbsp;Falta incluir co-respons&aacute;vel.".$msg_final;
              echo $msg_erro;
              exit();
        }      
    }
    ///    
    $elemento=5; $elemento2=6; $m_regs=0;
    ///  include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");
    include("php_include/ajax/includes/conectar.php");
    ////  Verificando se foi digitado o campo com a Data inicio do Projeto
    if( ! isset($m_datainicio) ) {
        // $m_datainicio="--";
        $m_datainicio="0000-00-00";
    } else {
        if( strlen(trim($m_datainicio))<10 ) {
            ///  $m_datainicio="--";
            $m_datainicio="0000-00-00";
        }
    }
    ///
    $objetivo = $arr_nome_val["objetivo"];
    /* 
         Verificando duplicata Projeto 
         os campos (objetivo, fonterec, fonteprojid, autor e m_datainicio) 
    */   
    $result=mysql_query("SELECT  cip,autor,titulo as titulo_outro, numprojeto as projeto_outro  "
                     ." FROM $bd_2.projeto WHERE "
                     ." objetivo={$objetivo}  and  "
                     ." trim(fonterec)=trim('".$fonterec."')  and  "
                     ." trim(fonteprojid)=trim('".$fonteprojid."') and "
                     ." autor=".$m_autor." and datainicio='$m_datainicio'  ");
    //                 
    // Verificando se houve erro no Select Tabdla Usuario
    if( ! $result ) {
        $msg_erro .= "Select Tabela projeto - Falha: ".mysql_error().$msg_final;
        echo $msg_erro;
        exit();
    }  
    $m_regs=mysql_num_rows($result);
    ///   Verificando se encontrou duplicatas
    if( $m_regs>=1 ) {
            $outro_titulo=mysql_result($result,0,"titulo_outro");
            $projeto_outro=mysql_result($result,0,"projeto_outro");
            if( isset($result) ) mysql_free_result($result);
            $result=mysql_query("SELECT  descricao FROM $bd_2.objetivo WHERE  codigo={$objetivo}  ");
            //                 
            // Verificando se houve erro no Select Tabdla Usuario
            if( ! $result ) {
                 /*
                  $msg_erro .= "Select tabela objetivo - falha: ".mysql_error().$msg_final;
                  echo $msg_erro;
                  */
            echo $funcoes->mostra_msg_erro("Select tabela objetivo falha&nbsp;-&nbsp;db/mysql:&nbsp;".mysql_error());
                 exit();            
            }  
            $descricao=mysql_result($result,0,"descricao");
           ///   Caso existe outro projeto com os mesmos dados
           $msg_erro .= "&nbsp;Existe outro Projeto&nbsp;nr.&nbsp;{$projeto_outro}&nbsp;<br>"
                       ."com esse T&iacute;tulo:&nbsp;{$outro_titulo}<br>"
                       ."j&aacute; est&aacute; cadastrado com esses dados&nbsp;(Autor, Objetivo, Fonte, Nr. Processo, Data In&iacute;cio).".$msg_final;
           echo $msg_erro;
          exit();
     } else {
          ////  Continuacao Tabela projeto - BD PESSOAL
          /*   MELHOR jeito de acertar a acentuacao - html_entity_decode    */    
          //  Caso tenha coautores/coresponsaveis no Projeto
          include("n_cos.php");
          //  SESSION abaixo para ser usada no include
          $_SESSION["tabela"]="$bd_2.projeto";
          include("dados_recebidos_arq_ajax.php"); 
          /// 
/*          
   echo "ERRO:  LINHA/662  -  \$_SESSION[campos_nome]  =  {$_SESSION["campos_nome"]} <br/> \$_SESSION[campos_valor] = {$_SESSION["campos_valor"]}  ";
   exit();       
  */        
          
          ///  Verificando o numero de coresponsaveis/coautores
          //  INSERIR USUARIO  
          //  mysql_db_query - Esta funcao e obsoleta, nao use esta funcao - Use mysql_select_db() ou mysql_query()
          $result_usu = mysql_query("SELECT codigousp from  $bd_1.usuario  WHERE  codigousp=$m_autor   ");
          // Verificando se houve erro no Select Tabdla Usuario
          if( ! $result_usu ) {
                $msg_erro .= "&nbsp; Select Tabela usuario  -  db/mysql:&nbsp;".mysql_error().$msg_final;
                echo $msg_erro;
                exit();
          }
          /// Numero de registros  
          $m_regs = mysql_num_rows($result_usu); 
          ///  Verficando Orientador
          if( $m_regs<1 ) { 
               $msg_erro .= "Orientador n&atilde;o cadastrado.".$msg_final;
               echo $msg_erro;
          } else {
                if( isset($_SESSION["numprojeto"]) ) $numprojeto=$_SESSION["numprojeto"];
                $n_erro=0;
                
/*                
  echo "ERRO: projeto_cadastrar_ajax.php  --- \$m_autor = $m_autor   -> \$numprojeto = $numprojeto  ---  \$count_coresp = $count_coresp  --- \$n_coresponsaveis = $n_coresponsaveis  ---  \$bd_1 = $bd_1  ---   \$bd_2 = $bd_2  ";
  exit();
          */
                /////           
                mysql_query("SET NAMES 'utf8'");
                mysql_query('SET character_set_connection=utf8');
                mysql_query('SET character_set_client=utf8');
                mysql_query('SET character_set_results=utf8');
                ///                         

                $campos_nome=$_SESSION["campos_nome"];
                ////  $campos_valor=utf8_decode($_SESSION["campos_valor"]);
                ///  IMPORTANTE:  html_entity_decode para variavel PHP para MySql
                $campos_valor=html_entity_decode($_SESSION["campos_valor"], ENT_QUOTES, "UTF-8");
                ////   $campos_valor=$_SESSION["campos_valor"];
                
                ////  START a transaction - ex. procedure    
                mysql_query('DELIMITER &&'); 
                mysql_query('begin'); 
                ///
                ///  Execute the queries 
                mysql_select_db($db_array[$elemento]);

                //  mysql_db_query - Esta funcao esta obsoleta, nao use esta funcao 
                //   - Use mysql_select_db() ou mysql_query()
                mysql_query("LOCK TABLES $bd_2.projeto WRITE, $bd_2.corespproj WRITE ");
                
                ///  IMPORTANTE: usar utf8_encode enviar dados do PHP para MySql
                $sqlcmd="INSERT into $bd_2.projeto  (".$campos_nome.") values(".utf8_encode($campos_valor).") ";
                
                ///  $sqlcmd="INSERT into $bd_2.projeto  ($campos_nome) values($campos_valor) ";
                $success=mysql_query($sqlcmd); 
                //  Complete the transaction 
                if( $success ) { 
                      ///  Cadastrando na tabela corespproj os coresponsaveis
                      if( isset($count_coresp) ) {
                          if( intval($count_coresp)>=1  ) {
                               for( $x=0; $x<$count_coresp;  $x++ ) {
                                   $ncod_resp=$n_coresponsaveis[$x];
                                   $result=mysql_query("INSERT into $bd_2.corespproj values(".$m_autor.", ".$numprojeto.", ".$ncod_resp.")");
                                   if( !$result ) {
                                        $n_erro=1; 
                                        $msg_erro .="&nbsp;CORESP. n&atilde;o foi cadastrado (autor/projeto/coresp):".$m_autor.", ".$_SESSION["numprojeto"].", ".$n_coresponsaveis[$x].mysql_error().$msg_final;
                                        ///  Cancelar inclusao
                                        mysql_query('rollback'); 
                                        echo  $msg_erro;
                                   }
                               }
                          }                            
                      }
                      if( intval($n_erro)<1 ) {
                          ///  Permitir inclusao
                          mysql_query('commit');                                  
                      }
                } else {
                    $n_erro=1;
                    ///  Cancelar inclusao
                    mysql_query('rollback'); 
                }              
                mysql_query("UNLOCK  TABLES");
                mysql_query('end'); 
                mysql_query('DELIMITER');
                //
                if( intval($n_erro)==1 ) {
                     $msg_erro .="&nbsp;Projeto <b>N&Atilde;O</b> foi cadastrado. ERRO#1 = ".mysql_error().$msg_final;
                     echo $msg_erro;               
                } else {
                     //  IINCLUINDO arquivo para a Anotacao do Projeto 
                    //  projeto, autor/orientador e numero da anotacao
                    $m_regs=0;
                    /*
                    $result_proj=mysql_query("SELECT  cip,autor,numprojeto FROM $bd_2.projeto WHERE "
                                ." trim(fonterec)=trim('".$fonterec."')  and  "
                                ." trim(fonteprojid)=trim('".$fonteprojid."') and "
                                ." autor=".$m_autor." and datainicio='$m_datainicio' and datafinal='$m_final'  ");
                     */                                
                    $result_proj=mysql_query("SELECT  cip,autor,numprojeto FROM $bd_2.projeto WHERE "
                                    ." autor=$m_autor and numprojeto=$numprojeto  ");
                     if( ! $result_proj  ) {
                        $msg_erro .= "&nbsp; Select Tabela projeto  -  db/mysql:&nbsp;".mysql_error().$msg_final;
                        echo $msg_erro;
                        exit();
                         
                     }                                    
                    ///  Numero de registros               
                    $m_regs=mysql_num_rows($result_proj);
                    ////
                    if( intval($m_regs)==1 ) {
                         $projeto_cip=mysql_result($result_proj,0,"cip");       
                         if( isset($result_proj) )  mysql_free_result($result_proj);
                         ///  Variavel para a data e hora atual                       
                         $data_atual=date("Y-m-d H:i:s"); //  Data de hoje e horario  
                        ////  START a transaction - ex. procedure    
                        mysql_query('DELIMITER &&'); 
                        mysql_query('begin'); 
                        //  Execute the queries 
                        mysql_query("LOCK TABLES $bd_2.anotador WRITE ");
                        $sqlcmd="INSERT into $bd_2.anotador (cip,codigo,pa,data) values($projeto_cip,$m_autor,$lnpa,'$data_atual')";
                        $res_anotador=mysql_query($sqlcmd); 
                        if( $res_anotador )  {
                              mysql_query('commit');       
                               ///  Enviando a mensagem para depois Incluir o relatorio em formato PDF
                              $msg_oknew ="<span class=\"titulo_usp\"  >";
                              $msg_oknew .="&nbsp;Para concluir o Projeto.<br/>Enviar o arquivo em formato PDF.</span>";
                              $msg_oknew .="falta_arquivo_pdf".$numprojeto."&".$m_autor;
                              echo $msg_oknew;
                               ///
                         } else {
                             $msg_erro .="&nbsp;Anotador <b>N&Atilde;O</b> foi cadastrado.".mysql_error().$msg_final;
                             echo $msg_erro;                                   
                             mysql_query('rollback');                             
                         }                   
                         mysql_query("UNLOCK  TABLES");
                         mysql_query('end'); 
                         mysql_query('DELIMITER');
                         ///
                    } else {
                         $msg_erro .="&nbsp;Projeto <b>N&Atilde;O</b> encontrado.".mysql_error().$msg_final;
                         echo $msg_erro;                                   
                    }
                }
                ///  FINAL -  TABELA PROJETO  -  BD  REXP
       }                     
    }
    ///
}  ///      //  FINAL IF TABELA projeto  -  BD  REXP 
///  

ob_end_flush(); /* limpar o buffer */
///
?>