<?php 
/*   REXP - CADASTRAR PESSOAL   
* 
*   LAFB&SPFB110906.1146 - Incluindo campo PA 
* 
*/
//  ==============================================================================================
//  
//  ==============================================================================================
//
//  Verificando se sseion_start - ativado ou desativado
if(!isset($_SESSION)) {
   session_start();
}
///
///  HOST mais a pasta principal do site
$host_pasta="";
if( isset($_SESSION["host_pasta"]) ) $host_pasta=$_SESSION["host_pasta"];

///
$incluir_arq="";
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
    echo "Sess?o incluir_arq n?o est? ativa.";
    exit();
}
///
include("{$_SESSION["incluir_arq"]}inicia_conexao.php");
////

///    MENU HORIZONTAL
include("{$_SESSION["incluir_arq"]}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) $array_pa = $_SESSION["array_pa"];    
//
$_SESSION["m_horiz"] = $array_projeto;

//  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anota??o";
/// $_SESSION['time_exec']=180000; 
$pagina_local =  "http://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];
///
///  Alterado em  20170222 - Funcionu no Windows e no Linux - Acentuacao   
?>
<!DOCTYPE html>
<html lang="pt-br" >
<head>
<meta charset="utf-8" />
<meta name="author" content="Sebastiao Paulo" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" CONTENT="NO-CACHE">
<meta name="ROBOTS" CONTENT="NONE"> 
<meta http-equiv="Expires" CONTENT="-1" >
<meta name="GOOGLEBOT" CONTENT="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>REXP - Cadastrar Pessoa</title>
<!--  <script type="text/javascript"  language="javascript"   src="../js/dochange_new.js" ></script>   -->
<link  type="text/css"  href="<?php echo $host_pasta;?>css/estilo.css" rel="stylesheet"  />
<!--  <link  type="text/css"   href="../css/style_titulo.css" rel="stylesheet"  />  -->
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/XHConn.js" ></script>
<script  type="text/javascript"  src="<?php echo $host_pasta;?>js/functions.js" charset="utf-8"  ></script>
<!--  <script  type="text/javascript"  src=" echo $host_pasta;?>js/pessoal_cadastrar.js" ></script>   -->
<!--  <script  type="text/javascript" src="<?php echo $host_pasta;?>js/formata_data.js"></script>  -->
<script type='text/javascript'  src='<?php echo $host_pasta;?>js/1/jquery.min.js?ver=1.9.1'></script>
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/responsiveslides.min.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/resize.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/verifica_mobile.js" ></script>
<?php
///  Arquivo javascript em PHP
////  include("{$_SESSION["incluir_arq"]}js/pessoal_cadastrar_js.php");
include("{$_SESSION["incluir_arq"]}js/pessoal_cadastrar_js.php");
///
$_SESSION["n_upload"]="ativando";
require_once("{$_SESSION["incluir_arq"]}includes/dochange.php");
///
?>
</head>
<body  id="id_body"    oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"    onkeydown="javascript: no_backspace(event);"   >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho -->
<div id="cabecalho"  >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("../includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div id="corpo" >
<?php 
//   CADASTRAR PESSOAL
/*
if( strlen(trim($_GET["m_titulo"]))>1 )  $_SESSION["m_titulo"]=$_GET["m_titulo"];  
if( strlen(trim($_POST["m_titulo"]))>1 )  $_SESSION["m_titulo"]=$_POST["m_titulo"];  
*/
if( isset($_GET["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_GET["m_titulo"];    
} elseif( isset($_POST["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_POST["m_titulo"];      
}  
//   
$_SESSION["cols"]=4;	
$lc_cols=$_SESSION["cols"];
//  Tabela PESSOA mas passa como PESSOAL
$_SESSION["onsubmit_tabela"]="PESSOAL";	  
?>
<!--  Mensagem de ERRO     -->
<section class="merro_e_titulo" >
<div  id="label_msg_erro"  >
</div>
<p class='titulo_usp' >Cadastrar&nbsp;<?php echo ucfirst($_SESSION["m_titulo"]);?></p>
</section>
<div id="div_form" class="div_form" style="" >
<?php
//   Colocar as datas do Cadastro do Usuario e a validade
date_default_timezone_set('America/Sao_Paulo');
//  Formatando a Data no formato para o Mysql
$dia = date("d");
$mes = date("m");
$ano = date("Y"); 
$ano_validade=$ano+2;
$_SESSION['datacad']="$ano-$mes-$dia";
$_SESSION['datavalido']="$ano_validade-12-31";
$_SESSION["VARS_AMBIENTE"] = "instituicao|unidade|depto|setor|bloco|salatipo|sala";		 
$vars_ambiente=$_SESSION["VARS_AMBIENTE"];
//
//  PA:  superusuario,  chefe,  subchefe, orientador, anotador  -  includes/array_menu.php
//  if( $_SESSION[permit_pa]>=$_SESSION[array_usuarios][superusuario]  and  $_SESSION[permit_pa]<=$_SESSION["array_usuarios"]["orientador"]  ) {
//  if( $_SESSION["permit_pa"]<=$_SESSION["array_usuarios"]["orientador"]  ) {
if( $_SESSION["permit_pa"]<=$array_pa["orientador"]  ) {        
  ?>
<form name="form1" id="form1"  enctype="multipart/form-data"  method="post"  onsubmit="javascript: enviar_dados_cad('submeter','<?php echo $_SESSION["onsubmit_tabela"];?>',document.form1); return false"   >
   <section>
       <article class="projetoarticle1"   >
           <!-- CODIGO/USP - digitar -->
         <label for="codigousp"  >C&oacute;digo/USP:&nbsp;</label><br/>
      <input type="number" size="14"  pattern="[0-9]{1,14}"  maxlength="14" name="codigousp"   id="codigousp" 
       onblur="javascript: this.value=trim(this.value);" title="C?digo/USP"  autocomplete="off"  style="cursor: pointer;" 
        autofocus="autofocus"  />
      <span class="example" >*Obs. C&oacute;digo sem d&iacute;gito. Caso n&atilde;o tenha, deixar vazio</span>
          <!-- Final - CODIGO/USP -->
       </article>
       <article class="projetoarticle1"   >
           <!--  Nome da Pessoa -->
               <label for="nome"  >Nome:&nbsp;</label><br />
               <input type="text" name="nome"   id="nome"  value=""  size="75" required="required"  maxlength="64"  
                title="Digitar Nome"   onkeypress="javascript: trimnovo(this);"   autocomplete="off"   />
              <!-- Final - Nome -->
       </article>          
       <article class="projetoarticle1"   >
            <!-- SEXO -->
            <label for="sexo" >Sexo:</label>
                <select name="sexo"   id="sexo"   title="Selecionar Sexo" required="required"   >
                      <option value="" >Selecione... </option>
                      <option value="F" >Feminino</option>
                      <option value="M" >Masculino</option>
                </select>   
               <!-- Final - Sexo -->
       </article>
       <article class="projetoarticle1"   >
          <?php
              ///  CATEGORIA => Cargo/Fun??o
               $elemento=5;
               include("php_include/ajax/includes/conectar.php");  
               /////           
                mysql_query("SET NAMES 'utf8'");
                mysql_query('SET character_set_connection=utf8');
                mysql_query('SET character_set_client=utf8');
                mysql_query('SET character_set_results=utf8');
                ///                         
               $result=mysql_query("SELECT codigo,descricao FROM  $bd_1.categoria order by codigo ");
               ///                
          ?>
          <span class="td_informacao2"  >
              <label for="categoria"  >Categoria:</label>
              <select name="categoria" class="td_select" id="categoria"  title="Selecionar Categoria" required="required"  >
                  <?php
                      ///  Categoria
                      $m_linhas = mysql_num_rows($result);
                      if( intval($m_linhas)<1 ) {
                          echo "<option value='' >Nenhuma Categoria definida.</option>";
                      } else {
                      ?>
                      <option value='' >Selecione...</option>
                      <?php
                           /// Usando arquivo com while e htmlentities
                           $_SESSION["siglaounome"]="CATEGORIA";
                          //// include("{$_SESSION["incluir_arq"]}includes/tag_select_tabelas.php");
                          
                          ///   Arquivo para a Tag Select das Tabelas: Instituicao, Unidade, Depto, pessoa, categoria
                            $num_campos=mysql_num_fields($result);
                            if( intval($num_campos)==1 ) {
                               $cpo_nome_descr=mysql_field_name($result,0);        
                            } elseif( intval($num_campos)>1 ) {
                                 $codigo_sigla=mysql_field_name($result,0);
                                 $cpo_nome_descr=mysql_field_name($result,1);
                            }
                            /*
                            while($linha=mysql_fetch_array($result)) {       
                                  //  htmlentities - o melhor para transferir na Tag Select
                                  $sigla= htmlentities($linha['sigla']);  
                                  $nome= htmlentities($linha['nome']);  
                                  echo "<option  value=".urlencode($linha['sigla'])."  "
                                          ."  title='$sigla - $nome'  >";
                                  echo  "&nbsp;".$linha['sigla']."&nbsp;</option>" ;
                            }
                            */
                            while($linha=mysql_fetch_array($result)) {       
                                  ///  htmlentities - o melhor para transferir na Tag Select  
                                  ////  $nome=urlencode(trim($linha[$cpo_nome_descr]));  
                                  ///  $nome= $linha[$cpo_nome_descr];  
                                  
                                   ///  Alterado no DEPTO 20170222 - 11h30 - Funcionou
                                   ///  $nome = htmlentities($linha[$cpo_nome_descr], ENT_QUOTES | ENT_IGNORE, "UTF-8");
                                   $nome = $linha[$cpo_nome_descr];
                                    //// $nome = html_entity_decode($linha[$cpo_nome_descr]);
                                  ///  $nome = htmlspecialchars($linha[$cpo_nome_descr]);
                                  /// $nome = $linha[$cpo_nome_descr];
                                  if( intval($num_campos)>1 ) {
                                      $sigla= htmlentities($linha[$codigo_sigla]);  
                                       echo "<option  value=".urlencode($linha[$codigo_sigla])."  "
                                          ."  title='$sigla - $nome'  >";
                                       $descricao = $sigla;         
                                  } 
                                  if( intval($num_campos)==1 ) {
                                     ///  echo  "<option  value=".urlencode(htmlspecialchars($nome))."  title=".$nome."  >";
                                      echo  "<option  value='$nome' title='$nome' >";
                                      ///// $descricao = $nome;         
                                       $descricao = $nome;         
                                  }    
                                 ////
                                 if( isset($_SESSION["onsubmit_tabela"]) ) {
                                     /*   Alterado em 20170123  - Em vez de nome passando para sigla    */
                                     ///  if( strtoupper(trim($_SESSION["onsubmit_tabela"]))=="PESSOAL" ) $descricao = $nome; 
                                    ////// $descricao = $sigla; 
                                     if( strtoupper(trim($_SESSION["onsubmit_tabela"]))=="PESSOAL" ) {
                                         if( isset($_SESSION["siglaounome"]) ) {
                                             $siglaounome=$_SESSION["siglaounome"];
                                             if( strtoupper($siglaounome)=="CATEGORIA" )  $descricao = $nome; 
                                         }
                                     }
                                 } 
                                 ////  echo  nl2br($descricao)."</option>" ;
                                /// echo  htmlentities($descricao, ENT_QUOTES | ENT_IGNORE, "UTF-8")."</option>";
                                 ///  echo  htmlspecialchars_decode($descricao)."</option>";
                                 /*     Detectar codificação de caracteres            */
                                 $codigo_caracter=mb_detect_encoding($descricao);
                                 if( trim(strtoupper($codigo_caracter))!="UTF8" ) {
                                      ///  Converter  para  UFT-8
                                      ///  echo  htmlentities($descricao, ENT_QUOTES | ENT_IGNORE, "UTF-8")."</option>";
                                      ///  echo html_entity_decode($descricao, ENT_COMPAT, 'UTF-8')."</option>";
                                      //// echo html_entity_decode($descricao, ENT_QUOTES, 'UTF-8')."</option>";
                                      echo  htmlentities($descricao,ENT_QUOTES,"UTF-8")."</option>";
                                     
                                          ///         echo  "$descricao</option>";   
                                       ///    echo  html_entity_decode($descricao, ENT_QUOTES, "UTF-8")."</option>";
                                    
                                 } else {
                                      echo  "$descricao</option>";    
                                 }
                                 ///           
                            }
                          
                          
                           $_SESSION["siglaounome"]="";
                          ///
                      ?>
                  </select>
              </span>
              <?php
                  if( isset($result) )  mysql_free_result($result); 
              }
              // FINAL - Categoria
          ?>  
        
        <!--  DESATIVANDO PA
        <td class="td_inicio1" style="vertical-align: middle; text-align: left;"  colspan="<?php echo $lc_cols/2;?>">
          <?php
              //  PA => Privilegio de acesso
              $elemento=6;      // Selecionando o BD rexp
              //  include("php_include/ajax/includes/conectar.php");                    
              /// $result=mysql_query("SELECT codigo,descricao FROM rexp.pa order by codigo ");
          ?>
          <span class="td_informacao2"  >
              <label for="pa"  style="vertical-align: middle; cursor: pointer;" title="Categoria"    >PA:</label>
              <select name="pa" class="td_select"   id="pa"  title="Selecionar PA (privilegio de acesso)"   >            
                  <?php
                      //  PA
                      $m_linhas = mysql_num_rows($result);
                      if( $m_linhas<1 ) {
                          echo "<option value='' >Nenhum PA definido.</option>";
                      } else {
                      ?>
                      <option value='' >Selecione... </option>
                      <?php
                          // Usando arquivo com while e htmlentities
                          include("{$_SESSION["incluir_arq"]}includes/tag_select_tabelas.php");
                      ?>
                  </select>
              </span>
              <?php
                  if( isset($result) ) mysql_free_result($result); 
              }
              /// FINAL - PA
          ?>  
        </td>
        -->
       </article>
       
       <article class="projetoarticle1"   >
          <table style="border: none; text-align: left;margin: 0px; padding: 0px;"  >
           <tr style="margin: 0;padding:0;">
           <td  class="td_inicio1" style="vertical-align: middle; text-align: left;padding-right: 7px;" >
             <?php
                 ///  INSTITUICAO
                 $elemento=3;
                include("php_include/ajax/includes/conectar.php");                    
                //  $result=mysql_db_query($db_array[$elemento],"SELECT sigla,nome FROM instituicao order by nome ");
                $result=mysql_query("SELECT sigla,nome FROM $bd_1.instituicao order by nome ");
                if( ! $result ) {
                    die('ERRO: Select - falha: '.mysql_error());
                    exit();
                }
             ?>
            <label for="instituicao" >Institui&ccedil;&atilde;o:</label><br />
                 <select name="instituicao" class="td_select" id="instituicao"  
          onchange="enviar_dados_cad('CONJUNTO',this.value,this.name+'|'+'<?php echo $vars_ambiente;?>');"  style="padding: 1px;" title="Institui&ccedil;&atilde;o" required="required"  >            
               <?php
                    ///  INSTITUICAO
                 $m_linhas = mysql_num_rows($result);
                 if( intval($m_linhas)<1 ) {
                        echo "<option value='' >Nenhuma Institui&ccedil;&atilde;o encontrada.</option>";
                 } else {
                   ?>
                    <option value='' >Selecione...</option>
                    <?php
                     ///  Usando arquivo com while e htmlentities
                      include("{$_SESSION["incluir_arq"]}includes/tag_select_tabelas.php");
                     ?>
                     <option value='Outra' >Outra</option>
                  </select>
                    <?php
                    if( isset($result) )  mysql_free_result($result); 
                  }
                   /// Final da Unidade
                  ?>
              </td>                  
                  <?php
                    $td_campos_array = explode("|",$_SESSION["VARS_AMBIENTE"]);
                    /*   Dica sobre o count ou sizeof 
                        Evite de usar for($i=0; $i < count($_linhas); $i++. Use: 
                           $total = count($_linhas); 
                          for($i=0; $i < $total; $i++) 
                          Pois o for sempre ir? executar a fun??o count, 
                           pesando na velocidade do seu programa. 
                    */ 
                    /// Nao comeca no Zero porque ja tem o primeiro campo acima - UNIDADE
                    $total_array = count($td_campos_array);
                    for( $x=1; $x<$total_array; $x++ ) {
                           $id_td = "td_".$td_campos_array[$x];
                           echo  "<td  nowrap='nowrap'  class='td_inicio1' style='position: relative; float: left; vertical-align: middle; text-align: left;padding-right: 7px;display:none; ' "
                                ."   name=\"$id_td\"    id=\"$id_td\"  >";
                           echo '</td>';
                     }
                  ?> 
                <td  class="td_inicio1" style="border: none; vertical-align: middle; text-align: left;"  colspan="<?php echo $lc_cols;?>" >
               <!-- font indicando bens encontrados -->
               <div id="tab_de_bens"  style="display: none; margin: 0;padding: 0;" ></div>              
              <!-- Final - font indicando bens encontrados -->           
            </td>
          </tr>    
        </table>             
       </article>
       
       <article class="projetoarticle1"   >
          <!--  EMAIL -->
           <label for="e_mail" >E_mail:&nbsp;</label><br />
           <input type="email" name="e_mail"   id="e_mail"  required="required"  size="58" 
             maxlength="64" title='Digitar E_MAIL'  onkeyup="this.value=trim(this.value)" 
              onblur="javascript: checkEmail(this.id,this.value);" autocomplete="off" />
           <!-- Final - EMAIL -->
       </article>
       
       <section id="ladoalado-container" >
           <div id="ladoalado">
               <article id="loop-ladoalado">
           <!-- Telefone - digitar -->
      <label for="Telefone"  >Telefone (dd)-fone:&nbsp;</label><br />
      <input type="text" name="fone"  id="fone" maxlength="14" onKeyDown="Mascara(this,Telefone);" 
       onKeyPress="Mascara(this,Telefone);" onKeyUp="Mascara(this,Telefone);" 
         placeholder="(xx) xxxx-xxxx"  pattern="\([0-9]{2}\)[\s][0-9]{4}-[0-9]{4,5}"  style="padding:1px;" 
           onblur="javascript: exoc('label_msg_erro',0,'');"  title="Digitar telefone somente n&uacute;mero incluindo dd " >
       <!-- Final - Telefone -->
               </article>
               <article id="loop-ladoalado">
           <!-- RAMAL - digitar -->
      <label for="ramal" style="vertical-align:bottom; padding-bottom: 1px;cursor: pointer;"  title="Ramal" >Ramal:&nbsp;</label><br />
      <input type="number" name="ramal" min="1"   id="ramal"   size="12"  maxlength="10" onKeyUp="this.value=trim(this.value);"   onblur="javascript: alinhar_texto(this.id,this.value)" autocomplete="off"  style="cursor: pointer;"  />
               <!-- Final - Ramal -->                           
               </article>
           </div>
       </section>

       <article class="projetoarticle1"  >
           <div class="labelselect" > 
           <?php 
               ///  <!--  Chefe/Orientador   --> 
               $elemento=5; $elemento2=6;
               include("php_include/ajax/includes/conectar.php");                                    
        ///       $sqlcmd="SELECT distinct codigousp,nome FROM  $bd_1.pessoa  where categoria like 'DOC%' order by nome "; 
               $sqlcmd="SELECT distinct chefecodusp,nome FROM  $bd_1.chefe  order by nome "; 
               $result = mysql_query($sqlcmd);
               /// Verifica se houve erro
                if( ! $result ) {
                           die('ERRO: Select tabela pessoa - falha: '.mysql_error());  
                } else  {
                      /*   Chefe/Orientador da pessoa para cadastrar   */
                  ?>
                  <label for="chefe"  >Chefe:&nbsp;</label>
                  <select name="chefe" class="td_select" id="chefe"  title="Selecionar Chefe/Orientador" 
                    onchange="javascript: enviar_dados_cad(this.name,this.value);"  >
                         <?php
                            ///  Chefe/Orientador
                             $m_linhas = mysql_num_rows($result);
                             if( intval($m_linhas)<1 ) {
                                  echo "<option value='' >Lista vazia. Contactar Administrador.</option>";
                             } else {
                                ?>
                                   <option value='' >Selecione...</option>   
                               <?php
                               /// Usando arquivo com while e htmlentities
                                $_SESSION["siglaounome"]="CATEGORIA";
                                include("{$_SESSION["incluir_arq"]}includes/tag_select_tabelas.php");
                                $_SESSION["siglaounome"]="";
                                  ///
                                  echo  "<option value='outro_chefe' >Outro</option>";
                             }
                              ?>
                              <!-- Final do Chefe/Orientador -->
                              </select>
                           <?php
                      }   
                        if( isset($result) )  mysql_free_result($result); 
                     
                       //// FINAL - Chefe/Orientador
                     ?>
                     <!-- Caso optou por Outro - Cadastrar novo Chefe/Orientador na Tabela pessoal.pessoa -->
                     <div id="outro_chefe" style="display:none;margin:0;">
                        <!--  Novo Chefe/Orientador -->
                        <br />
                         <label for="novo_chefe" >Novo Chefe:&nbsp;</label><br />
                        <input type="text" name="novo_chefe"   id="novo_chefe"  size="75" 
                         maxlength="64"  title='Digitar novo chefe'   onkeypress="javascript: trimnovo(this);" 
                          onkeyup="enviar_dados_cad('novo_chefe',this.value);"  disabled="disabled"  autocomplete="off" />
                         <!-- AQUI SER? APRESENTADO O RESULTADO DA BUSCA DIN?MICA.. OU SEJA OS NOMES -->
                           <div id="pagina"></div>
                        <!-- Final - novo Chefe/Orientador -->
                     </div>
               </div>                       
            </article>             

            <article class="projetoarticle4"  >
                   <!--  TAGS  type reset e  submit  -->                                              
                    <!-- Limpar campos -->                  
                    <button  type="button" name="limpar" id="limpar"  class="botao3d" 
                  onclick="javascript: enviar_dados_cad('reset','<?php echo $pagina_local;?>'); return false;"  
                      title="Limpar"  acesskey="L"  alt="Limpar"     >    
      Limpar <img src="../imagens/limpar.gif" alt="Limpar" style="vertical-align:text-bottom;" >
                    </button>
                    <!-- Final - Limpar  -->
                    <!-- Enviar -->                  
                    <button  type="submit"  name="enviar" id="enviar"   class="botao3d"  style="cursor: pointer; "  title="Enviar"  acesskey="E" alt="Enviar"  >Enviar&nbsp;<img src="../imagens/enviar.gif" alt="Enviar"  style="vertical-align:text-bottom;"  >
                    </button>
                    <!-- Final -Enviar -->
                    <!--  FINAL - TAGS  type reset e  submit  -->
           </article>                  
   </section>
</form>
<?php
} else {
   echo  "<p  class='titulo_usp' >Usu&aacute;rio n&atilde;o autorizado</p>";
}
?>
</div>
<!-- Final  div_form -->
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape"  >
<?php include_once("../includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
