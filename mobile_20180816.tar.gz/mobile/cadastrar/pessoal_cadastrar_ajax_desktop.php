<?php
//   Arquivo para CADASTRAR 
//
//  Funcao para busca com acentos
function stringParaBusca($str) {
    //// Transformando tudo em minúsculas
    $str = trim(strtolower($str));

    ///  Tirando espaços extras da string... "tarcila  almeida" ou "tarcila   almeida" viram "tarcila almeida"
    while ( strpos($str,"  ") )
        $str = str_replace("  "," ",$str);
    
    /// Agora, vamos trocar os caracteres perigosos "ã,á..." por coisas limpas "a"
    $caracteresPerigosos = array ("Ã","ã","Õ","õ","á","Á","é","É","í","Í","ó","Ó","ú","Ú","ç","Ç","à","À","è","È","ì","Ì","ò","Ò","ù","Ù","ä","Ä","ë","Ë","ï","Ï","ö","Ö","ü","Ü","Â","Ê","Î","Ô","Û","â","ê","î","ô","û","!","?",",","“","”","-","\"","\\","/");
    $caracteresLimpos    = array ("a","a","o","o","a","a","e","e","i","i","o","o","u","u","c","c","a","a","e","e","i","i","o","o","u","u","a","a","e","e","i","i","o","o","u","u","A","E","I","O","U","a","e","i","o","u",".",".",".",".",".",".","." ,"." ,".");
    $str = str_replace($caracteresPerigosos,$caracteresLimpos,$str);
    
    /* Agora que não temos mais nenhum acento em nossa string, e estamos com ela toda em "lower",
          vamos montar a expressão regular para o MySQL                                             */
    $caractresSimples = array("a","e","i","o","u","c");
    $caractresEnvelopados = array("[a]","[e]","[i]","[o]","[u]","[c]");
    $str = str_replace($caractresSimples,$caractresEnvelopados,$str);
    $caracteresParaRegExp = array(
        "(a|ã|á|à|ä|â|&atilde;|&aacute;|&agrave;|&auml;|&acirc;|Ã|Á|À|Ä|Â|&Atilde;|&Aacute;|&Agrave;|&Auml;|&Acirc;)",
        "(e|é|è|ë|ê|&eacute;|&egrave;|&euml;|&ecirc;|É|È|Ë|Ê|&Eacute;|&Egrave;|&Euml;|&Ecirc;)",
        "(i|í|ì|ï|î|&iacute;|&igrave;|&iuml;|&icirc;|Í|Ì|Ï|Î|&Iacute;|&Igrave;|&Iuml;|&Icirc;)",
        "(o|õ|ó|ò|ö|ô|&otilde;|&oacute;|&ograve;|&ouml;|&ocirc;|Õ|Ó|Ò|Ö|Ô|&Otilde;|&Oacute;|&Ograve;|&Ouml;|&Ocirc;)",
        "(u|ú|ù|ü|û|&uacute;|&ugrave;|&uuml;|&ucirc;|Ú|Ù|Ü|Û|&Uacute;|&Ugrave;|&Uuml;|&Ucirc;)",
        "(c|ç|Ç|&ccedil;|&Ccedil;)" );
    $str = str_replace($caractresEnvelopados,$caracteresParaRegExp,$str);
    
    //Trocando espaços por .*
    $str = str_replace(" ",".*",$str);
    
    //Retornando a String finalizada!
    return $str;
}
///
///  Funcao para minuscula para Maiuscula
function stringParaBusca2($str) {
 /*
     $a1 ="àáâãäåæçèéêëìíîïñòóôõöøùúûüý";
     $a1_len = strlen($a1);
     $a2 ="ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÑÒÓÔÕÖØÙÚÛÜÝ";
     //  $pessoa_nome2=trim($pessoa_nome);
    for( $i=0; $i<$a1_len; $i++ ) {
          $char1[]=substr($a1,$i,1);
            $char2[]=substr($a2,$i,1);
    }
    $m_count = count($char1);
    $texto=$str;
    for( $x=0; $x<$m_count ; $x++ ) {
        //   $str = str_replace($char1[$x],$char2[$x],$str);
         // First check if there is a "5" at position 0.
        $offset = 0; // initial offset is 0
        $fiveCounter = 0;
        if( strpos($str, $char1[$x])==0 ) continue;

       // Check the rest of the string for 5's
       while( $offset=strpos($str, $char1[$x],$offset+1) ) {
           $texto=substr_replace($texto,$char2[$x],$offset,1); 
           $chars .=  $char1[$x]." - ";        
       }
     //     $str = str_replace($char1,$char2,$str);
        //  $texto .= "<br>  - $str ".$char1." - ".$char2;
    
    
    }
  */
    //  Usar para substituir caracteres com acentos para Maiuscula
   $substituir = array(
                        '/&aacute;/i' => 'Á',
                        '/&Eacute;/i' => 'É',
                        '/&Iacute;/i' => 'Í',
                        '/&Oacute;/i' => 'Ó',
                        '/&Uacute;/i' => 'Ú',
                        '/&Atilde;/i' => 'Ã',
                        '/&Otilde;/i' => 'Õ',
                        '/&Acirc;/i' => 'Â',
                        '/&Ecirc;/i' => 'Ê',
                        '/&Icirc;/i' => 'Î',
                        '/&Ocirc;/i' => 'Ô',
                        '/&Ucirc;/i' => 'Û',
                        '/&Ccedil;/i' => 'Ç',
                        '/&Agrave;/i' => 'À'
                        );
    
    
    
    //  $texto =strtoupper($str);
   $substituir0 = array(
                        '/á/' => '&aacute;',
                        '/é/' => '&eacute;',
                        '/í/' => '&iacute;',
                        '/ó/' => '&oacute;',
                        '/ú/' => '&uacute;',
                        '/ã/' => '&atilde;',
                        '/õ/' => '&otilde;',
                        '/â/' => '&acirc;',
                        '/ê/' => '&ecirc;',
                        '/î/' => '&icirc;',
                        '/ô/' => '&ocirc;',
                        '/û/' => '&ucirc;',
                        '/ç/' => '&ccedil;',
                        '/Á/' => '&Aacute;',
                        '/É/' => '&Eacute;',
                        '/Í/' => '&Iacute;',
                        '/Ó/' => '&Oacute;',
                        '/Ú/' => '&Uacute;',
                        '/Ã/' => '&Atilde;',
                        '/Õ/' => '&Otilde;',
                        '/Â/' => '&Acirc;',
                        '/Ê/' => '&Ecirc;',
                        '/Î/' => '&Icirc;',
                        '/Ô/' => '&Ocirc;',
                        '/Û/' => '&Ucirc;',
                        '/Ç/' => '&Ccedil;',
                        '/à/' => '&agrave;',
                        '/À/' => '&Agrave;'
                        );

/*
    $substituir2 = array('/á/' => 'Á',
                        '/é/' => 'É',
                        '/í/' => 'Í',
                        '/ó/' => 'Ó',
                        '/ú/' => 'Ú',
                        '/ã/' => 'Ã',
                        '/õ/' => 'Õ',
                        '/â/' => 'Â',
                        '/ê/' => 'Ê',
                        '/î/' => 'Î',
                        '/ô/' => 'Ô',
                        '/û/' => 'Û',
                        '/ç/' => 'Ç',
                        '/ñ/' => 'Ñ',
                        '/ò/' => 'Ò',
                        '/ò/' => 'Ò',                        
                        '/ö/' => 'Ö',                        
                        '/ø/' => 'Ø',                                                
                        '/ù/' => 'Ù',                                                                        
                        '/ü/' => 'Ü',                                                                                                
                        '/ý/' => 'Ý'
                    );
                    */
                    
        $substituir2 = array('á' => 'Á',
                        'é' => 'É',
                        'í' => 'Í',
                        'ó' => 'Ó',
                        'ú' => 'Ú',
                        'ã' => 'Ã',
                        'õ' => 'Õ',
                        'â' => 'Â',
                        'ê' => 'Ê',
                        'î' => 'Î',
                        'ô' => 'Ô',
                        'û' => 'Û',
                        'ç' => 'Ç',
                        'ñ' => 'Ñ',
                        'ò' => 'Ò',
                        'ò' => 'Ò',                        
                        'ö' => 'Ö',                        
                        'ø' => 'Ø',                                                
                        'ù' => 'Ù',                                                                        
                        'ü' => 'Ü',                                                                                          
                        'ý' => 'Ý'
                    );
                    
                        
  // $texto = preg_replace(array_keys($substituir2),array_values($substituir2),$str);
   $texto =  preg_replace(array_keys($substituir),array_values($substituir),$str);

    return $texto;
    
}

ob_start(); /* Evitando warning */
//  Verificando se SESSION_START - ativado ou desativado
if(!isset($_SESSION)) {
   session_start();
}
// set IE read from page only not read from cache
//  header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control","no-store, no-cache, must-revalidate");
header("Cache-Control","post-check=0, pre-check=0");
header("Pragma", "no-cache");

//  header("content-type: application/x-javascript; charset=tis-620");
/// header("content-type: application/x-javascript; charset=iso-8859-1");
///  header("Content-Type: text/html; charset=ISO-8859-1",true);
header("Content-type: text/html; charset=utf-8");

//   Colocar as datas do Cadastro do Usuario e a validade
date_default_timezone_set('America/Sao_Paulo');


///  Melhor setlocale para acentuacao - strtoupper, strtolower, etc...
///  setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8");

//
//   Para acertar a acentuacao
//  $_POST = array_map(utf8_decode, $_POST);
// extract: Importa variáveis para a tabela de símbolos a partir de um array 
extract($_POST, EXTR_OVERWRITE);  

$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";

//  Conjunto de arrays 
include_once("{$_SESSION["incluir_arq"]}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) $array_pa = $_SESSION["array_pa"];    
// Conjunto de Functions
// require_once("../script/stringparabusca.php");	
require_once("{$_SESSION["incluir_arq"]}includes/functions.php");    

$post_array = array("source","val","m_array");
for( $i=0; $i<count($post_array); $i++ ) {
    $xyz = $post_array[$i];
    //  Verificar strings com simbolos: # ou ,   para transformar em array PHP    
    $xyz=="m_array" ? $div_array_por = "#" : $div_array_por = ",";
    if ( isset($_POST[$xyz]) ) {
	    $pos1 = stripos(trim($_POST[$xyz]),$div_array_por);
	   if ( $pos1 === false ) {
	       //  $$xyz=trim($_POST[$xyz]);
		   //   Para acertar a acentuacao - utf8_encode
           $$xyz = utf8_decode(trim($_POST[$xyz])); 
	   } else  $$xyz = explode($div_array_por,$_POST[$xyz]);
	}
}
//
//   Para acertar a acentuacao - utf8_encode
///   $source = utf8_decode($source); $val = utf8_decode($val); 
if( ! isset($val) ) $val="";
if( strtoupper($val)=="SAIR" ) $source=$val;

if( ! isset($source) ) $source="";
$_SESSION["source"]=trim($source);
$source_upper=strtoupper($_SESSION["source"]);
if( isset($val) ) $val_upper=strtoupper(trim($val));
////   Sair 
if( $source_upper=="SAIR" ) {
    // Eliminar todas as variaveis de sessions
    $_SESSION=array();
    session_destroy();
    if( isset($total) ) unset($total);
    if( isset($login_senha) ) unset($login_senha); 
    if( isset($login_down) ) unset($login_down); 
    if( isset($senha_down) )  unset($senha_down); 
	//
	//  echo  "<a href='http://www-gen.fmrp.usp.br'  title='Sair' >Sair</a>";
    response.setHeader("Pragma", "no-cache"); 
    response.setHeader("Cache-Control", "no-cache"); 
    response.setDateHeader("Expires",0); 
	//  echo  "http://www-gen.fmrp.usp.br/";
	exit();
}
//
if( strtoupper(trim($source))=="CONJUNTO" )  {
     /// PARTE PARA MUDANCA DE CAMPO - IMPORTANTE
	 $n_cpo = (int) $n_cpo; $cpo_final = (int) $cpo_final;
     unset($m_linhas); $m_vars_ambiente = $_SESSION['VARS_AMBIENTE'];     
     if( isset($m_array) ) {
          if( ! is_array($m_array) ) $m_array  = explode(",",$m_array);         
     } else {
         $m_array="";
     }
     ///
     if( ! isset($_SESSION["key"]) ) $_SESSION["key"]=0;    
      ///  Inicio do IF principal
	 if(  intval($n_cpo)<= intval($cpo_final) ) {  
         $cpo_where = "";
         if( is_array($m_array) ) {
              $cpo_where = trim($m_array[0]);
              $cpo_where_upper=strtoupper($cpo_where);
         }
		 //  $pos_encontrada = array_search($cpo_where,$m_array);
		 //  Definindo a posicao para o proximo campo 
         $_SESSION["key"]= (int) $_SESSION["key"]+1;                  
		 $total_array=sizeof($m_array);
		 ///  if( strtoupper($cpo_where)=="INSTITUICAO" ) {
         if( $cpo_where_upper=="INSTITUICAO" ) {
              $i=2;  unset($_SESSION['campos_dados1']);
              unset($_SESSION['campos_dados2']);
              $_SESSION["key"]=0;              
		 } else {
              $i=0;
              for( $j=1; $j<$total_array; $j++ ) {
                  if( $cpo_where==$m_array[$j] ) {
                      $i=$j+1;             
                      break;
                  }
            
              }
			 //  Verifica se esse campo ja foi selecionado no array
			 //  remover o anterior
             if( $_SESSION['campos_dados1'] ) {
                  $total = sizeof($_SESSION['campos_dados1']); 
			      for( $ver=0; $ver<$total ; $ver++ ) {
                      if( $cpo_where==$_SESSION['campos_dados1'][$ver] or $j<$total  ) {
                           $_SESSION["key"]=$ver;  // Importante depois de achar duplicata
					       for( $ver; $ver<$total ; $ver++ ) {
                                unset($_SESSION['campos_dados1'][$ver]);
                                unset($_SESSION['campos_dados2'][$ver]);        
						   }							   
					  }  
				  }
			 }
		 }
		 ///
         $table_atual = $m_array[$i]; $upper_val=strtoupper($val); 
         $_SESSION["select_cpo"]="sigla";
		 $array2 = array("bloco","salatipo","sala");
		 ///  Precisava passar a variavel 
		 if( $cpo_where_upper=="SALA" ) $table_atual="sala";	
         $chave = $_SESSION["key"];
         $_SESSION['campos_dados1'][$chave]=$cpo_where;
         $_SESSION['campos_dados2'][$chave]=$val;
		 //  
        //  Precisava passar a variavel 
        //  Mudando a variavel - $table_atual       
       if( $cpo_where_upper=="INSTITUICAO" && strtoupper(trim($table_atual))=="SALATIPO"  ) {
            ////   if(  strtoupper(trim($table_atual))=="SALATIPO"  ) {
            $msg_erro .= "-> cadastrar_auto_ajax.php/305  - FALHA GRAVE ";
            echo  $msg_erro;   
            exit();
       }
       $select_cpo=$_SESSION["select_cpo"];
       if( strtoupper($table_atual)=="BLOCO" || strtoupper($table_atual)=="SALATIPO" || strtoupper($table_atual)=="SALA" ) { 
               $_SESSION["select_cpo"]=$table_atual; 
               $select_cpo=$_SESSION["select_cpo"];
               $table_atual="bem"; 
               $apagaressavar="";
       }                         
       $_SESSION["where"]="";            
       $total_arrays = sizeof($_SESSION['campos_dados1']);        
		for( $row = 0; $row < $total_arrays; $row++) {
             $_SESSION["where"].= " upper(trim(".$_SESSION['campos_dados1'][$row]."))=";
             $p2 = $_SESSION['campos_dados2'][$row];
             $_SESSION["where"].=  " \"$p2\" ";
             if( $row<($total_arrays-1) ) $_SESSION["where"].=  " and ";
		}
        $where=$_SESSION["where"];        
	    /// Selecionando campo 	
       //  elemento define o bd_1  e o elemento2  o  bd_2
       $elemento=3;
       include("php_include/ajax/includes/conectar.php");	
	   $tabs_sig_nome= array("instituicao","unidade","depto","setor");			    
	   $nome_cpo="";
	   if( in_array($table_atual,$tabs_sig_nome) ) $nome_cpo="nome,";
      ///  mysql_db_query - Esta funcao e obsoleta, nao use esta funcao - Use mysql_select_db() ou mysql_query()
     /*
       $result=mysql_query("SELECT ".$_SESSION["select_cpo"].", $nome_cpo count(*) FROM "
                         ." $table_atual where ".$_SESSION["where"]."  group by 1 order by  ".$_SESSION["select_cpo"]);
                          
       */
       //  $sqlcmd="SELECT $select_cpo, $nome_cpo count(*) FROM  $table_atual where $where   group by 1  order by $select_cpo ";
       $sqlcmd="SELECT $select_cpo, $nome_cpo count(*) FROM  $bd_1.$table_atual WHERE $where  GROUP BY 1 ORDER BY $select_cpo ";
       $result=mysql_query($sqlcmd);
       ///
        if( strtoupper($table_atual)=="BEM" ) $table_atual=$_SESSION["select_cpo"]; 
        if( ! $result ) die('ERRO: Select - falha: '.mysql_error());
        $m_linhas = mysql_num_rows($result);
		///
		$_SESSION["table_atual"]=$table_atual;
		$cp_table_atual=$table_atual; $cp_cpo_where=$cpo_where;
		if( strtoupper($cp_table_atual)=="INSTITUICAO" ) $cp_table_atual="instituição";
		if( strtoupper($cp_cpo_where)=="INSTITUICAO" ) $cp_cpo_where="instituição";
		if( strtoupper($cp_table_atual)=="DEPTO" ) $cp_table_atual="departamento";
		if( strtoupper($cp_cpo_where)=="DEPTO" ) $cp_cpo_where="departamento";  
        /// 
		if( $m_linhas<1 )  {
		       /* echo "==== Nenhum(a) <b>".ucfirst($table_atual)."</b> desse(a) <b>"
									 .ucfirst($cpo_where)."</b> ====";	*/
		       echo "==== Nenhum(a) <b>".ucfirst($cp_table_atual)."</b> desse(a) <b>"
									 .ucfirst($cp_cpo_where)."</b> ====";	
		       exit();
	    }  //  Final do IF - m_linhas<1						   
		//  Executar IF quando nao for o ultimo campo
		if( $i<$cpo_final ) {
		     ?>
            <span class="td_informacao2"  >
             <label for="<?php echo $table_atual;?>" >&nbsp;<?php echo ucfirst($table_atual);?>:</label><br />
           <!--  Tag Select com title para ser verificada                   
             <select  class="td_select"  name="<?php echo $table_atual;?>"  id="<?php echo $table_atual;?>" 
                onchange="enviar_dados_cad('CONJUNTO',this.value,this.name+'|'+'<?php echo $m_vars_ambiente;?>');" style="padding: 1px;" title="<?php echo ucfirst($cp_table_atual);?>"  >            
            -->
             <select  class="td_select"  name="<?php echo $table_atual;?>"  id="<?php echo $table_atual;?>" 
                onchange="enviar_dados_cad('CONJUNTO',this.value,this.name+'|'+'<?php echo $m_vars_ambiente;?>');" style="padding: 1px;" >            
             <?php
          	     //  acrescentando opcoes
	             echo "<option value='' >&nbsp;Selecionar&nbsp;</option>";
                 while( $linha=mysql_fetch_array($result) ) {   //  WHILE  DA TAG SELECT    
    				      //  Desativando selected - opcao que fica selecionada
                          if( isset($linha["sigla"]) ) {
                                 $value = urlencode($linha["sigla"]);
                                 $nome = trim(htmlentities($linha["sigla"]));
                          } elseif( in_array($table_atual,array("bloco","salatipo","sala")) ) {
                                 $select_cpo=$_SESSION["select_cpo"];
                                 //  $value = urlencode($linha[$select_cpo]);
                                 $value = trim(htmlentities($linha[$select_cpo]));
                                 ///  $nome = trim(htmlentities($linha[$select_cpo]));                          
                                 $nome = trim($linha[$select_cpo]);                          
                          }
                          $inst_selected = "";    $traco="";
                          $se_sigla=""; $se_nome="";
						  if( strlen($nome_cpo)>1 ) {
                              //  htmlentities - o melhor para transferir na Tag Select
                              if( isset($linha["sigla"]) ) $se_sigla= htmlentities($linha["sigla"]);  
                                if( isset($linha["nome"]) ) $se_nome= htmlentities($linha["nome"]); 
                              $traco="-";                  
                          }      
                          $title_sigla=$se_sigla."&nbsp;".$traco."&nbsp;".$se_nome;
                          echo  "<option $inst_selected   value=".$value."  title=".$title_sigla." >";
                          echo  htmlentities($nome,ENT_QUOTES,"UTF-8")."&nbsp;</option>" ;
                          ///  echo  $nome."&nbsp;</option>" ;
   	              }  // FIM DO WHILE
	       	  ?>
	          </select>
	          </span>
			  <?php
                 if( isset($result) ) mysql_free_result($result); 
    	         // Final do SELECT
                 if( strtoupper(trim($_SESSION["select_cpo"]))=="SALA" ) {
                       $cpo_final=0; $n_cpo=0; unset($m_array); unset($m_linhas); unset($source);
                       unset($_SESSION["where"]);  unset($_SESSION["select_cpo"]);
                 }
          } else {
             //  Executando o Mysql Select do ultimo campo
             unset($m_linhas); 
          } //  FINAL DO - IF i < cpo_final
     }  
     ///  Final do IF principal
}

//  Serve tanto para o arquivo projeto  quanto para o experimento
///
//   Campo para Novo Chefe 
if( $source_upper=="NOVO_CHEFE" ) {
      ////  elemento define o bd_1  
      $m_linhas=0; $bd_1="";
      if( strlen(trim($val))>0 ) {
               $elemento=5;
               include("php_include/ajax/includes/conectar.php");        
               /*
                     $sqlcmd="SELECT distinct codigousp,nome FROM  $bd_1.pessoa  where categoria like 'DOC%'  COLLATE latin1_swedish_ci  order by nome "; 
               */      
               ////  Selecionando o banco de dados
               $resultadobd=mysql_select_db("$bd_1");
               if( ! $resultadobd  ) {
                    //// or die(mysql_error());
                    $msg_erro .="&nbsp;Select db falha: db/mysql ".mysql_error().$msg_final;  
                    echo $msg_erro;  
                    exit();
               } 
               /////            
               ///  Selecionando chefes
              $sqlcmd="SELECT distinct nome FROM  $bd_1.chefe 
                            WHERE   upper(clean_spaces(nome)) like '$val%' order by nome  "; 
              ///
              $result = mysql_query($sqlcmd);
              /// Verifica se houve erro
              if( ! $result ) {
                   ///      die('ERRO: Select tabela pessoa - falha: '.mysql_error());  
                   $msg_erro .="&nbsp;Select tabela chefe: db/mysql ".mysql_error().$msg_final;  
                   echo $msg_erro;  
                   exit();
              }
              ///  Numero de Chefe/Orientador
              $m_linhas = mysql_num_rows($result);
              if( intval($m_linhas)>0 ) {
                  $cpo_nome_descr=mysql_field_name($result,0);        
                  ?>
                  <select id="tmpnovochefe"  onchange="javascript: document.getElementById('<?php echo $source;?>').value=this.value;"  >
                  <option value='' >Selecione...</option>   
                     <?php
                          ///  Chefe/Orientador
                          /// Usando arquivo com while e htmlentities
                          $_SESSION["siglaounome"]="CATEGORIA";
                          include("{$_SESSION["incluir_arq"]}includes/tag_select_tabelas.php");
                          $_SESSION["siglaounome"]="";
                          ////
                       ?>
                     <!--  Final do Select chefe  -->
                     </select>
                  <?php
              }
              ////
       }
       ////  echo "pessoal_cad_ajax.php/439 ->>  $m_linhas --==    \$bd_1 = $bd_1  --   \$val = $val ";
      exit();
}    
///   
///  Tabela pessoa - BD PESSOAL
if( $val_upper=="PESSOAL" ) {
     ////  Verificando campos -- CONECTANDO
     $elemento=5;  $m_regs=0;
     include("php_include/ajax/includes/conectar.php");
    /*	 
         Melhor jeito de acertar a acentuacao - htmlentities(utf8_decode
		 OU para MYSQL  tem que ser html_entity_decode
    */	
 	 $campo_nome = htmlentities(utf8_decode($campo_nome));
	 $campo_value = htmlentities(utf8_decode($campo_value));
	 $campo_nome = substr($campo_nome,0,strpos($campo_nome,",enviar"));
	 $array_temp = explode(",",$campo_nome);
 	 $array_t_value = explode(",",$campo_value);
	 $count_array_temp = sizeof($array_temp);
     $i_codigousp=-1;
     /*   ALTERADO EM 20170217
     for( $i=0; $i<$count_array_temp; $i++ ) {
         $arr_nome_val[$array_temp[$i]]=$array_t_value[$i];
         // Salvando a posição do campo codigousp para criar codigo <0 para usuario de fora da USP
         if( strtoupper(trim($array_temp[$i]))=="CODIGOUSP" ) $i_codigousp=$i;
     }
     */
     ////  Caso novo_chefe solicitado
     $novo_chefeHTML="";
     for( $i=0; $i<$count_array_temp; $i++ ) {
         ////  Caso encontrado
         if( strtoupper(trim($array_temp[$i]))=="NOVO_CHEFE" ) {
                ///  Alterado em 20170301
               ////  $novo_chefe=stringParaBusca2($array_t_value[$i]);
               $novo_chefe=trim($array_t_value[$i]);
               $novo_chefeHTML=trim($array_t_value[$i]);
               //  $descricao =utf8_decode($novo_chefe);
               break;  
         }
     }
     /// Final - for para variavel novo_chefe
     /*     Detectar codificação de caracteres            */
     if( isset($novo_chefe) ) {
         $codigo_caracter=mb_detect_encoding($novo_chefe);
         if( trim(strtoupper($codigo_caracter))!="UTF8" ) {
                 /////  Converter  para  UFT-8
                $novo_chefe=html_entity_decode($novo_chefe, ENT_QUOTES, "UTF-8");
         }         
     }
     /////           
     ////  SESSION abaixo para ser usada no include
     $bd_1="pessoal";         
     $_SESSION["tabela"]="pessoa"; $_SESSION["bd"]=$bd_1;         
     ///  INCLUDE 
     include("dados_pessoal_cadastro_ajax.php");  
      /// 
     /// Verificando o numero de elementos no array $arr_nome_val
     if( isset($arr_nome_val) ) {
              $count_array_temp=sizeof($arr_nome_val);
              ///  Definindo os nomes dos campos recebidos do FORM
              $nelem=0;
              foreach(  $arr_nome_val as $elemento => $valor ) {
                    $$elemento =  $valor;
                    if( strtoupper($elemento)=="CODIGOUSP" ) {
                         $i_codigousp=$nelem;    
                         $codigousp=$valor;    
                    }
                    ++$nelem;
              } 
             ///
     } else {
            $msg_erro .="&nbsp;Array arr_nome_val n&atilde;o foi definido.".$msg_final;
            echo $msg_erro;         
            exit();              
     }    
     //// CASO  NAO tenha codigo USP sera criado 
     if( intval($arr_nome_val["codigousp"])==0 ) {          
          /* 
              Caso for novo codigousp
         */
         ///  Selecionar todos os usuarios menor que  ZERO/0 
         $result=mysql_query("SELECT min(codigousp) as codigo_ult  FROM  $bd_1.pessoa where codigousp<0 ") ;
         if( ! $result ) {
             die("Falha erro no Select/Atribuir codigoUSP".mysql_error());
         }
         $m_regs=mysql_num_rows($result);
         if( intval($m_regs)>0 ) {
             $codigo_prx = mysql_result($result,0,'codigo_ult');
         } 
         if( ! isset($codigo_prx) ) {
             $codigo_prx = 0;
         }
         $codigo_prx += -1;
         if( isset($result) ) mysql_free_result($result);
         $arr_nome_val["codigousp"] = $codigo_prx;
         if( $i_codigousp<0 ) {
              die("ERRO: Falha inesperada criando um NOVO codigo USP.");
         }
                  /// Alterado em 20170216
         /// $array_t_value["$i_codigousp"] = $codigo_prx;
         $arr_nome_val["codigousp"] = $codigo_prx;
         $codigousp = $codigo_prx;
         /////
         /*
             Corrigir array elemento codigousp da pessoa sendo cadastrada
         */
          $campo_nome=explode(",",$campo_nome);
          $count_array_cponome=count($campo_nome);
          $campo_value=explode(",",$campo_value);
          for( $nc=0;$nc<$count_array_cponome; $nc++ )  {
               if( strtoupper($campo_nome[$nc])=="CODIGOUSP" ) {
                     $campo_value[$nc]=$codigousp;          
               }
          }
           ///  Caso houver excesso de elementos no array  $campo_value
           ///  O mesmo volume de elementos dos dois arrays
           $campo_value = array_slice($campo_value, 0, $count_array_cponome); 
           $campo_nome=implode(",",$campo_nome);
           $campo_value=implode(",",$campo_value);
           if( array_key_exists("codigousp", $arr_nome_val) ) {
                $arr_nome_val["codigousp"]=$codigousp;  
           }
           ///
     }
    /////  FINAL - if( intval($arr_nome_val["codigousp"])==0 ) {
    ////        VERIFICANDO se essa pessoa ja tem cadastro
	$result_usu=mysql_query("SELECT codigousp,nome FROM $bd_1.pessoa where codigousp=".$arr_nome_val["codigousp"]) ;
	if( ! $result_usu ) {
		  die("Falha erro no Select".mysql_error());
	}
    $m_regs=mysql_num_rows($result_usu);
    if( isset($result_usu) ) mysql_free_result($result_usu);
    if( intval($m_regs)>=1 ) {
           $msg_erro .= "&nbsp;Esse C&oacute;digo:&nbsp;".$arr_nome_val["codigousp"]." j&aacute; est&aacute; cadastrado.".$msg_final;
           echo $msg_erro;
    } else {
           //   Vericando se o NOme se ja esta cadastrado  na Tabela pessoa
           //   Importante no PHP strtoupper, str trim  e no MYSQL  replace,upper,trim
           //    Remover os espacos do nome deixando apenas um entre as palavras
           ///  $arr_nome_val['nome'] = trim(preg_replace('/ +/',' ',$arr_nome_val['nome']));            
           ///  $pessoa_nome=html_entity_decode(strtoupper(trim($arr_nome_val['nome'])));
           ////   ACERTAR O CAMPO NOME, retirando acentuação e passando para maiusculas
           /// $pessoa_nome=stringParaBusca2(strtoupper(trim($arr_nome_val['nome'])));
           ///  
           ///  Acertando ACENTOS DO HTML PARA PHP/MYSQL - html_entity_decode
           /////  $pessoa_nome=html_entity_decode(trim($pessoa_nome)); 
           
           ////  SESSION abaixo para ser usada no INCLUDE - organiza dados com a Tabela
           $_SESSION["tabela"]="pessoa"; $_SESSION["bd"]=$bd_1;         
           include("dados_pessoal_cadastro_ajax.php");  
           ///  Caso tenha o codigousp  alterar o array $arr_nome_val
           if( array_key_exists("codigousp", $arr_nome_val) ) {
                $arr_nome_val["codigousp"]=$codigousp;  
           }
           ////  Selecionando o banco de dados
           $resultadobd=mysql_select_db("$bd_1");
           if( ! $resultadobd  ) {
                //// or die(mysql_error());
                $msg_erro .="&nbsp;Select db falha: db/mysql ".mysql_error().$msg_final;  
                echo $msg_erro;  
                exit();
           }
           /////           
           mysql_query("SET NAMES 'utf8'");
           mysql_query('SET character_set_connection=utf8');
           mysql_query('SET character_set_client=utf8');
           mysql_query('SET character_set_results=utf8');
           ///       
           ////  Definindo os nomes dos campos recebidos do FORM
           foreach(  $arr_nome_val as $xchave => $xvalor )  $$xchave = $xvalor;
           /*
                CASO a variabel chefe  - NAO esteja ativa
          */
          $registronovochefe=0;
          if( ! isset($chefe) ) {
              ////   Incluir novo chefe na LISTA  
               /*  Caso  declarado  no FORM o campo novo_chefe  */
              if( isset($novo_chefe) ) {
                  ////
                  ////   $novo_chefe=trim($novo_chefe);
                  $temparray = explode(" ",$novo_chefe);
                  $numelems=count($temparray);
                  if( intval($numelems)<2 ) {
                        //// or die(mysql_error());
                        $msg_erro .="&nbsp;Nome do novo chefe inválido. $novo_chefe ";  
                        echo $msg_erro;  
                        exit();
                  }
                  ////  Verifica se esse Chefe existe
                  //// $sqlcmd=mysql_query("SELECT nome from $bd_1.chefe WHERE  trim(nome)=trim(\"$novo_chefe\")  ");
                  $sqlcmd=mysql_query("SELECT nome,chefecodusp from $bd_1.chefe 
                              WHERE  upper(clean_spaces(nome))=upper(clean_spaces('".$novo_chefe."')) 
                               COLLATE latin1_swedish_ci  order by nome ");

                   ///
                   if( ! $sqlcmd ) {
                        die("Falha no Select tabela chefe ".mysql_error());
                   }
                  /// Numero do ultimo chefecodusp
                   $regs=mysql_num_rows($sqlcmd);
                   if( intval($regs)>0 ) {
                        ////  Caso chefe encontrado na tabela chefe
                        $chefe=mysql_result($sqlcmd,0,"chefecodusp");
                   } else {
                         ///   Incluir novo chefe na LISTA  
                         $result=mysql_query("SELECT min(chefecodusp) as codigo_ult_chefe  
                                           FROM  $bd_1.chefe where chefecodusp<0 ") ;
                         ///                     
                         if( ! $result ) {
                              die("Falha no Select/min chefecodUSP".mysql_error());
                         }
                         ///
                        /// Numero do ultimo chefecodusp
                        $numregs=mysql_num_rows($result);
                        if( intval($numregs)>0 ) {
                            $ultcod_chefe=mysql_result($result,0,"codigo_ult_chefe");
                        } 
                        if( !isset($ultcod_chefe) ) {
                            $ultcod_chefe = -1;
                        } else {
                            $ultcod_chefe += -1;                
                        }
                        if( isset($result) ) mysql_free_result($result);
                        ///
                        $chefecodusp = $ultcod_chefe;
                        $chefe=$chefecodusp;

                        ///  Inserindo novo Chefe  
                       $n_erro=0;
                       
                 ////   BD para fazer teste                                         
               ////   $bd_1="lixo";     

                       /*
                              INSERIR O NOVO CHEFE
                       */
                       ///  START a transaction - ex. procedure    
                       mysql_query('DELIMITER &&'); 
                       mysql_query('begin'); 
                       ///  Execute the queries 
                       ///  mysql_db_query - Esta funcao esta obsoleta, nao use esta funcao 
                       ///   - Use mysql_select_db() ou mysql_query()
                       mysql_query("LOCK TABLES $bd_1.chefe WRITE ");
                       $sqlcmd="INSERT into $bd_1.chefe (chefecodusp,nome) values($chefecodusp,'$novo_chefe') ";
                       $success=mysql_query($sqlcmd); 
                       ///
                        ///  Complete the transaction 
                        if( $success ) { 
                              mysql_query('commit');                                  
                        } else {
                              /// Ocorreu erro
                              $n_erro=1;
                              mysql_query('rollback'); 
                        }              
                        mysql_query("UNLOCK  TABLES");
                        mysql_query('end'); 
                        mysql_query('DELIMITER');
                        ///
                        ///  SLEEP - tempo de espera em segundos
                        sleep(1);
                        ///
                        if( intval($n_erro)>0 ) {
                             //// $msg_erro .="&nbsp;".$arr_nome_val['nome']." n&atilde;o foi cadastrado.".$msg_final;
                             $msg_erro .="Esse chefe &nbsp;".$novo_chefeHTML." n&atilde;o foi cadastrado.".$msg_final;
                             echo $msg_erro;         
                             exit();    
                        } else {
                            /// Confirmando cadastrado o novo chefe
                             $isqlcmd=mysql_query("SELECT * FROM $bd_1.chefe WHERE  chefecodusp=$chefecodusp  "); 
                             ///
                             if( ! $isqlcmd ) {
                                die("Falha no Select tabela chefe pesquisa cadastrado ".mysql_error());
                             }
                             /// Numero do ultimo chefecodusp
                             $registronovochefe=mysql_num_rows($isqlcmd);
                             ///     
                        }
                       ///  Final do INSERT novo CHEFE
                   }
                   ///
                   /*
                         Corrigir array elemento novo_chefe para chefe
                   */
                   $campo_nome=explode(",",$campo_nome);
                   $count_array_cponome=count($campo_nome);
                   $campo_value=explode(",",$campo_value);
                   for( $nc=0;$nc<$count_array_cponome; $nc++ )  {
                       if( strtoupper($campo_nome[$nc])=="NOVO_CHEFE" ) {
                             $campo_nome[$nc]="chefe";
                             $campo_value[$nc]=$chefe;          
                       }
                   }
                   ///  Caso houver excesso de elementos no array  $campo_value
                   ///  O mesmo volume de elementos dos dois arrays
                   $campo_value = array_slice($campo_value, 0, $count_array_cponome); 
                   $campo_nome=implode(",",$campo_nome);
                   $campo_value=implode(",",$campo_value);
                   ////                  
              }
              ///  IF isset($novo_chefe))
          } 
          ////
           /* IMPORTANTE - essa parte para configurar novamente as variaveis 
                       $cpo_nome  e  $cpo_valor
           */
           ////  SESSION abaixo para ser usada no INCLUDE - organiza dados com a Tabela
           $campo_nome = htmlentities(utf8_decode($campo_nome));
           $campo_value = htmlentities(utf8_decode($campo_value));
           $array_temp = explode(",",$campo_nome);
           $array_t_value = explode(",",$campo_value);
           $count_array_temp = sizeof($array_temp);
           $_SESSION["tabela"]="pessoa"; $_SESSION["bd"]=$bd_1;         
           include("dados_pessoal_cadastro_ajax.php");  
           
           ////  INSERINDO nova pessoa
           $n_erro=0;
           /*       IMPORTANTE:
                   trim: removerá todos os caracteres '  (mesmo que haja mais de um!) 
                   Do inicio ate o  final seqüência de caracteres.
            */
            $nome=trim($nome,"'");
                     
        ////   BD para fazer teste                                         
         /// $bd_1="lixo";
        
       /*
   echo "ERRO: LINHA/807 -> $source e $val  ////  $registronovochefe <-  $campo_nome = $campo_value \r\n  -->> $cpo_nome  =  $cpo_valor   ///  $nome  ".$arr_nome_val['nome'];
   exit();        
         */
            ///// IMPORTANTE: Converter  para  UFT-8 - PHP para MYSQL
            $cpo_valor=html_entity_decode($cpo_valor, ENT_QUOTES, "UTF-8");

        
           ////  Start a transaction - ex. procedure			   
           mysql_query('DELIMITER &&'); 
           mysql_query('begin'); 
           mysql_query("LOCK TABLES $bd_1.pessoa WRITE ");
           ////
           ///
            $success=mysql_query("insert into $bd_1.pessoa  (".$cpo_nome.") values(".$cpo_valor.") "); 
           /// $success=mysql_query("insert into $bd_1.pessoa  (".$cpo_nome.") values('$cpo_valor') "); 
          ///  $success=mysql_query("insert into $bd_1.pessoa  ('$cpo_nome') values('$cpo_valor') "); 
           ////  $success=mysql_query("insert into $bd_1.pessoa  (".$campo_nome.") values(".$campo_value.") "); 
           ////  Complete the transaction 
           if( $success ) { 
                mysql_query('commit'); 
                ////  $msg_ok .="<p class='titulo_usp'>&nbsp;".$arr_nome_val['nome']." foi cadastrado.</p>".$msg_final;
                $msg_ok .="<p class='titulo_usp'>&nbsp;$nome foi cadastrado.</p>".$msg_final;
                echo $msg_ok;
           } else { 
               $n_erro=1;
               mysql_query('rollback'); 
                /// $msg_erro .="&nbsp;".$arr_nome_val['nome']." n&atilde;o foi cadastrado.".$msg_final;
                 $msg_erro .="&nbsp;$nome n&atilde;o foi cadastrado.".$msg_final;
                 echo $msg_erro;	     
           } 
           mysql_query("UNLOCK  TABLES");
           mysql_query('end'); 
           mysql_query('DELIMITER'); 
           ///
           /*
           if( intval($n_erro)<1 ) {       
                ///   Incluir novo chefe na Tabela Pessoa
                if( isset($novo_chefe) ) {
                       ///  Start a transaction - ex. procedure               
                       mysql_query('DELIMITER &&'); 
                       mysql_query('begin'); 
                       mysql_query("LOCK TABLES $bd_1.pessoa WRITE ");
                       ///
                       $success=mysql_query("update $bd_1.pessoa set chefe=$chefecodusp  WHERE codigousp=$codigousp "); 
                       //  Complete the transaction 
                       if( $success ) { 
                           mysql_query('commit'); 
                       } else { 
                           mysql_query('rollback'); 
                           $msg_erro .="&nbsp;Chefe n&atilde;o foi cadastrado.".$msg_final;
                           echo $msg_erro;         
                       } 
                       mysql_query("UNLOCK  TABLES");
                       mysql_query('end'); 
                       mysql_query('DELIMITER'); 
                       ///
                }    
           } 
           */   
           ///
	}
	//  Final - Tabela pessoa 
}	 
#
ob_end_flush(); /* limpar o buffer */
#
?>