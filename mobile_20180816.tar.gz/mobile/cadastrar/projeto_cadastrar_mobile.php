<?php 
/*  

    EDITANDO: LAFB/SPFB110903.0934

    REXP - CADASTRAR PROJETO   

 
    LAFB/SPFB110901.2219
*/
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
/// IMPORTANTE: para acentuacao php
header("Content-type: text/html; charset=utf-8");

// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 

//// Mensagens para enviar
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";
///   FINAL - Mensagens para enviar

///  Verificando SESSION incluir_arq - 20180605
$n_erro=0; $incluir_arq="";
if( ! isset($_SESSION["incluir_arq"]) ) {
     $msg_erro .= "Sessão incluir_arq não está ativa.".$msg_final;  
    ///  echo $msg_erro;
    ///  exit();
    $n_erro=1;
} else {
    $incluir_arq=trim($_SESSION["incluir_arq"]);    
}
if( strlen($incluir_arq)<1 ) $n_erro=1;
///
///   CASO OCORREU ERRO GRAVE
if( intval($n_erro)>0 ) {
    ///  Alterado em 20180621
     $msg_erro .= "<br/>Ocorrido na parte: $n_erro.".$msg_final;  
     echo $msg_erro;
     exit();
}
/***
*    Caso NAO houve ERRO  
*     INICIANDO CONEXAO - PRINCIPAL
***/
require_once("{$_SESSION["incluir_arq"]}inicia_conexao.php");

///  Variavel recebida do script/arquivo - inicia_conexao.php 
$_SESSION["m_horiz"] = $array_projeto;
///
///   Caminho da pagina local
$_SESSION["pagina_local"] = $pagina_local=$_SESSION["protocolo"]."://{$_SERVER["HTTP_HOST"]}{$_SERVER['PHP_SELF']}";

///  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]= utf8_decode("Registro de Anotação") ;
///
////  INCLUINDO CLASS - 
require_once("{$incluir_arq}includes/autoload_class.php");  
if( class_exists('funcoes') ) {
    $funcoes=new funcoes();
}
///
/*  UPLOAD: FILEFRAME section of the script
      verifica se o arquivo foi enviado      */
//  $_SESSION["display_arq"]='none';
$_SESSION["display_arq"]='none';
$_SESSION["div_form"]="block";
$_SESSION["result"]=''; 
$_SESSION["msg_upload"]="";
//  fileframe - tag iframe  type hidden
if( isset($_POST['fileframe']) ) {
  $_SESSION["div_form"]="none";
  /// include("../includes/functions.php");
  include("{$_SESSION["incluir_arq"]}includes/functions.php");
  
  ///  NOME TEMPORÃ?RIO NO SERVIDOR
  if( isset($_FILES['relatproj']['tmp_name']) ) {
      $_SESSION["result"]='OK'; $erros="";
      $_SESSION["display_arq"]='block';
      /** Conjunto de arquivos - ver tamanho total dos arquivos ***/
      $tam_total_arqs=0; $files_array= array(); 
	  $conta_arquivos = count($_FILES['relatproj']['tmp_name']);	
	  //  Verificando se existe diretorio
      $msg_erro =  "<p "
			   ." style='text-align: center; font-size: small; font-family: Verdana, Arial, Helvetica, sans-serif, Times, Georgia; font-weight:bolder;' >";
      $msg_erro_final = "</p>";
     if( intval($conta_arquivos)<1 ) {
         $_SESSION["msg_upload"] = $msg_erro."ERRO: Falta INDICAR o arquivo.".$msg_erro_final;
	     $_SESSION["result"]='FALSE'; $erros="ERRO";
     }
     /***   IMPORTANTE - Arquivo/relatorio Projeto Mobile salvar na pasta localizada Desktop
     *            usando  SESSION  pr_relatproj  iniciada no inicia_conexao.php 
     ***/
	///    Esse For abaixo para acrescentar diretorios caso nao tenha
    ///  if ( $tamanho_dir[0]<1  or  !file_exists($_SESSION["dir"]) ) {  ///  Tem que ser maior que 8 bytes
	for( $n=1; $n<3 ; $n++ ) {
        ///  if( $n==1 )	$_SESSION["dir"] = "/var/www/html/rexp3/doctos_img/A".$_POST["autor_cod"];
        if( $n==1 )  $_SESSION["dir"] = "/var/www/html".$_SESSION["pr_relatproj"]."doctos_img/A".$_POST["autor_cod"];
        if( $n==2 )	$_SESSION["dir"] .= "/projeto/";	   
	    if(  ! file_exists($_SESSION["dir"]) ) {  ///  Verificando dir e sub-dir
             $r = mkdir($_SESSION["dir"],0755);
	         if( $r===false ) {
    			 ///  echo  $msg_erro;
				 $_SESSION["msg_upload"] = $msg_erro."Erro ao tentar criar diret&oacute;rio".$msg_erro_final;
				 ///  die("Erro ao tentar criar diret&oacute;rio");
			 	 $_SESSION["result"]='FALSE';  $erros='ERRO';
		     } else {
                 chmod($_SESSION["dir"],0755);                                                   
             }
	    }
	}  
    ///
    $tamanho_dir = shell_exec("/usr/bin/du  ".$_SESSION["dir"]);  /// tamanho em bytes do diretorio
    $tamanho_dir = explode("/",$tamanho_dir);
    if( intval($conta_arquivos)>1 ) {
     	for( $i=0; $i<$conta_arquivos ; $i++ ) $tam_total_arqs += $_FILES["relatproj"]["size"][$i];   
     } else {
        $tam_total_arqs = $_FILES["relatproj"]["size"];   
     }
    ///
    $total_dir_arq = $tamanho_dir[0]+$tam_total_arqs;
	//
	/*** o tamanho maximo no arquivo configurado no  php.ini ***/
    /* $ini_max = str_replace('M', '', ini_get('upload_max_filesize'));
          $upload_max = ($ini_max * 1024)*1000000;
    */
    /***  an array to hold messages   ***/
    ///  $messages=array(); 
	$files_size= array(); $files_date= array();
    /*** check if a file has been submitted ***/
	
    if( $_SESSION["result"]=='OK' )  {
		/***  tamanho maximo do arquivo admitido em bytes   ***/
  		$max_file_size = 524288000; // bytes - B
		$espaco_em_disco = $max_file_size-$tamanho_dir[0];
		if ( $espaco_em_disco<1024 ) $tipo_tamanho = "bytes";
		if ( $espaco_em_disco>1024 and  $espaco_em_disco<1024000 ) {
		     $tipo_tamanho = "KB"; $espaco_em_disco= intval($espaco_em_disco/1024);
	   	} else if ( $espaco_em_disco>=1024000 ) {
	   	     $tipo_tamanho = "MB"; $espaco_em_disco= intval($espaco_em_disco/1024000);
		}
		//
	    if( $total_dir_arq > $max_file_size ) {
	         $erros='ERRO';
			 $result_msg= "No tem espa&ccedil;o no disco para esse arquivo. Cancelado\\n";
			 $result_msg .= "       espa&ccedil;o disponvel no disco  de ".$espaco_em_disco." $tipo_tamanho\\n";
	         $_SESSION["msg_upload"] = $msg_erro.$result_msg.$msg_erro_final;
		} 
        /** loop atraves do conjunto de arquivos ***/
        //  verifica se o arquivo esta no conjunto (array)
        if( !is_uploaded_file($_FILES["relatproj"]['tmp_name']) ) {
			   // $messages[]="Arquivo n&atilde;o armazenado\n"; 
			   $_SESSION["msg_upload"] = $msg_erro."Arquivo n&atilde;o armazenado\n".$msg_erro_final;
         		//  $erros[]='ERRO';
				$erros='ERRO';
        } elseif( $_FILES["relatproj"]['tmp_name'] > $max_file_size )  {
              // verifica se o arquivo menor que o tamanho maximo permitido
              $_SESSION["msg_upload"]= $msg_erro."O arquivo excedeu o tamanho limite permitido $max_file_size $tipo_tamanho ";
			  $_SESSION["msg_upload"].=$msg_erro_final;
			  $erros = 'ERRO';
        } else {
                // copia o arquivo para o diretorio especificado
				 $filename="P".$_POST["nprojexp"]."_".$_FILES["relatproj"]["name"];
				 if( @copy($_FILES["relatproj"]['tmp_name'],$_SESSION["dir"].$filename) )  {
                     /*** give praise and thanks to the php gods ***/
					 $erros='';
                     $_SESSION["msg_upload"]= $msg_erro."Arquivo: ".$_FILES["relatproj"]["name"].' foi armazenado&nbsp;';
         			 $_SESSION["msg_upload"].=$msg_erro_final;
					 $files_array[]=$_FILES["relatproj"]["name"];
					 $files_size[]=$_FILES["relatproj"]["size"];
					 //  filemtime â€” ObtÃ©m o tempo de modificaÃ§Ã£o do arquivo
            	     $files_date[] = date('d/m/Y H:i:s', filemtime($_SESSION["dir"].$filename));
					 $files_type[] = mime_type($filename);
					// Permissao do arquivo
					 chmod($_SESSION["dir"].$filename,0755);									
                } else  {
                     /***  an error message  ***/
                     $_SESSION["msg_upload"]= $msg_erro.'Armazenamento '.$_FILES["relatproj"]["name"].' FALHA';
         			 $_SESSION["msg_upload"].=$msg_erro_final;
		     	     $erros = 'ERRO';
                }
		}
     } 
     ///  FINAL - IF  \$_SESSION["result"]
	 ///
     $_SESSION["erros"] = trim($erros);
	 //   Incluindo o nome do arquivo na tabela  projeto
     if( trim($erros)=='' ) {
           //  OCORREU  ERRO NESSA JANELA DO JAVASCRIPT
          //  OCORREU  echo "<p style='text-align: center;'>Aguarde um momento.</p>";
          //
	      	$elemento=5; $elemento2=6;  
            ///  include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");
            include("php_include/ajax/includes/conectar.php");
			///  $local_arq0 = $_SESSION["dir"].$filename;
			$nprojexp = $_POST["nprojexp"]; $autor_cod = $_POST["autor_cod"];
			$local_arq  = html_entity_decode(trim($filename));
           ///  mysql_db_query - Esta funcao e obsoleta, nao use esta funcao - Use mysql_select_db() ou mysql_query()
            $success = mysql_query("UPDATE $bd_2.projeto SET relatproj='$local_arq'  WHERE ( numprojeto=$nprojexp  and  autor=$autor_cod ) ");
			//
			if( ! $success ) {
                $_SESSION["msg_upload"]= $msg_erro.'Armazenamento '.$_FILES["relatproj"]["name"].' FALHA'.mysql_error();
   			    $_SESSION["msg_upload"].=$msg_erro_final;
			} else {
                 $success=mysql_query("SELECT nome from $bd_1.pessoa where codigousp=$autor_cod  ");
                 $autor_proj=htmlentities(mysql_result($success,0,0),ENT_QUOTES,"UTF-8");
                 $_SESSION["msg_upload"] .= $msg_erro."Projeto $nprojexp do autor ".$autor_proj." foi conclu&iacute;do.";
				 $_SESSION["msg_upload"] .=$msg_erro_final;		    
            }		  
	}
  } 
}  //  FINAL do IF UPLOAD  
//
$http_host="";
if( isset($_SESSION["http_host"]) ) $http_host=$_SESSION["http_host"];
///
?>
<!DOCTYPE html>
<html lang="pt-BR" >
<head>
<meta charset="UTF-8" />
<meta name="author" content="Sebastião Paulo" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta name="ROBOTS" content="NONE"> 
<meta http-equiv="Expires" content="-1" >
<meta name="GOOGLEBOT" content="NOARCHIVE"> 
<!--  <link rel="shortcut icon"  href="imagens/agencia_contatos.ico"  type="image/x-icon" />  -->
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>REXP - Cadastrar Projeto</title>
<link  type="text/css"  href="<?php echo $host_pasta;?>css/estilo.css" rel="stylesheet"  />
<!--  <link  type="text/css"   href="<?php echo $http_host;?>css/style_titulo.css" rel="stylesheet"  /> -->
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/functions.js"  charset="utf-8" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/responsiveslides.min.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/resize.js" ></script>
<!--   <script type="text/javascript" src="<?php echo $host_pasta;?>js/verifica_mobile.js" ></script>  -->
<?php
///  Arquivo javascript em PHP
////  
include("{$_SESSION["incluir_arq"]}js/projeto_cadastrar_js.php");
///
$_SESSION["n_upload"]="ativando";

///  Para mudar de pagina no MENU usando  dochange.php  ou  domenu.php
///  require("{$_SESSION["incluir_arq"]}includes/dochange.php");
require("{$_SESSION["incluir_arq"]}includes/domenu.php");
///
?>
</head>
<body  id="id_body"   oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"   >
    <!-- onkeydown="javascript: no_backspace(event);" >  -->
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho -->
<div id="cabecalho"  >
<?php include("{$_SESSION["incluir_arq"]}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$_SESSION["incluir_arq"]}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<?php
//   CADASTRAR PROJETO
//  $m_titulo="Projeto";
if( isset($_GET["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_GET["m_titulo"];    
} elseif( isset($_POST["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_POST["m_titulo"];      
}  
//
if( isset($_SESSION["usuario_conectado"]) ) $usuario_conectado = $_SESSION["usuario_conectado"];
//  Definindo valores nas variaveis
if( isset($_SESSION["permit_pa"]) ) $permit_pa=$_SESSION["permit_pa"]; 
//   
?>
<!--  Mensagens e Titulo  -->
<section class="merro_e_titulo" >
<div  id="label_msg_erro"  >
</div>
<p class='titulo_usp' >Cadastrar&nbsp;<?php echo ucfirst($_SESSION["m_titulo"]);?></p>
</section>
<!-- Final -  Mensagens e Titulo  -->
<?php
    $m_erro=0;
//  Verificando permissao para acesso Supervisor/Orientador
// include("../includes/orientador_pa.php");
//
//  PA:  superusuario,  chefe,  subchefe, orientador, anotador  -  includes/array_menu.php
//  if( ( $_SESSION["permit_pa"]=="0"  or $_SESSION["permit_pa"]=="10"  or $m_pa_coord=="30" ) and $m_erro=="0"  ) {    
//  if( ( $_SESSION["permit_pa"]=="0"  or $_SESSION["permit_pa"]=="10"  ) and $m_erro=="0"  ) {    
// if( ( $_SESSION["permit_pa"]<=$_SESSION["array_usuarios"]["superusuario"]  or $_SESSION["permit_pa"]>$_SESSION["array_usuarios"]["orientador"] ) and $m_erro=="0"  ) {    
if( ( $_SESSION["permit_pa"]<=$array_pa["super"]  or $_SESSION["permit_pa"]>$array_pa["orientador"] ) and $m_erro=="0"  ) {    
    echo  "<p  class='titulo_usp' >Procedimento n&atilde;o autorizado.<br>"
                ."N&atilde;o consta como Orientador ou Superior</p>";
    exit() ;
}
if( strlen(trim($_SESSION["msg_upload"]))>1 ) {
?>
<script type="text/javascript" language="javascript">
    document.getElementById('label_msg_erro').style.display="block";              
    ////  document.getElementById('msg_erro').innerHTML="<?php echo $_SESSION["msg_upload"]; ?>";
    document.getElementById('label_msg_erro').innerHTML="<?php echo $_SESSION["msg_upload"]; ?>";              
</script>
<?php
    if( strlen(trim($_SESSION["erros"]))<1 ) $_SESSION["display_arq"]='none';
}       
///
?>        
<div id="arq_link"  style="display: none;" >
  <form name="form_arq_link"  method="post"  enctype="multipart/form-data"  action="<?php echo $pagina_local; ?>" 
   onsubmit="javascript: enviar_dados_cad('submeter','relatproj');" >
        <!-- Relatorio Externo (link) Projeto -->   
        <div class="td_inicio1" style="text-align: justify;" >
             <label for="relatproj" style="vertical-align: middle; cursor: pointer;" title="link para o Arquivo do Projeto" >
                <span class="asteristico" >*</span>&nbsp;Arquivo (link):&nbsp;</label>
                              <input type="hidden" name="fileframe" value="true">
               <!-- Target of the form is set to hidden iframe -->
               <!-- From will send its post data to fileframe section of this PHP script (see above) -->
               <input type="file" name="relatproj"  id="relatproj" size="90" title="Relatório Externo do Projeto (link)" 
                  required="required"  style="cursor: pointer; vertical-align:middle;" onChange="javascript: jsUpload(this);" />
               <input  type="hidden"  id="nprojexp" name="nprojexp"  />
               <input  type="hidden"  id="autor_cod" name="autor_cod" />       
               <input  type="hidden"  id="m_titulo" name="m_titulo"  value="<?php echo $_SESSION["m_titulo"];?>" />
        </div>
         <!-- FINAL - Relatorio Externo (link) Projeto -->

         <!--  Aviso na espera do processo -->
            <div id="aguarde_arq" style="text-align: center; display: none; border: 3px double #000000; width:100%">Aguarde. Esse processo pode demorar...</div>   
         <!-- Final - Aviso na espera do processo -->   
         
         <!--  Enviar Relatorio/Arquivo Projeto  -->
         <div class="td_inicio1" style="text-align: center;" >
           <button  type="submit"  name="enviar_arq" id="enviar_arq" class="botao3d" 
              style="width: 160px; cursor: pointer;"  title="Enviar"  acesskey="E"  alt="Enviar" 
                onclick="javascript: if(  trim(document.getElementById('relatproj').value)=='' ) { document.getElementById('relatproj').focus(); return false; } " >
               Enviar arquivo&nbsp;<img src="../imagens/enviar.gif" alt="Enviar Arquivo"  style="vertical-align:text-bottom;" >
           </button>
         </div>  
           <span class="asteristico" >*</span>&nbsp;<b>Campo obrigat&oacute;rio</b>
         <!-- Final - Enviar Relatorio/Arquivo Projeto  -->   
  </form>
  <script type="text/javascript">
   /* This function is called when user selects file in file dialog */
    function jsUpload(upload_field) {
            // Este e apenas um exemplo de verificacao de extensoes de arquivo
            //  var re_text = /\.txt|\.xml|\.zip/i;
            var re_text = /\.pdf/i;
            var filename = upload_field.value;
            /* Checking file type */
             if( filename.search(re_text) == -1)  {
                  //  alert("File does not have text(txt, xml, zip) extension");
                  alert("ERRO: Esse arquivo não tem formato PDF");
                  document.getElementById('relatproj').focus();
                  //  upload_field.form.reset();
                  return false;
             }
             /*
                        upload_field.form.submit();
                        document.getElementById('upload_status').value = "uploading file...";
                        upload_field.disabled = true;
                        return true;
                        */
    }
  </script>
            </div>
<!--  DIV abaixo os dados antes de pedir arquivo para upload   -->
<div id="div_form" class="div_form" style="overflow:scroll;" >
   <form name="form1" id="form1"  method="post" enctype="multipart/form-data"  >
      <section>
          <article class="projetoarticle1"  >
             <label title="Orientador do Projeto">Orientador:&nbsp;</label>
                <!-- N. Funcional USP - Autor/Orientador -->
                  <?php 
                        ///  Verificando se session_start - ativado ou desativado
                        $elemento=5; $elemento2=6;
                        include("php_include/ajax/includes/conectar.php");                                    
                        /////           
                        /***          
                          mysql_query("SET NAMES 'utf8'");
                          mysql_query('SET character_set_connection=utf8');
                          mysql_query('SET character_set_client=utf8');
                          mysql_query('SET character_set_results=utf8');
                        ***/
                        ///  Executando Select/MySQL
                          ///   Utilizado pelo Mysql/PHP - IMPORTANTE -20180615      
                          /***
                            *    O charset UTF-8  uma recomendacao, 
                            *    pois cobre quase todos os caracteres e 
                            *    símbolos do mundo
                        ***/
                        mysql_set_charset('utf8');
                        ///                         
                        ///                         
                        //  Nao precisa chamar de novo o arquivo ja foi chamado
                        // @require_once("/var/www/cgi-bin/php_include/ajax/includes/class.MySQL.php");
                        // $result = $mySQL->runQuery("select codigousp,nome,categoria from pessoa  order by nome ",$db_array[$elemento]); 
                        $sqlcmd="SELECT distinct a.codigousp,a.nome,a.categoria FROM "
                                  ." $bd_1.pessoa a, $bd_1.usuario b WHERE "
                                  ." a.codigousp=b.codigousp and a.codigousp=$usuario_conectado and "
                                  ." b.pa<=".$array_pa["orientador"]." order by a.nome "; 
                        ///
                        $result = mysql_query($sqlcmd);
                        if( ! $result ) {
                             die('ERRO: Select tabelas pessoa e usuario -&nbsp;db/mysql:&nbsp;'.mysql_error());
                        }
                        ///
                        ///  Cod/Num_USP/Autor
                        $m_linhas = mysql_num_rows($result);
                        if( intval($m_linhas)<1 ) {
                            $autor="== Nenhum encontrado ==";
                        } else {
                             $_SESSION["autor_codigousp"]=$usuario_conectado;
                             $autor_nome=mysql_result($result,0,"nome");
                             $autor_nome=htmlentities($autor_nome,ENT_QUOTES,"UTF-8");
                             $autor_categoria=mysql_result($result,0,"categoria");;
                        }
                        if( isset($result) ) mysql_free_result($result); 
                        // Final da Num_USP/Nome Responsavel
                        //   echo "<span class='td_inicio1' title='Nome do Autor ResponsÃ¡vel do Projeto' >$autor_nome</span>";
                        //  Numero do novo PROJETO
                        //  Verificando campos 
                        $m_regs=0;
                        ///
                        $result_projetos=mysql_query("SELECT  max(numprojeto) as n FROM $bd_2.projeto "
                                    ." WHERE trim(autor)='".$_SESSION['autor_codigousp']."' ");
                        ///            
                        if( ! $result_projetos ) {
                             die("ERRO: Consultando n&uacute;mero do &uacute;ltimo projeto -&nbsp;db/mysql:&nbsp;".mysql_error());
                            exit();
                        }
                        $num_projs = (int) mysql_result($result_projetos,0,"n");
                        $_SESSION["numprojeto"]=$num_projs+1;
                        if( isset($result_projetos) ) mysql_free_result($result_projetos);
                        ///  htmlentities($descricao,ENT_QUOTES,"UTF-8")
                    ?>  
                       <span class='td_inicio1' style="height: auto; border:none; background-color:#FFFFFF; color:#000000;" title='Nome do Autor ResponsÃ¡vel do Projeto' >
                                      &nbsp;<?php echo $autor_nome; ?>&nbsp;
                       </span>
                        <input type="hidden" name="autor" id="autor" size="80" maxlength="86"  value="<?php echo $_SESSION["autor_codigousp"];?>" />
                        <span class="td_inicio1">
                               <label   title="N&uacute;mero do Projeto"   >Nr. do Projeto:&nbsp;</label>
                               <span class='td_inicio1' style="padding: 0; overflow: hidden; border:none; background-color:#FFFFFF; color:#000000;" title='N&uacute;mero do Projeto' >&nbsp;<?php echo $_SESSION["numprojeto"];?>&nbsp;</span>
                                    <input type="hidden" name="numprojeto" id="numprojeto"   value="<?php echo $_SESSION["numprojeto"];?>" />
                        </span>
          </article>      
          <article class="projetoarticle1"  >
            <!-- Titulo do Projeto  -->
              <label for="titulo"  style="vertical-align: top; color:#000000; background-color: #32CD99; cursor:pointer;" title="TÃ­tulo do Projeto"   ><span class="asteristico" >*</span>&nbsp;T&iacute;tulo:&nbsp;</label>
              <textarea rows="3" cols="45" name="titulo" id="titulo" required="required"  autofocus="autofocus" 
                           onKeyPress="javascript:exoc('label_msg_erro',0,'');limita_textarea('titulo');" title='Digitar T&iacute;tulo do Projeto' 
                           style="cursor: pointer; overflow:auto;"  onblur="javascript: alinhar_texto(this.id,this.value);"  >
              </textarea>      
              <!-- Final - Titulo do Projeto  -->
          </article>
          <article class="projetoarticle1"  >
             <label for="objetivo"  style=" cursor:pointer;" title="Objetivo do Projeto"   ><span class="asteristico" >*</span>&nbsp;Objetivo:&nbsp;</label>
                <?php 
                    ///  Objetivo
                    /// 
                    /// $result2 = $mySQL->runQuery("select codigo,descricao from objetivo order by codigo ",$db_array[$elemento]); 
                    $result2 = mysql_query("select codigo,descricao from $bd_2.objetivo order by codigo "); 
                    ////
                    if( ! $result2 ) {
                        die("ERRO: Select codigo,descricao from objetivo -&nbsp;db/mysql:&nbsp;".mysql_error());  
                    }
                    ///
                 ?>
                  <!-- Objetivo  -->
                     <select name="objetivo" id="objetivo" class="td_select" style="background-color: #FFFFFF;"  
                          onfocus="exoc('label_msg_erro',0,'');"  title="Selecionar Objetivo" required="required" >                   
                 <?php
                       /// Verifica o numero de registros
                       if( intval($m_linhas)<1 ) {
                           echo "<option value='' >== Nenhum encontrado ==</option>";
                       } else {
                           echo "<option value='' >== Selecionar ==</option>";
                           while( $linha=mysql_fetch_array($result2)) {       
                                  $descricao=htmlentities($linha['descricao'],ENT_QUOTES,"UTF-8");
                                  echo "<option  value=".$linha['codigo']."  >";
                                  echo  ucfirst($descricao)."&nbsp;</option>" ;
                           }
                 ?>
                     </select>
                 <?php
                     if( isset($result2) ) mysql_free_result($result2); 
                     }
                     /// Final objetivo
                 ?>  
                 </article>
                 <article class="projetoarticle1"  >
                    <label for="fonterec" style="vertical-align: middle; cursor: pointer;" title="Fonte Principal de Recursos (Pr&oacute;prio, FAPESP, CNPQ, etc)"   >Fonte Principal de Recursos:&nbsp;</label>
                        <input type="text" name="fonterec"   id="fonterec"  size="30"  maxlength="16" 
                             title="Digitar Fonte Principal de Recursos (Pr&oacute;prio, FAPESP, CNPQ, etc)"  onkeypress="javascript:exoc('label_msg_erro',0,'');" 
                             onblur="javascript: alinhar_texto(this.id,this.value); soLetrasMA(this.id)"  style="cursor: pointer;"  />
                 </article>
                 <article class="projetoarticle1"  >
                    <!-- Nr. Processo  -->
                     <label for="fonteprojid"  title="Nr. Processo"  >Nr. Processo:&nbsp;</label>
                     <span>
                       <input type="text" name="fonteprojid" id="fonteprojid" size="36" maxlength="24" onkeypress="javascript:exoc('label_msg_erro',0,'');" 
                          title="Digitar Nr. Processo"  onblur="javascript: alinhar_texto(this.id,this.value)" />
                     </span>
                     <!-- Final - Nr. Processo -->
                 </article>
                 <article class="projetoarticle1"   >
                     <div class="nright" >
                         <!-- Data inicio do Projeto -->                                
                            <label for="datainicio"  title="Data de Início do Projeto" >Data in&iacute;cio:&nbsp;</label>
                                <input type="date" name="datainicio"  id="datainicio" maxlength="10" pattern="[0-9]{2}\/[0-9]{2}\/[0-9]{4}$"
                                    title="Digitar Data in&iacute;cio - exemplo: 01/01/1998"  required="required" />
                            <!-- Final - Data inicio do Projeto -->

                            <!-- Data Final do Projeto -->
                            <label for="datafinal"  title="Data Final do Projeto" >Data final:&nbsp;</label>
                                <input type="date" name="datafinal" id="datafinal"  maxlength="10" 
                                 title="Digitar Data Final - exemplo: 01/01/1998" />
                            <!-- Final - Data Final do Projeto -->
                     </div>   
                 </article>
                 <article class="projetoarticle3"  >
                     <div>
                       <!-- Numero de Coautores -->
                        <label for="coresponsaveis"  >N&uacute;mero de Co-Respons&aacute;veis:&nbsp;</label>
                             <input  type="number" name="coresponsaveis" id="coresponsaveis" min="0" max="99"  pattern="[0-9]" 
                                 maxlength="3" title="Digitar  N&uacute;mero de Co-Respons&aacute;veis"  onkeypress="javascript:exoc('label_msg_erro',0,'');" 
                                 onKeyup="javascript: n_coresponsaveis(this,event); "  value="" style="padding: 1px; font-weight: bold;" 
                                 onblur="javascript: if( this.value<1 ) exoc('incluindo_coresponsaveis',0);"   />&nbsp;
                             <input  type="button"  onclick="javascript: enviar_dados_cad('coresponsaveis');"  id="busca_coresponsaveis" 
                                 title='Clicar'  style="cursor: pointer; width: 60px;"   onkeypress="javascript:exoc('label_msg_erro',0,'');" 
                                  value="Indicar"  class="botao3d"  >
                       <!-- Final - Numero de Coautores -->
                     </div>
                     <!-- Inclusao de Coautores - caso tenha no Projeto - fica Oculto sem Coresponsaveis -->
                     <div id="incluindo_coresponsaveis" ></div>
                     <!-- Final - Inclusao de Coautores -->           
                 </article>     
                 
                 <!--  TAGS  type reset e  submit  -->                                              
                 <article class="projetoarticlexy"  >
                    <!-- Limpar campos -->                  
                       <button type="button"  name="limpar" id="limpar"  class="botao3d" style="cursor: pointer;"  
                            onclick="javascript: enviar_dados_cad('reset','<?php echo "{$_SESSION["pagina_local"]}";?>'); return false;"  
                            title="Limpar"  acesskey="L"  alt="Limpar" >
                          Limpar&nbsp;<img src="../imagens/limpar.gif" alt="Limpar" style="vertical-align:text-bottom;" >
                       </button>
                    <!-- Final - Limpar  -->
                    <!-- Enviar -->                  
                       <button  type="button"  name="enviar" id="enviar" class="botao3d"    
                           title="Enviar"  acesskey="E"  alt="Enviar"  onclick="javascript: enviar_dados_cad('submeter','PROJETO',this.form);return false;"   >
                         Enviar&nbsp;<img src="../imagens/enviar.gif" alt="Enviar"  style="vertical-align:text-bottom;"  >
                       </button>
                    <!-- Final -Enviar -->
                 </article>                  
                 <!--  FINAL - TAGS  type reset e  submit  -->
                         <article class="projetoarticle3" style="margin-left: 0px;padding-left: 0px;"  >
                               <span class="asteristico" >*</span>&nbsp;<b>Campo obrigat&oacute;rio</b>    
                         </article>
                    </section>
                </form>
            </div>
        </div>
   <!-- Final Corpo -->
<!-- Rodape -->
<div id="rodape"  >
   <?php include_once("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>
