<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Lang" content="en">
<meta name="author" content="">
<meta http-equiv="Reply-to" content="@.com">
<meta name="generator" content="PhpED 6.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="creation-date" content="06/01/2011">
<meta name="revisit-after" content="15 days">
<style type="text/css">
div.scrollTable{
    background: #ffffff;
    border: 1px solid#888;
}

div.scrollTable table.header, div.scrollTable div.scroller table{
      width:100%; 
      _width:100%; 
/*    width:1000px;
    _width:1000px;
    */
    border-collapse: collapse;
}

div.scrollTable table.header th, div.scrollTable div.scroller table td{
    border: 1px solid #444;
    padding: 3px 5px;
    font-family: "Times New Roman", Times,  Arial, Geneva, Helvetica, sans-serif, 'Courier New', Courier, monospace, Verdana,   Garamond, Georgia, serif;
}

div.scrollTable table.header th{
    background: #ddd;
}

div.scrollTable div.scroller{
    height: 200px;
    overflow: auto;
 }

div.scrollTable .coluna75px{
    width: 75px;
}

div.scrollTable .coluna100px{
    width: 100px;
}

div.scrollTable .coluna150px{
    width: 150px;
}
</style>
<title>Untitled</title>
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>
<?php

$arquivo="/var/www/html/rexp/doctos_img/A2416911/projeto/P2_solicitaÃ§Ã£o controle de acesso.pdf";

if( file_exists(utf8_decode($arquivo)) ) {
    echo "<p styel='text-align:center;color:#00FF00;font-size: larger;'>Arquivo $arquivo  - EXISTE </p><br/>";
} else {
    echo "<p styel='text-align:center;color:#B0FF0F;font-size: larger;'>Arquivo $arquivo  - NÃO EXISTE </p><br/>";
}


$string = '/var/www/html/rexp/mobile/';
$pattern = '/mobie|mobile\//i';
$replacement = '';
$testest = preg_replace('/mobie|mobile\//i', '', $string);
echo "<p style='font-size:40px;'>$testest</p>";
echo "<br/>";

$princ="/rexp";

$posicao=strpos($string,$princ);

if( $posicao ) {
    $posicaor=strripos($string,"/rexp");
    $testest = substr($string,0,$posicao);
    $testest .=$princ;
    echo "<p style='font-size:40px;'> Passou aqui -- $posicao e $posicaor  ---    $testest</p>";
    echo "<br/>";
}




$server_name=$_SERVER["SERVER_NAME"];
define('SITE_NOME', 'http://sol.fmrp.usp.brx/');  

$arrayok= Array("SERVER['REQUEST_URI " => $_SERVER['REQUEST_URI'],"HTTP_HOST" => $_SERVER['HTTP_HOST'] );
foreach( $arrayok as $key => $valor   ) {
      echo "<br>  $key =  $valor ";
}

echo   "<br/>".SITE_NOME."  ---  $server_name  = {$_SERVER["SERVER_NAME"]} --- http_host = {$_SERVER["HTTP_HOST"]}  --- {$_SERVER['DOCUMENT_ROOT']} ";
exit();


$array_cps_largura= array("NUMPROJETO" => 80, "NR" => 92, "T?TULO" => 600, "DETALHES" => 70, "DATA" => 90 );
$_SESSION["NUMPROJETO"]=$array_cps_largura['NUMPROJETO'];
$NUMPROJETO=$array_cps_largura['NUMPROJETO'];
echo "\$_SESSION[NUMPROJETO] = {$_SESSION["NUMPROJETO"]} <br>";    
?>
<script type="text/javascript">
   var b = "<?php echo $a;?>";
  alert(" a = "+b);
</script>

<div class="scrollTable">
    <table class="header">
        <tr>
            <th class="scrollTable" style="width:<?php echo $NUMPROJETO;?>px;text-align: justify;" >Nr/Projeto</th>
            <th style="width:<?php echo $array_cps_largura['NR'];?>px;" >Nr/Anota??o</th>
            <th style="width:<?php echo  $array_cps_largura['T?TULO'];?>px;">T?tulo/Anota??o</th>
            <th style="width:<?php echo  $array_cps_largura['DETALHES'];?>px;text-align: center;">Detalhes</th>
            <th style="width:<?php echo  $array_cps_largura['DATA'];?>px;text-align: center;">Data</th>
            <th></th>
        </tr>
    </table>
    <div class="scroller">
        <table>
            <tr>
            <td class="scrollTable" style="width:<?php echo $NUMPROJETO;?>px;text-align: right;" >11</td>
            <td style="width:<?php echo $array_cps_largura['NR'];?>px;" >125</td>
            <td style="width:<?php echo $array_cps_largura['T?TULO'];?>px;">T?tulo/Anota??o Feito na Anota??o Desenvolvido</td>
            <td style="width:<?php echo $array_cps_largura['DETALHES'];?>px;text-align: center;">Detalhes</td>
            <td style="width:<?php echo $array_cps_largura['DATA'];?>px;font-weight: bold;text-align: center;">25/11/2011</td>
           <td>&nbsp;</td>
            </tr>
        </table>
    </div>
</div> 
<br>
<?php
/*
ob_start();  /// start reading the internal buffer
exec('ls -altsh /tmpe/',$output);
////  var_dump($output);          
var_dump(isset($output));          
$resultado = ob_get_contents(); /// assigning the internal buffer contents to variable
ob_end_clean(); 
echo "<br/><br/>".strlen($resultado)."<br/> $resultado  --->>> ".count($resultado)."<br/>";
*/

$output = array();
$return_var = -1;
$pasta="/tmpe";
$cmd="ls -altsh ".$pasta;
////  exec($cmd."2>&1",$output);
///exec($cmd . " 2>&1", $output,$return_var);
exec($cmd, $output,$return_var);
///  $array=serialize($output); // $results now contains output from print_r
////  echo  "<br/><br/>--->>>  $results = $results   ".sizeof($results);
////  echo "<br/><br/><br/>-------------------------------".$array[1];    
echo "<br/>-->> $output<br/><br/><p style='font-size:medium;font-weight:bolder;'>$return_var</p>";    

echo shell_exec($cmd);

echo "<p style='font-weight:bold;' >----------------------------------------------------</p>";

system($cmd,$return_var);

echo "<p style='font-weight:bold;' >>>>>>>>>>> $return_var  <<<<<<<<<br/></p>";

$last_line = system('/bin/lsxc', $retval);

// Printing additional info
echo '
</pre>
<hr />Last line of the output: ' . $last_line . '
<hr />Return value: ' . $retval;

?>

</body>
</html>
