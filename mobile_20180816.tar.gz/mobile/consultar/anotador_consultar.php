<?php 
//   Iniciando conexao - CONSULTAR ANOTADOR
/*
    EDITANDO: LAFB/SPFB110903.0934

    REXP - CONSULTAR ANOTADOR

 
    LAFB/SPFB110901.2219
*/
//  ==============================================================================================
//  ATENCAO: SENDO EDITADO POR LAFB/SPFB  - CONSULTAR ANOTADOR
//  ==============================================================================================
//
///  Verificando se session_start - ativado ou desativado
if( ! isset($_SESSION)) {
   session_start();
}
// include('inicia_conexao.php');
extract($_POST, EXTR_OVERWRITE); 
//// Mensagens para enviar
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";

$msg_final="</span></span>";
///   FINAL - Mensagens para enviar

///
if( isset($_SESSION["incluir_arq"]) ) {
    $incluir_arq=$_SESSION["incluir_arq"];  
} else {
    echo "Sessão incluir_arq não está ativa.";
    exit();
}
///
$incluir_arq=$_SESSION["incluir_arq"];
///
///  HOST mais a pasta principal do site - host_pasta
$host_pasta="";
if( isset($_SESSION["host_pasta"]) ) {
     $host_pasta=$_SESSION["host_pasta"];  
} else {
     $msg_erro .= "Sessão host_pasta não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
///  DEFININDO A PASTA PRINCIPAL 
if( ! isset($_SESSION["pasta_raiz"]) ) {
     $msg_erro .= "Sessão pasta_raiz não está ativa.".$msg_final;  
     echo $msg_erro;
     exit();
}
///
$_SESSION["url_central"] = "http://".$_SESSION["http_host"].$_SESSION["pasta_raiz"];
$raiz_central=$_SESSION["url_central"];
///
///  Inicia conexao
include("{$incluir_arq}inicia_conexao.php");
////
///    MENU HORIZONTAL
include("{$incluir_arq}includes/array_menu.php");
if( isset($_SESSION["array_pa"]) ) {
   $array_pa = $_SESSION["array_pa"];       
   $permit_anotador = $array_pa['anotador'];
   $permit_orientador = $array_pa['orientador'];
}
///
$_SESSION["m_horiz"] = $array_projeto;

$usuario_conectado = $_SESSION["usuario_conectado"];
if( isset($_SESSION["permit_pa"]) ) $permit_pa = $_SESSION["permit_pa"];
///   Caminho da pagina local
$pagina_local ="http://".$_SERVER["HTTP_HOST"].$_SERVER['PHP_SELF'];

///
///  Titulo do Cabecalho - Topo
if( ! isset($_SESSION["titulo_cabecalho"]) ) $_SESSION["titulo_cabecalho"]="Registro de Anota??o";
// $_SESSION['time_exec']=180000;
//
////  INCLUINDO CLASS - 
require_once("{$incluir_arq}includes/autoload_class.php");  
$funcoes=new funcoes();
$funcoes->usuario_pa_nome();
$_SESSION["usuario_pa_nome"]=$funcoes->usuario_pa_nome;
///
?>
<!DOCTYPE html >
<html lang="pt-br"  >
<head>
<meta charset="utf-8" >
<meta name="author" content="LAFB/SPFB" />
<meta http-equiv="Cache-Control" content=" no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0">
<meta http-equiv="PRAGMA" content="NO-CACHE">
<meta name="ROBOTS" content="NONE"> 
<meta http-equiv="Expires" content="-1" >
<meta name="GOOGLEBOT" content="NOARCHIVE"> 
<link rel="shortcut icon"  href="imagens/pe.ico"  type="image/x-icon" />  
<meta http-equiv="imagetoolbar" content="no">  
<title>REXP - Consultar Anotação</title>
<!--  <script type="text/javascript"  language="javascript"   src="../includes/dochange.php" ></script> -->
<link  type="text/css"  href="<?php echo $host_pasta;?>css/estilo.css" rel="stylesheet" />
<script  type="text/javascript" src="<?php echo $host_pasta;?>js/XHConn.js" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/functions.js"  charset="utf-8" ></script>
<script type="text/javascript"  src="<?php echo $host_pasta;?>js/1/jquery.min.js?ver=1.9.1" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/responsiveslides.min.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/resize.js" ></script>
<script type="text/javascript" src="<?php echo $host_pasta;?>js/verifica_mobile.js" ></script>
<script  language="javascript"  type="text/javascript" >
/* <![CDATA[ */
///   JavaScript Document
/*   PARA ALTERAR SENHA       */
function enviando_dados(source,val,string_array) {
   ///
    /// Verificando se a function exoc existe
    if( typeof exoc=="function" ) {
        ///  Ocultando ID  e utilizando na tag input comando onkeypress
         exoc("label_msg_erro",0);  
    } else {
        alert("funcion exoc nao existe");
    }
    ///  
    ///  Verificando variaveis
    if( typeof(source)=="undefined" ) var source=""; 
    if( typeof(val)=="undefined" ) var val=""; 
    if( typeof(string_array)=="undefined" ) var string_array=""; 
    ///
    
 ///   alert(" anotador_consultar.php/104 -  source = "+source+" --  val = "+val+" - string_array = "+string_array);      
   
   var opcao = source.toUpperCase();
   
 //// alert("CONTINUAR anotador_consultar.js/52 -  source = "+opcao+" -- val = "+val+" -string_array = "+string_array);
    //
    if ( ( typeof(string_array)!='undefined') && ( opcao=="PROJETO" || opcao=="LISTA" )  ) {
        if( document.getElementById('resultado_anotador') ) {
           document.getElementById('resultado_anotador').style.display="none";    
        }
        var m_id_type  = document.getElementById("projeto").type;
        var m_id_title = document.getElementById("projeto").title;
        var m_id_name  = document.getElementById("projeto").name;
        if( m_id_type=="select-one" ) {  
             var m_id_value = trim(document.getElementById(m_id_name).value);
             if( m_id_value=="" ) {
                   document.getElementById("label_msg_erro").style.display="block";
                   var msg_erro = "<span class='texto_normal' style='color: #000; text-align: center;'>";
                   msg_erro += "<span style='color: #FF0000;'>ERRO:&nbsp;";
                   var final_msg_erro = "&nbsp;</span></span>";
                   m_tit_cpo = "<span style='color: #000000;'>&nbsp;&nbsp;"+m_id_title+"</span>";
                   msg_erro = msg_erro+'&nbsp;Corrigir campo.'+m_tit_cpo+final_msg_erro;
                   document.getElementById("label_msg_erro").innerHTML=msg_erro;    
                   document.getElementById(m_id_name).focus();
                   return;
                   ////
             }
        } 
    }
    ///  Utilizando Navegador 
    var browser="";
    if( typeof navegador=="function" ) {
         var browser=navegador();
    }  
    ///
    var poststr = "source="+encodeURIComponent(source)+"&val="+encodeURIComponent(val)+"&m_array="+escape(string_array)+"&navegador="+browser; 
         
    /*   Aqui eu chamo a class do AJAX */
    var myConn = new XHConn();
        
    /*  Um alerta informando da n?o inclus?o da biblioteca - AJAX   */
    if ( !myConn ) {
          alert("XMLHTTP n?o dispon?vel. Tente um navegador mais novo ou melhor.");
          return false;
    }
    //
    //  Serve tanto para o arquivo projeto, anotacao e outros - Cadastrar
   //   ARQUIVO abaixo onde recebe os DADOS da PAGINA e EXECUTA os procedimentos e Retorna resultado
    ////  var receber_dados = "../includes/consultar_anotador_ajax.php";
    var receber_dados = "srv_mostraanotador.php";
    ///
     var inclusao = function (oXML) { 
                         //  Recebendo os dados do arquivo ajax
                         //  Importante ter trim no  oXML.responseText para tirar os espacos
                         var m_dados_recebidos = trim(oXML.responseText);
                         var lnip = m_dados_recebidos.search(/Nenhum|ERRO:/i);
                         ///  Caso ocorreu erro
                         if( parseInt(lnip)!=-1 ) {
                              ///  Ativando ID mensagem de erro
                              exoc("label_msg_erro",1,m_dados_recebidos);                   
                         } 
                         ////
                         
     ////    alert(" anotador_consultar.php/162 - source="+source+" -- val = "+val+"  -- string_array = "+string_array);                                                        
                         if(  opcao=="CONJUNTO"   ) { 
                               var m_elementos = "instituicao|unidade|depto|setor|bloco|sala";
                                var new_elements = m_elementos.split("|");
                                //// Desativando alguns campos
                                document.getElementById("label_msg_erro").style.display="none";
                                if ( cpo_ant.toUpperCase()=="INSTITUICAO" ) {
                                     limpar_campos(new_elements);
                                }  else if( cpo_ant.toUpperCase()=="SALA" ) {
                                      n_sel_opc = 0;
                                      cpo_ant="instituicao";      
                                }
                                //  Verificando se tem proximo campo ou chegou no Final
                                if ( prox_cpo.length>0 ) {
                                   //  Ativando a tag td com o campo
                                   var id_cpo = "td_"+prox_cpo;
                                   document.getElementById("tab_de_bens").innerHTML= "";
                                   var lsinstituicao = m_dados_recebidos.search(/Institui??o/i);  
                                   var pos = m_dados_recebidos.search(/Nenhum|Erro/i);  
                                   if( pos != -1 )  {
                                      if( lsinstituicao  == -1 )  {
                                            limpar_campos(new_elements);
                                           /// Voltar para o inicio da tag Select
                                           document.getElementById('instituicao').options[0].selected=true;
                                           document.getElementById('instituicao').options[0].selectedIndex=0;
                                           document.getElementById(id_cpo).style.display="none";
                                           mensg_erro(m_dados_recebidos,"label_msg_erro");
                                           ///  Erro limpar font ID = tab_de_bens  - display: none
                                           if( document.getElementById('tab_de_bens') ) {
                                              document.getElementById('tab_de_bens').style.display="none";  
                                           } 
                                           document.getElementById('instituicao').focus();
                                      }  
                                   } else if( pos == -1 ) {
                                        if( n_sel_opc<=m_array_length ) {
                                            /*
                                            document.getElementById(id_cpo).style.display="block";
                                            document.getElementById(id_cpo).innerHTML=m_dados_recebidos;
                                            */
                                            ///  Ativando ID id_cpo
                                            exoc(id_cpo,1,m_dados_recebidos);                   
                                            ///               
                                       }
                                   }
                              }
                         } else if( opcao=="LISTA" ) {
                               /*
                               if( document.getElementById('div_pagina') ) {
                                     document.getElementById('div_pagina').style.display="block";    
                                     document.getElementById('div_pagina').innerHTML=m_dados_recebidos;      
                               } 
                               */
                               ///  Ativando ID div_pagina
                               exoc("div_pagina",1,m_dados_recebidos);                   
                               ///               
                         } else  if( opcao=="DETALHES" ) {
                                /// Recebendo dados da Anotacao
                                var myArguments = trim(m_dados_recebidos);
                              
                 ////      alert("  anotacao_consultar.php/135  myArguments = "+myArguments)
                         
                                 /*     
                              if ( showmodal != null)  {                                                                                                                
                                   var array_modal = showmodal.split("#");
                                   if( document.getElementById('div_form')  ) {
                                         if( document.getElementById('id_body')  ) {
                                              document.getElementById('id_body').setAttribute('style','background-color: #FFFFFF');
                                         }    
                                         document.getElementById('div_form').innerHTML=showmodal;
                                   }                                                                                           
                              } 
                              */         
                                 if( window.showModalDialog) { 
                                      var showmodal =  window.showModalDialog("myArguments_anotacao.php",myArguments,"dialogWidth:760px;dialogHeight:600px;dialogTop: 50px;resizable:no;status:no;center:yes;help:no;");  
                                 } else {
                                      ///  Ativando ID anotacao_escolhida
                                      exoc("anotacao_escolhida",1,myArguments);                   
                                 }
                                 ////
                         } else if( opcao=="DESCARREGAR"  ) {
                               /// IMPORTANTE:  Abrir Arquivo PDF - Acentuacao comandos escape e decodeURIComponent - Javascript
                                 var acertaacentuacao=escape("\r\nCaso o Internet Explorer bloqueie o download, faça o seguinte:\r\n\r\n Opção - Via Ferramentas do Internet Explorer\r\n 1 - Abra o Opções do Internet Explorer e clique na aba Segurança.\r\n 2 - Clique no botão Nível Personalizado e dentro de Configurações de Segurança, localize o recurso Downloads \r\n3 - Em: Aviso automático para downloads de arquivo e selecione Habilitar");
                                alert(decodeURIComponent(acertaacentuacao));
                                srv_ret = trim(m_dados_recebidos);
                                var array_arq = srv_ret.split("%");
                                self.location.href="../includes/baixar.php?pasta="+encodeURIComponent(array_arq[0])+"&file="+encodeURIComponent(array_arq[1]);
                         } else {
                              var pos = m_dados_recebidos.search(/UPLOAD/i);
                              if( pos != -1 )  {
                                  var acertaacentuacao=escape("\r\nCaso o Internet Explorer bloqueie o download, faça o seguinte:\r\n\r\n Opção - Via Ferramentas do Internet Explorer\r\n 1 - Abra o Opções do Internet Explorer e clique na aba Segurança.\r\n 2 - Clique no botão Nível Personalizado e dentro de Configurações de Segurança, localize o recurso Downloads \r\n3 - Em: Aviso automático para downloads de arquivo e selecione Habilitar");
                                  alert(decodeURIComponent(acertaacentuacao));
                                  var  srv_ret = trim(m_dados_recebidos);
                                  var array_arq = srv_ret.split("%");
                                  self.location.href="../includes/baixar.php?pasta="+encodeURIComponent(array_arq[0])+"&file="+encodeURIComponent(array_arq[1]);
                              } else {
                                   var pos = m_dados_recebidos.search(/Nenhum|ERRO:/i);
                                   if( document.getElementById('corpo') ) document.getElementById('corpo').style.display="block";
                                   document.getElementById('label_msg_erro').style.display="none";    
                                   if( document.getElementById('resultado_anotador') ) {
                                        document.getElementById('resultado_anotador').style.display="block";    
                                        //  document.getElementById('div_form').setAttribute("style","padding-top: 2px; text-align: center;font-size: medium;");
                                       document.getElementById('resultado_anotador').innerHTML=m_dados_recebidos;      
                                   }                                  
                              }
                         }
           }; 
           /* 
              aqui ? enviado mesmo para pagina receber.php 
               usando metodo post, + as variaveis, valores e a funcao   */
  //         if( opcao=="DESCARREGAR" ) {      
    //           var poststr = "grupoproj="+encodeURIComponent(lcopcao)+"&val="+encodeURIComponent(val)+"&m_array="+encodeURIComponent(string_array); 
       
        var conectando_dados = myConn.connect(receber_dados, "POST", poststr, inclusao);   
        /*  uma coisa legal nesse script se o usuario n?o tiver suporte a JavaScript  
          porisso eu coloquei return false no form o php enviar sozinho   */
       //
       return;
}  ///  FINAL da Function enviar_dados_cad para AJAX 
///
/* ]]> */
</script>
<?php
///     Alterado em 20170925   
///   require_once("{$_SESSION["incluir_arq"]}includes/dochange.php");
require("{$_SESSION["incluir_arq"]}includes/domenu.php");

///   Consultar - Anotador
if( isset($_GET["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_GET["m_titulo"];    
} elseif( isset($_POST["m_titulo"]) ) {
   $_SESSION["m_titulo"]=$_POST["m_titulo"];      
}  
///
?>
</head>
<body  id="id_body"    oncontextmenu="return false" onselectstart="return false"  ondragstart="return false"    onkeydown="javascript: no_backspace(event);"   >
<!-- PAGINA -->
<div class="pagina_ini"  id="pagina_ini"  >
<!-- Cabecalho -->
<div id="cabecalho"  >
<?php include("{$incluir_arq}script/cabecalho_rge.php");?>
</div>
<!-- Final Cabecalho -->
<!-- MENU HORIZONTAL -->
<?php
include("{$incluir_arq}includes/menu_horizontal.php");
?>
<!-- Final do MENU  -->
<!--  Corpo -->
<div  id="corpo"  >
<!--  Mensagem de ERRO e Titulo    -->
<section class="merro_e_titulo" >
<div  id="label_msg_erro"  >
</div>
<p class='titulo_usp' >Consultar&nbsp;<?php echo ucfirst($_SESSION["m_titulo"]);?></p>
</section>
<!-- Final - Mensagem de ERRO e Titulo    -->
<?php 
////   IP do usuario conectado
if ( isset($_SERVER["REMOTE_ADDR"]) )    {
    $usuario_ip = $_SERVER["REMOTE_ADDR"];
} else if ( isset($_SERVER["HTTP_X_FORWARDED_FOR"]) )    {
    $usuario_ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else if ( isset($_SERVER["HTTP_CLIENT_IP"]) )    {
    $usuario_ip = $_SERVER["HTTP_CLIENT_IP"];
}
///  IPS permitidos  
$ips_permitidos = array("143.107.143.231","143.107.143.232","189.123.108.225",$usuario_ip);
if( ! in_array($usuario_ip, $ips_permitidos) ) {
    ?>
    <script type="text/javascript">
       /* <![CDATA[ */
       alert("P?gina em constru??o")       
      /* ]]> */
   </script>
   <?php
   echo "<p style='text-align: center; font-size: medium;' >P&aacute;gina em constru&ccedil;&atilde;o</p>";
   exit();
}
//
//     Verificano o PA - Privilegio de Acesso
//   INVES de superusuario e?  super
//  if( ( $_SESSION["permit_pa"]>$array_pa['superusuario']  and $_SESSION["permit_pa"]<=$array_pa['orientador'] ) ) {    
if( ( $_SESSION["permit_pa"]>$array_pa['super']  and $_SESSION["permit_pa"]<=$array_pa['orientador'] ) ) {  
     // Para incluir nas mensagens
    // include_once("../includes/msg_ok_erro_final.php");
     //   Definindo a variavel usuario para mensagem
    // $usuario="Orientador"; 
    //  if( $_SESSION["permit_pa"]!=$array_pa['orientador'] ) $usuario="Usu&aacute;rio"; 
     //      
?>
<div id="div_form" class="div_form" style="overflow:auto;" >
<div style="padding-top: .5em;text-align: center;background-color: #FFFFFF;" >
<p class="titulo_usp" style="text-align: center; width:100%;font-size:medium;font-weight: bold;" >Selecione o Projeto:&nbsp;
</p>
</div>
<div style="text-align: center;padding-top:0px; padding-bottom: 5px;" >
        <?php 
            $elemento=5; $elemento2=6;
           /////  include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");            
           include("php_include/ajax/includes/conectar.php");            
           $sem_projeto=utf8_decode("Esse {$_SESSION["usuario_pa_nome"]} n&atilde;o tem Projeto para adicionar Anotador.");
           ///
           $nerro=0;
           if( $_SESSION["permit_pa"]<=$array_pa['orientador']  ) {
                 $sqlcmd = "SELECT a.codigousp,a.nome,b.cip,b.fonterec,b.fonteprojid,b.numprojeto,b.titulo, "
                      ." b.anotacao FROM $bd_1.pessoa a, $bd_2.projeto b  where a.codigousp=b.autor and "
                      ." b.autor=".$usuario_conectado." order by b.titulo "; 
                 $result_projeto = mysql_query($sqlcmd);               
           }  else {
                ///  die('Esse Usu&aacute;rio n?o tem Projeto');                 
                /*  $msg_erro .=$sem_projeto.$msg_final;
                echo   $msg_erro; */
                ////  echo $funcoes->mostra_msg_erro($sem_projeto);
                $msg_erro .=$sem_projeto.$msg_final;  
                echo $msg_erro;               
                $nerro=1;     
           }
           //                  
           if( ! $result_projeto ) {
                /*  $msg_erro .="Selecionando os projetos autorizados para esse {$_SESSION["usuario_pa_nome"]}. db/mysql:&nbsp; ";
                echo   $msg_erro.mysql_error().$msg_final;  */
                 ///  Parte do Class                
                 echo $funcoes->mostra_msg_erro("Selecionando os Projetos autorizados para esse {$_SESSION["usuario_pa_nome"]}. db/mysql:&nbsp; ".mysql_error());
                 $nerro=1;     
           }
           $n_projetos=mysql_num_rows($result_projeto);
           if( intval($n_projetos)<1 ) {
                /*  $msg_erro .=$sem_projeto.$msg_final;
                echo   $msg_erro; */
                ///  Parte da Class        
                /////  echo $funcoes->mostra_msg_erro($sem_projeto);
                $msg_erro .=$sem_projeto.$msg_final;  
                echo $msg_erro;               
                $nerro=1;     
           }
           /// Verifica se NAO teve Erro
           if( intval($nerro)<1 ) {
                 ///
                  while( $linha=mysql_fetch_assoc($result_projeto) ) {
                        $arr_cnc["fonterec"][]=htmlentities($linha['fonterec']);
                        $arr_cnc["fonteprojid"][]=  ucfirst(htmlentities($linha['fonteprojid']));
                        $arr_cnc["titulo"][]=$linha['titulo'];
                        $arr_cnc["cip"][]=$linha['cip'];
                        $arr_cnc["autor_nome"][]=$linha['nome'];
                        $arr_cnc["anotacao"][]=$linha['anotacao'];
                        ///  $arr_cnc["anotacao"][]=$linha['anotacao']+1;
                   }
                   $count_arr_cnc = count($arr_cnc["fonterec"])-1;
                    //  Identifica??o da Fonte de Recurso
                   $m_linhas = mysql_num_rows($result_projeto);
                   ///
                   ?>
                   <select  name="projeto"  id="projeto"  title="Identifica&ccedil;&atilde;o do Projeto"  onchange="javascript:  enviando_dados('projeto',this.id,this.value)"    >                   
                   <?php
                       ///  Verificando registro
                       if( intval($m_linhas)<1 ) {
                            $autor="== Nenhum encontrado ==";
                       } else {
                           ?>
                            <option value="" >Selecione o Projeto que corresponde ao Anotador&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
                            <?php
                                for( $jk=0; $jk<=$count_arr_cnc; $jk++ ) {                       
                                    $_SESSION["cip"]=$arr_cnc["cip"][$jk];
                                    $_SESSION["anotacao_numero"]=$arr_cnc["anotacao"][$jk];
                                    $autor_nome = $arr_cnc['autor_nome'][$jk];
                                    $fonterec=$arr_cnc['fonterec'][$jk];  
                                    $fonteprojid=$arr_cnc['fonteprojid'][$jk];         
                                    /*  Desativado por nao ter valores nos campos fonterec e fonteprojid     
                                    $titulo_projeto = $arr_cnc['fonterec'][$jk]."/".$arr_cnc['fonteprojid'][$jk]
                                        .": ".$arr_cnc['titulo'][$jk];
                                    */    
                                    ///  Definindo Titulo do Projeto - 20171024
                                    $titulo_projeto="";
                                    if( strlen(trim($fonterec))>=1  ) {
                                        $titulo_projeto.= $fonterec."/";
                                    }
                                    if( strlen(trim($fonteprojid))>=1  ) {
                                        $titulo_projeto.= $fonteprojid.": ";
                                    }
                                    ///
                                    ///  $titulo_projeto .= $titulo;
                                    $titulo_projeto0 = $arr_cnc['titulo'][$jk];    
                                    $titulo_projeto .= trim($titulo_projeto0);
                                    $lccip=$arr_cnc['cip'][$jk];    
                                    //// Puts a space here - Coloca um espaco aqui 
                                    echo "<option  value='$lccip' title='Orientador do Projeto: $autor_nome'   >";
                                    ///
                                    $codigo_caracter=mb_detect_encoding($titulo_projeto);
                                    if( trim(strtoupper($codigo_caracter))!="UTF8" ) {
                                         echo htmlentities($titulo_projeto)."&nbsp;&nbsp;</option>";
                                         ////
                                    } else {
                                         echo  $titulo_projeto."&nbsp;&nbsp;</option>";                                  
                                    }
                                    ////    
                                }
                           ?>
                           </select>
                          <?php 
                       }
                       ///
           }
           ///
           ?>  
           <!-- Final da Num_USP/Nome Responsavel  -->     
         <span  id="resultado_anotador" style="margin-top: 0px;  top: 0px;  display:none; width: 100%; text-align: center; overflow:hidden;" ></span>            
</div>
<div  style="position:relative;  display:flex; ">
<!-- id div_out  -->
<section style="float: left;width:100%;" >
<article id="div_out"  class="div_out"  style="width:100%; overflow: auto;">
</article>
<!-- Final - id div_out  -->
<!--  ID - Anotacao escolhida -->
<article  id="anotacao_escolhida" >
</article>
</section>
<!-- Final - Anotacao escolhida -->
</div>
</div>
<?php
} else {
   echo  "<p  class='titulo_usp' >Usu&aacute;rio n&atilde;o autorizado</p>";
}
?>
</div>
 <!-- Final Corpo -->
 <!-- Rodape -->
<div id="rodape"  >
<?php include_once("{$_SESSION["incluir_arq"]}includes/rodape_index.php"); ?>
</div>
<!-- Final do  Rodape -->
</div>
<!-- Final da PAGINA -->
</body>
</html>