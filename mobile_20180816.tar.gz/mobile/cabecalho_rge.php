<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Lang" content="en">
<meta name="author" content="">
<meta http-equiv="Reply-to" content="@.com">
<meta name="generator" content="PhpED 6.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="creation-date" content="06/01/2011">
<meta name="revisit-after" content="15 days">
<title>Untitled</title>
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>
<TABLE cellSpacing=0 cellPadding=0 border=0>
  <TR>
        <TD colSpan=2> <a href="index.php"><IMG src="imagens/topo_rge.jpg" width=780 height=80 border="0"></a></TD>
      </TR>
  <TR>
    <TD  width="780"  background="imagens/b1.gif"  height=19 style="font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#FFF;">T�tulo da p�gina  - <?php echo date('Y');  ?></TD>
    </TR>
</TABLE> 
</body>
</html>

