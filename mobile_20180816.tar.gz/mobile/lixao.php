<!DOCTYPE html >
<html lang="pt-br" >
<head>
 <title>width e height</title>
<meta charset="utf-8" >
<meta name="author" content="SPFB&LAFB" /> 
<style type="text/css">
<!--
.idd {
  width: 100%;
  height: 100px;
  background-color: #a7fea8;
  text-align: center;
 }
-->
</style>
<script type="text/javascript">
//  Alinhar Texto - como o TRIM do php
//  Removendo os espacos antes e depois
function xtrim(str) { return str.replace(/^\s+|\s+$/g,""); }
///
//********************************************************************************
//
//  Alinhar Texto - como o TRIM do php
//  Removendo os espacos antes e depois 
//  Alterado para o HTML5  aceitar
function ytrim(str) { 
     var texto = str.replace(/^\s+|\s+$/g,""); 
     var i=9999;
     var resultado = "";
     var x = texto.indexOf("  ");
     if( x!=-1 ) {
         while( i>0 ) {
              texto = texto.replace("  "," "); 
              var n = texto.indexOf("  ");
              /// 
              if( n==-1) {
                  break;
              } else {
                  resultado = texto;              
              }
              i--;
         } 
         return resultado; 
     }
     return texto;
}
////***************************************************
m_dados_recebidos="salçdkjdfas asdlçkjfdas falta_arquivo_pdf.1&";
var pos=m_dados_recebidos.search(/falta_arquivo_pdf/i);
alert(" pos = "+pos);


//**********************************************************
var texto="   Digtado  -   agora     ";
var nlength = texto.length;
document.writeln("texto: "+texto+" - tamano="+nlength);
var texto1=xtrim(texto);

alert("texto1:"+texto1+" - tamanho: "+texto1.length)
//
var texto2=ytrim(texto);
alert("texto1:"+texto2+" - tamanho: "+texto2.length)
document.getElementById("b").innerHTML=texto2+" - tamanho=".texto2.length;

///  Verificando a Data 
function validatedate(inputText) {
        var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;  
        /// Match the date format through regular expression  
        /// Combine o formato da data com a expressão regular
        
   alert("Passou validatedate --  dateformat = "+dateformat);
        
        if( inputText.value.match(dateformat) ) {  
              ///   document.form1.text1.focus();  
              ///  Test which seperator is used  '/' or '-'  
              ///  Testa qual seperator é usado   '/' ou '-'  
              var opera1 = inputText.value.split('/');  
              var opera2 = inputText.value.split('-');  
              lopera1 = opera1.length;  
              lopera2 = opera2.length;  
              ///  Extract the string into month, date and year  
              ///   Extrair a cadeia em mês, data e ano
              if( lopera1>1 )  {  
                   var pdate = inputText.value.split('/');  
              }  else if (lopera2>1) {  
                   var pdate = inputText.value.split('-');  
              }  
              var mm  = parseInt(pdate[0]);  
              var dd = parseInt(pdate[1]);  
              var yy = parseInt(pdate[2]);  
              //// Create list of days of a month [assume there is no leap year by default]  
              ///  Criar lista de dias de um mês [assumir que não há ano bissexto por padrão]
              var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];  
              if( mm==1 || mm>2 ) {  
                  if( dd>ListofDays[mm-1 ]) {  
                        alert('Data formato inválido!');  
                        return false;  
                  }  
              }  
              if( mm==2 ) {  
                    var lyear = false;  
                    if( ( !(yy % 4) && yy % 100) || !(yy % 400) ) {  
                        lyear = true;  
                    }  
                    if(( lyear==false) && (dd>=29) ) {  
                        alert('Data formato inválido!');  
                        return false;  
                    }  
                    if(( lyear==true) && (dd>29) ) {  
                        alert('Data formato inválido!');  
                        return false;  
                    }  
              }  
        } else {  
            alert("Data formato inválido!");  
            ////  document.form1.text1.focus();  
            return false;  
        }  
} 
///  Final verficando a data
////
///  Verifica a data 
function verificadata(nome_id) {
   var isvalid = document.getElementById(nome_id).checkValidity();
   
   alert(" data = "+isvalid);
   if( ! isvalid ) {
        document.writeln("INVALIDO");
   }  else {
       var valor=document.getElementById(nome_id).value;
       var variavel_len=valor.length;
       ////  document.writeln("OK --  INVALIDO  -  variavel_len = "+variavel_len+"  data = "+valor); 
       var texto="OK --  INVALIDO  -  variavel_len = "+variavel_len+"  data = "+valor; 
       if( parseInt(variavel_len)>10  ) {
            var teste=" -> ERRO";
            var texto="OK --  INVALIDO  -  variavel_len = "+variavel_len+"  data = "+valor+teste; 
       }
       document.getElementById("mostrar").innerHTML=texto;
   }
   
       
}
///
</script>
</head>
<body>

<p>Click the button to alert the string with removed whitespace.</p>

<button onclick="myFunction()">Try it</button>

<div id="mostra1" style="padding-top:.5em;" ></div>
<div id="mostra2" style="padding-top:.5em;" ></div>

<p><strong>Note:</strong> The trim() method is not supported in Internet Explorer 8 and earlier versions.</p>

<script>
function myFunction() {
    var str = "       Hello      World!       ";
    //// document.writeln("Antes - str len = "+str.length);
    var strtrim=str.trim();    
    alert(strtrim);
    document.getElementById("mostra1").innerHTML=str+" - "+str.length;   
    var strtrim = strtrim.replace(/^\s+|\s+$/gm,"");    
    var strtrim = strtrim.replace(/\s*,\s*/g,""); 
    var strtrim = strtrim.replace(/^\s+|\s{2,9}|\s+$/gm,",");    
    document.getElementById("mostra2").innerHTML=strtrim+" - "+strtrim.length;
     
}
if (!String.prototype.trim) {
  String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  };
}
</script>

 <div class="idd">Web site: http://simplificandoaweb.com</div>

Texto xtrim:&nbsp;<div  id="a" ></div> 
Texto ytrim:&nbsp;<div  id="b" ></div>

<!-- Data inicio do Projeto -->

<form>
                                <label for="datainicio"  title="Data de Início do Projeto" >Data in&iacute;cio:&nbsp;</label>
<input type="date" name="datainicio"   id="datainicio" maxlength="10" pattern="[0-9]{2}\/[0-9]{2}\/[0-9]{4}$"
                                     title="Digitar Data in&iacute;cio - exemplo: 01/01/1998" oninvalid="setCustomValidity('Date Invalid ')" 
                                    required="required"   onchange="try{setCustomValidity('')}catch(e){}" />
<br/>
<label for="datefim" >Date:&nbsp;</label>
<input type="date" name="datefim" id="datefim" onblur="javascript: validatedate(this.value);"  />                                    
                                   <!-- Final - Data inicio do Projeto -->
<br/>
<br/>
<input type="date" name="dtf" id="dtf" value="DD/MM/YYYY"    />                                                               
<br/>                                   
<br/>
<input type="button" onclick="verificadata('dtf');" >        
 </form>
<div id="mostrar" style="padding-top: 6px;position:relative;" ></div>
<br/>
<select   title="Ordernar"  id="ordenar"   style="display: block; font-size:medium;" 
  onchange="javascript:  consulta_mostraproj('ordenar',todos.value,this.value)"  >
<option  value=""  >ordenar por</option>
<option  value="cip asc"  >cip - asc</option>
<option  value="cip desc"  >cip - desc</option>
<option  value="datainicio asc"  >Data in&iacute;cio - asc</option>
<option  value="datainicio desc"  >Data <?php echo utf8_decode("início"); ?> - desc</option>
<option  value="titulo asc"  >T&iacute;tulo - asc</option>
<option  value="titulo desc"  >T&iacute;tulo - desc</option>
</select>
  <p style="font-weight: bold;text-align: center;font-size: larger;"  >FINAL AQUI</p>
  <?php
     $hash = crypt('79a809e6567dfc44');
     $password=$_POST['password']='paulo!(""';
     
     $hashed_password = hash('sha512', $_POST['password']);
     $encrypt_pass= md5($password);
      echo   "$encrypt_pass  --->>>  \$hash = $hash --- <br/> \$hashed_password = $hashed_password  <br/>";
      
      /// $letras = array("a", "b", "c");
      $letras = array("a");
      $nstring=implode(",",$letras);
      echo "<br/>\$nstring = $nstring  <br/>";
      
      $outro=print_r($letras);
      echo "<br/> \$outro = $outro  ";
      //////////
  ?>
 </body>
</html>