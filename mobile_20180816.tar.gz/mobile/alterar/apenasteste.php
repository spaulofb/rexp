<?php
//  AJAX da opcao Alterar  - Servidor PHP para mostrar Anotacoes do PROJETO
//
//  LAFB&SPFB110908.1151
#
ob_start(); /* Evitando warning */
//
$y=5;
for( $x=1;$x<=$y;$x++) {
    if( (intval($x)%2)==0  ) {
        echo "<b>$x</b> resto zero <br/>";
    }  else {
        print "$x resto NAO E zero <br/>";
    }
}


#
ob_end_flush(); 
#
?>