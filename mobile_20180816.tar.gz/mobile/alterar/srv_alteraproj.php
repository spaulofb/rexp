<?php
//  AJAX da opcao Alterar  - Servidor PHP para ALTERAR PROJETO
//
//  LAFB&SPFB110908.1151
#
ob_start(); /* Evitando warning */
//
//  Verificando se session_start - ativado ou desativado
if(!isset($_SESSION)) {
   session_start();
}
// set IE read from page only not read from cache
//  header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control","no-store, no-cache, must-revalidate");
header("Cache-Control","post-check=0, pre-check=0");
header("Pragma", "no-cache");

//  header("content-type: application/x-javascript; charset=tis-620");
//  header("content-type: application/x-javascript; charset=iso-8859-1");
header("Content-Type: text/html; charset=ISO-8859-1",true);
//  Melhor setlocale para acentuacao - strtoupper, strtolower, etc...
setlocale(LC_ALL, "pt_BR", "pt_BR.iso-8859-1", "pt_BR.utf-8");

//
// extract: Importa vari�veis para a tabela de s�mbolos a partir de um array 
extract($_POST, EXTR_OVERWRITE);  

if( isset($_POST['grupoproj']) ) $opcao=$_POST['grupoproj'];
if( isset($_SESSION["usuario_conectado"]) )  $orientador=$_SESSION["usuario_conectado"];
/*  Desativado em 20120803
$msg_erro = "<span class='texto_normal' style='color: #000; text-align: center; ' >";
$msg_erro .= "ERRO:&nbsp;<span style='color: #FF0000; text-align: center; ' >";

$msg_ok = "<span class='texto_normal' style='color: #000; text-align: center;' >";
$msg_ok .= "<span style='color: #FF0000; padding: 4px;' >";
$msg_final="</span></span>";
*/

$elemento=5; $elemento2=6;
include("/var/www/cgi-bin/php_include/ajax/includes/conectar.php");     
require_once('/var/www/cgi-bin/php_include/ajax/includes/tabela_pa.php');
if( isset($_SESSION["array_pa"]) ) $array_pa=$_SESSION["array_pa"];        
//
//  INCLUINDO CLASS - 
require_once('../includes/autoload_class.php');  
$funcoes=new funcoes();
// $funcoes->usuario_pa_nome();
// $_SESSION["usuario_pa_nome"]=$funcoes->usuario_pa_nome;
//
// Para incluir nas mensagens
//  include_once("../includes/msg_ok_erro_final.php");
//   Definindo a variavel usuario para mensagem
// $usuario="Orientador"; 
// if( $_SESSION["permit_pa"]!=$array_pa['orientador'] ) $usuario="Usu&aacute;rio"; 
 //      
$opcao_maiusc = strtoupper(trim($opcao));

//  UPLOAD -  do Servidor para maquina local
if( $opcao_maiusc=="DESCARREGAR" )  {
    // Define o tempo m�ximo de execu��o em 0 para as conex�es lentas
    set_time_limit(0);
    $post_array = array("grupoproj","val","m_array");
    for( $i=0; $i<count($post_array); $i++ ) {
        $xyz = $post_array[$i];
        //  Verificar strings com simbolos: # ou ,   para transformar em array PHP
        $xyz=="m_array" ? $div_array_por = "#" : $div_array_por = ",";
        if ( isset($_POST[$xyz]) ) {
            $pos1 = stripos(trim($_POST[$xyz]),$div_array_por);
            if ( $pos1 === false ) {
                //  $$xyz=trim($_POST[$xyz]);
                //   Para acertar a acentuacao - utf8_encode
                $$xyz = utf8_decode(trim($_POST[$xyz])); 
            } else  $$xyz = explode($div_array_por,$_POST[$xyz]);
        }
    }    
    // $pasta = "/var/www/html/rexp3/doctos_img/A".$m_array[0];
    $pasta = "../doctos_img/A".$m_array[0];
    $pasta .= "/".$m_array[1]."/";     
    //  $output = shell_exec('for arq in `ls '.$pasta.'/*.*`; do mv $arq `echo $arq | tr  [:upper:] [:lower:] `; done');    
    $host  = "http://".$_SERVER['HTTP_HOST']; 
    /*
    echo "ERRO: \$host  = $host  -- \$pasta = $pasta --  ";
    exit();
      */
    $arquivo = trim($val);
    if( ! file_exists("{$pasta}".$arquivo) ) {
         $msg_erro .= "&nbsp;Esse Arquivo: ".$arquivo."  n&atilde;o tem no Servidor".$msg_final;
         echo $msg_erro;  
         
         
    }  else   echo $pasta."%".$arquivo;
    exit();     
}
//  Mostrar todas as anotacoes de um Projeto
if( $opcao_maiusc=="TODOS" or $opcao_maiusc=="BUSCA_PROJ" ) {
        $_SESSION["selecionados"]="";
        //  Selecionar os Projetos de acordo com o op��o
        $sqlcmd = "SELECT a.numprojeto, a.titulo, a.objetivo, a.fonterec, a.fonteprojid, "
                 ."a.autor as autor_codigousp, b.nome as autor_nome, a.cip as Detalhes,  a.coresponsaveis, "
                 ."concat(substr(a.datainicio,9,2),'/',substr(a.datainicio,6,2),'/',substr(a.datainicio,1,4)) as datainicio, "    
                 ."concat(substr(a.datafinal,9,2),'/',substr(a.datafinal,6,2),'/',substr(a.datafinal,1,4)) as datafinal, "             
                 ." a.relatproj as Arquivo FROM $bd_2.projeto a, $bd_1.pessoa b  "
                 ." WHERE a.autor=b.codigousp   ";
        // 
        switch ($opcao) {
           case "TODOS":
               if( $_SESSION["permit_pa"]==$array_pa['orientador'] )  {
                    $where_cond = " and  a.autor=$orientador ";    
               }
               $where_cond .= "";
               break;
           case "BUSCA_PROJ":
              //  $where_cond .= " and  cip=$val ";
              $where_cond .= " and  cip=$cip ";
              break;    
           default:
              $where_cond .= "";
        }
        $sqlcmd .= $where_cond." order by a.cip desc";
        //
        $result_consult_projeto = mysql_query($sqlcmd);
        if( ! $result_consult_projeto ) {
                $msg_erro .= "Falha consultando a tabela anota&ccedil;&atilde;o  - op&ccedil;&atilde;o=".$opcao.' - '.mysql_error().$msg_final;  
                echo $msg_erro;                
                exit();
        }       
        $n_regs=mysql_num_rows($result_consult_projeto);
        // Caso encontador o Projeto
        if( $n_regs==1 ) {
               //  Definindo os nomes dos campos recebidos do MYSQL SELECT
               if( isset($array_nome) ) unset($array_nome);
               $array_nome=mysql_fetch_array($result_consult_projeto);
               foreach( $array_nome as $chave_cpo => $valor_cpo ) {
                      $$chave_cpo=$valor_cpo;
               }
               //   CIP - Codigo de Informacao do Projeto
               if( isset($cip) ) {
                    if( strlen(trim($cip))>0 ) {
                          $_POST["cip"]=$cip;    
                          $_SESSION["cip"]=$cip;    
                    }
               }  
               ////  Definindo as sessoes que serao usadas no projeto_alter.php 
               //       na parte do relatorio/arquivo
               $_SESSION["autor_cod"]=$autor_codigousp;
               $_SESSION["nprojexp"]=$numprojeto;
               //                                    
        } else {
            $msg_erro .= "Projeto n&atilde;o encontrado.".$msg_final;  
            echo $msg_erro;
            exit();        
        }
        mysql_free_result($result_consult_projeto); 
        $total_cols=4;
       ?>
      <form name="form_alterar_projeto" id="form_alterar_projeto" enctype="multipart/form-data"   method="post" style="padding: 0px; top: 0px; " >
        <table class="table_inicio" cols="<?php echo $total_cols;?>"  align="center" cellpadding="2"  cellspacing="2" style="font-weight:normal;color: #000000;   "  >
          <tr style="text-align: left;overflow: hidden;"  >
             <td  class="td_inicio1" colspan="<?php echo $total_cols;?>" style="vertical-align: middle;text-align: left;"  >
                <label   title="Orientador do Projeto"   >Orientador:&nbsp;</label>
                <!-- N. Funcional USP - Autor/Orientador -->
                <span class='td_inicio1' style="border:none; background-color:#FFFFFF; color:#000000;" title='Nome do Autor Respons�vel do Projeto' >&nbsp;<?php echo $autor_nome;?>&nbsp;</span>
                <span  class="td_inicio1" style="vertical-align: middle;text-align: left;"   >
                   <label   >Nr. do Projeto:&nbsp;</label>
                      <span class='td_inicio1' style="border:none; background-color:#FFFFFF; color:#000000;" title='N&uacute;mero do Projeto' >&nbsp;<?php echo $numprojeto;?>&nbsp;</span>
                      </span>
              </td>
             </tr>
             <tr style="text-align: left;"  >
               <!--  Titulo do Projeto  -->
                 <td  class="td_inicio1" colspan="<?php echo $total_cols;?>"  style="text-align: left;vertical-align: top;   background-color: #32CD99; " >
                      <label for="titulo"  style="vertical-align: top; color:#000000; background-color: #32CD99; cursor:pointer;" title="T�tulo do Projeto"   ><span class="asteristico" >*</span>&nbsp;T&iacute;tulo:&nbsp;</label>
                       <textarea rows="3" cols="85" name="titulo" id="titulo"  onKeyPress="javascript:limita_textarea('titulo');" title='Digitar T&iacute;tulo do Projeto' style="cursor: pointer; overflow:auto;"  onblur="javascript: alinhar_texto(this.id,this.value);"  ><?php echo nl2br($titulo);?></textarea>      
                 </td>
              <!-- Final -  Titulo do Projeto  -->                 
            </tr>
            <tr style="text-align: left;"  >
               <!--  Objetivo  -->
               <td  class="td_inicio1" style="vertical-align: middle; text-align: left;"  colspan="<?php echo $total_cols;?>"  >
                  <label for="objetivo"  style=" cursor:pointer;" title="Objetivo do Projeto"   ><span class="asteristico" >*</span>&nbsp;Objetivo:&nbsp;</label>
                 <?php 
                    // Objetivo
                    $sqlcmd  = "SELECT  codigo,descricao from $bd_2.objetivo  order by codigo "; 
                    $result_objetivo = mysql_query($sqlcmd);
                    if( ! $result_objetivo ) {
                        $msg_erro .= "Falha consultando a tabela objetivo  - db/mysql: ".mysql_error().$msg_final;  
                        echo $msg_erro;
                        exit();
                    }        
                  ?>
                    <!-- Objetivo  -->
                    <select name="objetivo" id="objetivo" class="td_select"  title="Selecionar Objetivo"   >                   
                      <?php
                        $m_linhas = mysql_num_rows($result_objetivo);
                        while($linha=mysql_fetch_array($result_objetivo)) {       
                              $codigo_objetivo = $linha['codigo'];
                              $objetivo_selected = "";                      
                              if ( $codigo_objetivo==$objetivo ) $objetivo_selected = "selected='selected'";
                              echo "<option $objetivo_selected  value=".htmlentities($linha['codigo'])." >"
                                   .ucfirst(htmlentities($linha['descricao']))."&nbsp;</option>" ;
                        }
                        ?>
                         </select>
                    </td>
                    <!--  Final - Objetivo  -->
                </tr>
                <tr  style="text-align: left;"   >
                    <!--  Fonte de Recurso -->
                    <td  class="detalhes1" style="text-align: left; vertical-align: middle; "   colspan="<?php echo $total_cols;?>"  >
                        <label for="fonterec" style="vertical-align: middle; cursor: pointer;" title="Fonte Principal de Recursos (Pr&oacute;prio, FAPESP, CNPQ, etc)"   >Fonte Principal de Recursos:&nbsp;</label>
                        <input type="text" name="fonterec" value="<?php echo $fonterec;?>"   id="fonterec"   size="30" maxlength="16" title='Digitar Fonte Principal de Recursos (Pr&oacute;prio, FAPESP, CNPQ, etc)' onblur="javascript: alinhar_texto(this.id,this.value); soLetrasMA(this.id)"  style="cursor: pointer;"  />
                    </td>
                    <!-- Final - Fonte de Recurso -->
                </tr>
                <tr  style="text-align: left;" >
                  <!-- fonteprojid - Nr. do Processo  -->
                    <td  class="detalhes1"  style="text-align: left; vertical-align: middle; "   colspan="<?php echo $total_cols;?>"  >
                        <label for="fonteprojid" style="vertical-align: middle; cursor: pointer;" title="Nr. Processo"  >Nr. Processo:&nbsp;</label>
                        <input type="text" name="fonteprojid"   id="fonteprojid"  value="<?php echo $fonteprojid;?>"    size="36" maxlength="24" title='Digitar Nr. Processo'  style="cursor: pointer;"   onblur="javascript: alinhar_texto(this.id,this.value)"   />
                    </td>
                   <!-- Final - fonteprojid -->
                </tr>



                <tr  style="text-align: left;" >
                  <!-- Data inicio do Projeto -->
                  <td  class="detalhes1"   style="text-align: left; vertical-align: middle; "   colspan="<?php echo $total_cols;?>"  >
                        <label for="datainicio" style="vertical-align: middle; cursor: pointer;" title="Data de In�cio do Projeto"   >Data in&iacute;cio:&nbsp;</label>
                        <input type="text" name="datainicio"   id="datainicio"  value="<?php echo $datainicio;?>"  size="12" maxlength="10" title="Digitar Data in&iacute;cio - exemplo: 01/01/1998"   style="cursor: pointer;"   onkeyup="formata(this,event);"  onkeydown="javascript: backspace(event,this)"   />
                  <!-- Final - Data inicio do Projeto -->
                  <!-- Data Final do Projeto -->
                        <label for="datafinal" style="vertical-align: middle; cursor: pointer;" title="Data Final do Projeto"   >Data final:&nbsp;</label>
                        <input type="text" name="datafinal"   id="datafinal"  value="<?php echo $datafinal;?>"  size="12" maxlength="10" title="Digitar Data Final - exemplo: 01/01/1998"  style="cursor: pointer;"    onkeyup="formata(this,event);"  onkeydown="javascript: backspace(event,this)"   onblur="javascript: verificadatas('datainicio','datafinal',document.getElementById('datainicio').value,document.getElementById('datafinal').value)"   />
                  </td>
                  <!-- Final - Data Final do Projeto -->
                </tr>

                
                <tr  style="text-align: left;"  >
                   <!-- Numero de Coautores -->
                   <td  class="detalhes1"  style="text-align: left; vertical-align: middle; "   colspan="<?php echo $total_cols;?>"  >
                       <label for="coresponsaveis" >N&uacute;mero de Co-Respons&aacute;veis:&nbsp;</label>
                       <input type="text" name="coresponsaveis" id="coresponsaveis" value="<?php echo $coresponsaveis;?>" size="5"   maxlength="3" title='Digitar  N&uacute;mero de Co-Respons&aacute;veis'  style="cursor: pointer;"
                          onKeyup="javascript: n_coresponsaveis(this,event); " value=""   onblur="javascript: if( this.value<1 ) exoc('incluindo_coresponsaveis',0);"   />&nbsp;
                       <input  type="button"    onclick="javascript: enviar_dados_cad('coresponsaveis');"  id="busca_coresponsaveis" 
                            title='Clicar'  style="cursor: pointer; width: 110px;"  value="Indicar" 
                              class="botao3d"   >
                    </td>
                    <!-- Final - Numero de Coautores -->                    
                </tr>

                <!-- Inclusao de Coautores - caso tenha no Projeto - fica Oculto sem Coresponsaveis -->
                <tr align="center" >
                    <td align="center"  colspan="<?php echo $total_cols;?>"  >
                        <div id="incluindo_coresponsaveis" align="center"  ></div>
                    </td>
                </tr>
                <!-- Final - Nomes dos Coautores -->
                
               
  <tr  style="text-align: left;"  >
   <!-- Nome dos Coautores  -->
   <td  colspan="<?php echo $total_cols;?>"  >
    <table class="table_inicio"  align="center" width="100"  cellpadding="1" border="2" cellspacing="1" style="background-color: #A8A8A8; font-weight:normal; text-align: center; margin: 0px; padding: 0px;vertical-align: middle; "  >      
     <?php 
       //  Caso de Coresponsaveis maior que Zero
       if( $coresponsaveis>0  ) {
           // Nomes dos Coresponsaveis na Tabela CORESPPROJ 
           if( isset($sqlcmd) ) unset($sqlcmd);
           $sqlcmd = "SELECT a.nome as nome_coresponsavel FROM $bd_1.pessoa a, $bd_2.corespproj b  WHERE  "
                       ." a.codigousp=b.coresponsavel  and b.projetoautor=$autor_codigousp and  b.projnum=$numprojeto ";
           //
           $result_corespproj=mysql_query($sqlcmd);
           if( ! $result_corespproj ) {
                $msg_erro .= "Falha consultando as tabelas pessoa e corespproj  - db/mysql: ".mysql_error().$msg_final;  
                echo $msg_erro;
                exit();
           } 
           $val= (int) $coresponsaveis;
           //  Caso variavel val ser imprar entao colspan=1                   
           $impar_ou_par=(int) $val%2;
           $m_co = "Co-resp.";
           if( $source_upper=="COLABS" )    $m_co = "Colab.";
           $x_float2 = (float) (.5);  $acrescentou=0;
           $n_tr = (float) ($val/2);
           if(  ! is_int($n_tr) ) {
              $n_tr=$n_tr+$x_float2;
              $acrescentou=1;
           }
           //  $n_y=0;$texto=0; $n_tr= (int) $val;
           $n_y=0;$texto=0; $n_tr= (int) $n_tr;
           for( $x=1; $x<=$n_tr; $x++ ) {
                echo "<tr style='margin: 0px; padding: 0px;vertical-align: middle; text-align: left;' >";
                $n_y=$texto; $n_td=4;
                $n_tot=$n_td/2;
               for( $y=1; $y<=$n_tot ; $y++ ) {
                   $texto=$n_y+$y; $colspan=2;
                   //  Caso variavel val ser imprar entao colspan=1                   
                   if( $y>=$val and $impar_ou_par==1 ) $colspan=1;
                   if( ( $acrescentou==1 ) and  ( $texto>$val ) ) {                         
                         continue;
                   } else  {
                         echo  "<td class='detalhes1'   colspan=$colspan  style='text-align: left; color: #000000; vertical-align: middle;' >"
                                 ."&nbsp;$m_co $texto:&nbsp;";
                   }
                   $n_tot2=1; $n_cores;
                   for( $z=1; $z<=$n_tot2 ; $z++ ) {                         
                        ?>                       
                        <!-- N. Funcional USP - COautor ou Colaborador  -->
                        <span style="color: #FFFFFF;" >
                        <?php echo trim(mysql_result($result_corespproj,$n_cores,"nome_coresponsavel"));?>
                        </span>
                      </td>
                    <?php                      
                    $n_cores++;
                  } // Final do If TD  - numero USP/Coautor
               }
               echo "</tr>";
           }            
       }  //  Final do IF coresponsaveis>0  
     ?>
  </table>
  </td>
  </tr>
               <tr align="center" style="border: 2px solid #000000; vertical-align:top;  line-height:0px;" >
                 <td colspan="4" align="CENTER" nowrap style=" padding: 1px; text-align:center; border: none; line-height:0px;">
                   <table border="0" cellpadding="0" cellspacing="0" align="center" style="width: 100%; line-height: 0px; margin:0px; border: none; vertical-align: top; " >

               <tr  >
                <!-- Arquivo do Relatorio do Projeto  -->
                 <td  class="td_inicio1"  style="vertical-align: middle; " colspan="1"  >
                     <label for="fonteprojid" style="vertical-align: middle; cursor: pointer;" >Arquivo do Projeto:&nbsp;</label>
                 </td  >
                 <td class="td_inicio2"  colspan="3"  >
                      <span style='background-color: #FFFFFF; color: #000000; padding: 2px; font-weight: bold; border: 2px solid #000000; ' >
                         <?php  echo  $arquivado_como;?>
                     </span>           
                 </td>
                   <!-- Final - arquivo relatorio do projeto -->
               </tr>
               
               <tr  >
                <!-- Nr. de Anotacoes do Projeto  -->
                 <td  class="td_inicio1"  style="vertical-align: middle; " colspan="1"  >
                     <label for="fonteprojid" style="vertical-align: middle; cursor: pointer;" >Nr. de Anota&Ccedil;&otilde;es do Projeto:&nbsp;</label>
                 </td  >
                 <td class="td_inicio2"  colspan="3"  >
                      <span style='background-color: #FFFFFF; color: #000000;  padding: 2px; font-weight: bold;  border: 2px solid #000000' >
                         <?php  echo  $anotacao;?>
                     </span>           
                 </td>
                   <!-- Final - numero de anotacoes do projeto -->
               </tr>               
              </table>
              </td>
              </tr>
                               

              <!--  TAGS  type reset e  submit  --> 
               <tr align="center" style="border: 2px solid #000000; vertical-align:top;  line-height:0px;" >
                 <td colspan="4" align="CENTER" nowrap style=" padding: 1px; text-align:center; border: none; line-height:0px;">
                   <table border="0" cellpadding="0" cellspacing="0" align="center" style="width: 100%; line-height: 0px; margin:0px; border: none; vertical-align: top; " >
                     <tr style="border: none;">
                       <td  align="CENTER" nowrap style="text-align:center; border:none;" >
                        <button name="cancelar" id="cancelar"  type="button" onClick="javascript: altera_projeto('BUSCA_PROJ','LIMPAR');"  class="botao3d" style="cursor: pointer;  width: 120px; "  title="Cancelar"  acesskey="C"  >    
                           Cancelar&nbsp;<img src="../imagens/limpar.gif" alt="Cancelar" style="vertical-align:text-bottom;" >
                        </button>
                         <!-- Remover -->                  
                         </td>
                         <td  align="center"  style="text-align: center; border:none; ">
                            <button name="alterar" id="alterar"   type="button"  class="botao3d"  onClick="javascript: altera_projeto('ALTERAR_PROJETO','<?php echo $conjunto;?>');"  style="cursor: pointer; width: 120px; "  title="Alterar"  acesskey="A" >    
                                Alterar&nbsp;<img src="../imagens/enviar.gif" alt="Alterar"  style="vertical-align:text-bottom;"  >
                            </button>
                         </td>
                         <!-- Final -Enviar -->
                     </tr>
                     <!--  FINAL - TAGS  type reset e  submit  -->
                   </table>
                 </td>
               </tr>
       </table>
      </form>
    <?php    
   


   exit();

        
        mysql_free_result($result_consult_projeto);               
        //  Selecionando todos os registros da Tabela temporaria de consulta Anotacoes
        $query2 = "SELECT * from  ".$_SESSION['table_consultar_projeto']."  ";
        $resultado_outro = mysql_query($query2);                                    
        if( ! $resultado_outro ) {
             die("ERRO: Selecionando os Projetos - mysql =  ".$cip.mysql_error());  
             exit();
        }         
        //  Pegando os nomes dos campos do primeiro Select
        $num_fields=mysql_num_fields($resultado_outro);  //  Obt�m o n�mero de campos do resultado
      //  $projeto_titulo = mysql_result($resultado_outro,0,"Titulo");
        $td_menu = $num_fields+1;   
        //  Total de registros
        $_SESSION["total_regs"] = mysql_num_rows($resultado_outro);
        if( $_SESSION["total_regs"]<1 ) {
            $msg_erro .= "&nbsp;Nenhuma Anota&ccedil;&atilde;o para esse Projeto:&nbsp;<br>$projeto_titulo".$msg_final;
            echo $msg_erro;
            exit();
        }   
        $_SESSION['total_regs']==1 ? $lista_usuario=" <b>1</b> Projeto " : $lista_usuario="<b>".$_SESSION['total_regs']."</b> Projetos ";     
        $_SESSION["titulo"]= "<p class='titulo'  style='text-align: left; margin: 0px 0px 0px 4px; padding: 0px; '  >";
        $_SESSION["titulo"].= "Lista de $lista_usuario ".$_SESSION['selecionados']."</p>"; 
        //  Buscando a pagina para listar os registros        
        $_SESSION["num_rows"]=$_SESSION["total_regs"];  $_SESSION["name_c_id0"]="codigousp";    
        $_SESSION["ucfirst_data"]=$titulo_pag; $_SESSION["pagina"]=0;
        $_SESSION["m_function"]="consulta_projeto" ;  $_SESSION["conjunto"]="Projeto#@=".$usuario_conectado."#@=";
        $_SESSION["opcoes_lista"] = "../includes/tabela_consulta_projeto.php?pagina=";
        require_once("../includes/tabela_consulta_projeto.php");  
        if( isset($cip) ) unset($cip)                    ;
     /*
         $msg_erro .= " srv_mostraanot.php/122 -  \$resultado_outro = $resultado_outro ";
        echo  $msg_erro;
        exit();     
        */
}  elseif( $opcao_maiusc=="DETALHES" )  {
    //  MUITO IMPORTANTE PASSAR A VARIAVEL val para cip
    $cip=$val;
    //  Selecionando Projeto
     $sqlcmd .= "SELECT a.numprojeto, a.titulo as  titulo_projeto, b.nome as autor_projeto,  "
                ." concat(substr(a.datainicio,9,2),'/',substr(a.datainicio,6,2),'/',substr(a.datainicio,1,4)) as data_projeto "
                ." FROM $bd_2.projeto a, $bd_1.pessoa b WHERE a.cip=$cip and a.autor=b.codigousp  ";
     $resultado_projeto = mysql_query($sqlcmd);
     if( ! $resultado_projeto ) {
          $msg_erro .= "Selecionando Projeto  db/mysql - ".mysql_error().$msg_final;            
          echo  $msg_erro;
          exit();
     }         
     //  Definindo os nomes dos campos recebidos do MYSQL SELECT - mysql_fetch_array
     $array_nome=mysql_fetch_array($resultado_projeto);
     foreach( $array_nome as $key => $value ) {
              $$key=$value;
     }             
     mysql_free_result($resultado_projeto);     
     //  Selecionando as ANOTACOES do PROJETO        
    $sqlcmd = "SELECT  a.numero as numero_anotacao, a.titulo as titulo_anotacao,  "
                 ." concat(substr(a.data,9,2),'/',substr(a.data,6,2),'/',substr(a.data,1,4)) as data_anotacao "
                 ."  FROM $bd_2.anotacao a, $bd_1.pessoa b "
                 ." WHERE a.autor=b.codigousp and a.projeto=$cip ";                
     $resultado_anotacao = mysql_query($sqlcmd);
     if( ! $resultado_anotacao ) {
          $msg_erro .= "Selecionando Anota&ccedil;&otilde;es do Projeto: ".$numprojeto."  db/mysql - ".mysql_error().$msg_final;  
          echo $msg_erro;
          exit();
     }         
     //  Definindo os nomes dos campos recebidos do MYSQL SELECT - mysql_fetch_array
     if( isset($array_nome) ) unset($array_nome);
     $num_anotacoes = mysql_num_rows($resultado_anotacao);
     $anotacoes ="" ;
     if( $num_anotacoes>=1  ) {
         $anotacoes ="<div style='width: 100%; overflow: auto;'  >";
         /*  Mostra Anotacao por Anotacao - Desativado
          while( $reg_anot=mysql_fetch_array($resultado_anotacao) ) {
              // Anotacao do Projeto                            
              $anotacoes .="<p style='text-align:center;font-size: medium;'>"
                 ."<b>Anota&ccedil;&atilde;o</b>:&nbsp;".$reg_anot['numero_anotacao']."&nbsp;-&nbsp;"
                 ."<b>Data da Anota&ccedil;&atilde;o</b>:&nbsp;".$reg_anot['data_anotacao']."</p>";
              $anotacoes .="<div style='text-align:center;font-size: medium; overflow: auto;'>"
                 ."<b>T&iacute;tulo da Anota&ccedil;&atilde;o</b>:<br>"                
                 .$reg_anot['titulo_anotacao']."</div>";                                     
          }
          */
          $anotacoes .="<p style='text-align:center;font-size: medium;'>";
          $anotacoes .="Total de Anota&ccedil;&otilde;es desse Projeto:&nbsp;".$num_anotacoes."</p>";
          $anotacoes .="</div>" ;
     }
     mysql_free_result($resultado_projeto);
     //   Projeto
     $confirmar0 ="<p style='text-align:center;font-size: medium;'>"
                     ."<b>Projeto $numprojeto </b><br>"
                     ."<b>Autor do Projeto</b>: $autor_projeto</p>";
     $confirmar0 .="<div style='text-align:center;font-size: medium; overflow: auto;'>"
                 ."<b>T&iacute;tulo do Projeto</b>:<br>"                
                 ."$titulo_projeto </div>";
     $confirmar0 .="<p style='text-align:center;font-size: medium;'>"
                    ."<b>Data in&iacute;cio do Projeto</b>:&nbsp;$data_projeto </p>";
     $confirmar0 .=$anotacoes;                   
     $confirmar1 .=$confirmar0."<br><div style='width: 100%; text-align: center;'>";                                         
     $confirmar1 .="<button class='botao3d_menu_vert'  style='text-align:center; cursor: pointer;'  " 
                  ." onclick='javascript: limpar_form();' >Ok";                                  
     $confirmar1 .="</button></div>";                                         
     echo $confirmar1;               
}
//
ob_end_flush(); 
#
?>