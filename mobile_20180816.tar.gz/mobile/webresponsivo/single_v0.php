<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Cursos IAG</title>
<link href="estilo.css" rel="stylesheet" type="text/css">
<link href="fonts/fonts.css" rel="stylesheet" type="text/css">
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
</head>

<body>
<a name="topo">
<header id="topo">

	<span id="logo">
    	<a href="index.php"><img src="imagens/logo-cursos-iag.png"></a>
    </span>
    
    <section id="login-carrinho">
    	 <span id="login"><a href="#"><img src="imagens/login-header.png"></a></span>
        <span id="carrinho"><a href="#"><img src="imagens/checkout-header.png"></a></span>
        <span id="pesquisar">
        	<form name="form1">
           	<input type="search" name="search1"> 
           </form>
        </span>
    </section>
    
</header>

<section id="menu-container">
	<nav id="menu">
    	<ul>
        	<li><a href="categoria.php">WEB DESIGN</a></li>
           <li><a href="categoria.php">DESIGN GRÁFICO</a></li>
           <li><a href="categoria.php">ÁUDIO E VÍDEO</a></li>
           <li><a href="categoria.php">PROGRAMAÇÃO</a></li>
           <li><a href="categoria.php">3D</a></li>
           <li><a href="categoria.php">OFFICE</a></li>
           <li><a href="categoria.php">CURSOS ADOBE</a></li>
           <li><a href="categoria.php">FORMAÇÕES</a></li>
        </ul>
    </nav>
</section> 
 
<section id="single-container">
   <div id="single">
        <div id="single-header">
        	<h1>CURSO DE ADOBE EDGE ANIMATE</h1>
           <h2>Com Adriano Gianini</h2>
           
       <div id="single-header-prices">
        <span>R$ 100,00</span>
            <small>EM ATÉ 3X SEM JUROS</small>
       </div> 
	</div> 
        
    <div id="tabs-container">
    <ul id="tabs">
        <li><a href="#" name="#tab1">DESCRIÇÃO</a></li>
        <li><a href="#" name="#tab2">INFORMAÇÕES</a></li>
        <li><a href="#" name="#tab3">PÚBLICO ALVO</a></li>
        <li><a href="#" name="#tab4">PERFIL</a></li>
        <li><a href="#" name="#tab5">AULA DEMO</a></li>
    </ul>
    
    <div class="contenttab">
    <div id="tab1">
    
    O curso ensina como trabalhar com a nova ferramenta Adobe Edge Animate e a criar animações com jQuery e CSS3 sem a necessidade de ser um programador jQuery.
    
    Você aprenderá a criar animações para divulgação de produtos, menus, slideshows, sliders, galerias de fotos, sites responsivos entre várias outras situações.
    
    Além de criar tudo isso o resultado não é em FLASH o que torna toda animação criada compatível com desktops, smartphones e tablets.
    
    </div>
    <div id="tab2">
    
    Tempo de gravação dos vídeos: 6 horas e 4 minutos
    
    Tempo de acesso: 2 anos
    
    Carga horária certificado: 30 horas
    
    Certificado: Sim (PDF)
    
    Idioma do Software: Inglês
    
    Pré-requisitos: É necessário possuir conhecimentos em informática básica, internet, noções de web design e muita vontade para aprender.
    
    Possui DVD? Sim. Enviado em até 48 horas úteis após a confirmação de pagamento, exceto em promoções onde não enviamos DVD.
    
    Possui acesso online as aulas? Sim, liberado em até 24 horas (úteis)
    
    <a href="http://www.adrianogianini.com.br/site/wp-content/uploads/2013/01/conteudo_curso_edge_animate.pdf" target="_blank" data-ob="lightbox" class="pdf">Faça o download do conteúdo em PDF</a>
    
    </div>
    <div id="tab3">
    
    Esse curso é perfeito para designers que desejam migrar suas animações do Flash para CSS3 e jQuery mas não desejam se tornar programadores nem tampouco ter como resultado um SWF.
    
    </div>
    <div id="tab4">
    
    Após o curso o aluno estará apto criar animações para divulgação de produtos, menus, slideshows, sliders, galerias de fotos, sites responsivos entre várias outras situações.
    
    </div>
    <div id="tab5">
    <iframe height="487" width="100%" src="http://www.youtube.com/embed/6c6Y7jG_oq8" frameborder="0" allowfullscreen></iframe>
    </div>
    </div>
              
    </div>
    </div>
    
       
    <div id="botao-pagseguro">
        <img src="imagens/icon-shop.png">
        <div id="checkout">
            <img src="imagens/checkout.jpg">
        </div>
    </div>

 </section>

 
<footer id="rodape-container">

	<section id="rodape1">
    
    	<ul>
        	<h1>ESTUDE CONOSCO</h1>
           <li><a href="#">10 razões para estudar</a></li>
           <li><a href="#">Como funciona</a></li>
           <li><a href="#">Missão e Valores</a></li>
        </ul>
        
        <ul>
        	<h1>SOBRE <br />NÓS</h1>
           <li><a href="#">IAG, a história</a></li>
           <li><a href="#">Próximos Cursos</a></li>
           <li><a href="#">Guia de Carreiras</a></li>
           <li><a href="#">Bastidores</a></li>
           <li><a href="#">Vídeo Aulas Gratuitas</a></li>
           <li><a href="#">Agência Digital IAG</a></li>
           
        </ul>
        
        <ul>
        	<h1>NOSSOS PRODUTOS</h1>
           <li><a href="#">Cursos Online</a></li>
           <li><a href="#">Suporte</a></li>
           <li><a href="#">DVDs</a></li>
           <li><a href="#">Certificados</a></li>
           <li><a href="#">Parcerias</a></li>
        </ul>
        
        <ul>
        	<h1>SUPORTE <br />IAG</h1>
           <li><a href="#">FAQ</a></li>
           <li><a href="#">Contato</a></li>
           <li><a href="#">Atendimento Online</a></li>
           <li><a href="#">Seja um Autor</a></li>
        </ul>
        
         <ul>
        	<h1>MAIS <br />INFORMAÇÕES</h1>
           <li><a href="#">Mapa do Site</a></li>
           <li><a href="#">Termos e Condições</a></li>
        </ul>
        
        <span id="rodape-logo"><img src="imagens/footer-logo.png"></span>
        
        <a href="#topo" class="rodape-topo">IR AO TOPO</a>
                           
    </section>

    
    <section id="rodape2">
    
		<div id="rodape2-facebook">
         <ul>
        	<h1>ACOMPANHE <br />NO FACEBOOK</h1>
            
            <?php
 
				abstract class ShareNetWork{
					protected $url;
					protected $server;
			 
					public function setUrl($url){
						$this->url = $url;
					}
			 
					public function setServer($server){
						$this->server = $server;
					}
			 
					protected function accessServer($url){
						$ch = curl_init($url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						$result = curl_exec($ch);
						curl_close($ch);
						return $result;
					}
			 
					abstract protected function populate($obj);
			 
					abstract public function execute();
			 
				}
				
				class ShareFacebook extends ShareNetWork{
					private $shareCount;
					private $likeCount;
					private $clickCount;
			 
					public function __construct($url){
						$this->setUrl($url);
						$this->setServer('http://api.facebook.com/restserver.php?method=links.getStats&urls=%s');
					}
			 
					public function execute(){
						$url = sprintf($this->server, $this->url);
						$data = $this->accessServer($url);
						$obj  = simplexml_load_string($data);
						$this->populate($obj);
						return $this;
					}
			 
					protected function populate($obj){
						$this->shareCount = $obj->link_stat->share_count;
						$this->likeCount = $obj->link_stat->like_count;
						$this->clickCount = $obj->link_stat->click_count;
					}
			 
					public function getShareCount(){
						return $this->shareCount;
					}
			 
					public function getLikeCount(){
						return $this->likeCount;
					}
			 
					public function getClickCount(){
						return $this->clickCount;
					}
			 
				}
				
				 $facebook = new ShareFacebook('https://www.facebook.com/cursosiag');
   				 $facebook->execute();
				
			?>
            
            <span class="like"><div class="arrow_box"></div><strong><?php echo $facebook->getLikeCount();?></strong> CURTIRAM</span>
            
            <div id="fb-root"></div>
			<script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1&appId=291255711008650";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
            
            <div class="fb-like-box" data-href="https://www.facebook.com/cursosiag" data-width="365" data-show-faces="true" data-stream="false" data-show-border="true" data-header="true"></div>
        </ul>

        </div>
        
        <div id="rodape2-maisvistos">
        
        		<div id="sidebar-plugin">
                
                    <div class="tabs">
                    
                    <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" />
                    <label for="tab-1" class="tab-label-1">ÁREAS</label>
            
                    <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" />
                    <label for="tab-2" class="tab-label-2">MAIS VISTOS</label>
                
                    <div class="clear"></div>
                
                    <div class="content">
                    
                        <div id="content-1">
                        
                             <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            
                        </div><!-- CONTENT-1 -->
                        
                        <div id="content-2">
                            
                             <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>

                            
                        </div><!-- CONTENT-2 -->
                        
                    </div>
                        
                    </div><!-- FIM SIDEBAR-PLUGIN-TABS -->
            
            </div><!-- FIM SIDEBAR-PLUGIN --> 
        
        </div>	

    </section>
    
    <section id="rodape3-container">
    	<div id="rodape3">
        		<p>E-mail: atendimento@cursosiag.com.br TEL: (82) 3034-5153</p>
              <p>Todos os direitos reservados - 2008 - 2013 CursosIAG</p>
              <p>
              		<img src="imagens/icon-facebook.png">
                  <img src="imagens/icon-twitter.png">
                  <img src="imagens/icon-youtube.png">
              </p>
        </div>
    </section>


</footer>

<script type="text/javascript">
$(function () {
    $('.box').each(function() {
        var content = $(this).find('.content-2'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

$(document).ready(function () {
$('a[href=#topo]').click(function () {
$('html, body').animate({ scrollTop: 0 }, 'slow');
		return false;
	}); 
});

$(function () {
	
	$("#banners").responsiveSlides({
		
		auto: true,
        pager: false,
        nav: true,
        speed: 800,
        namespace: "callbacks",
        
      });

});

$(function(){
var menuTop = $('#menu-container').offset().top;
$(window).scroll(function(){
	if($(window).scrollTop() > menuTop){
		 $('#menu-container').css({position: 'fixed', top: '0px'});
	}else{
		 $('#menu-container').css({position: 'static'});
	}
})
});

$(function () {
    $('.box-2').each(function() {
        var content = $(this).find('.content-tab-footer'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

</script>


<script>

    function resetTabs(){
        $(".contenttab > div").hide(); //Hide all content
        $("#tabs a").attr("id",""); //Reset id's      
    }

    var myUrl = window.location.href; //get URL
    var myUrlTab = myUrl.substring(myUrl.indexOf("#")); // For localhost/tabs.html#tab2, myUrlTab = #tab2     
    var myUrlTabName = myUrlTab.substring(0,4); // For the above example, myUrlTabName = #tab

    (function(){
        $(".contenttab > div").fadeOut(); // Initially hide all content
        $("#tabs li:first a").attr("id","current"); // Activate first tab
        $(".contenttab > div:first").fadeIn(); // Show first tab content
        
        $("#tabs a").on("click",function(e) {
            e.preventDefault();
            if ($(this).attr("id") == "current"){ //detection for current tab
             return       
            }
            else{             
            resetTabs();
            $(this).attr("id","current"); // Activate this
            $($(this).attr('name')).fadeIn(); // Show content for current tab
            }
        });

        for (i = 1; i <= $("#tabs li").length; i++) {
          if (myUrlTab == myUrlTabName + i) {
              resetTabs();
              $("a[name='"+myUrlTab+"']").attr("id","current"); // Activate url tab
              $(myUrlTab).fadeIn(); // Show url tab content        
          }
        }
    })()
	
</script>


</body>
</html>
