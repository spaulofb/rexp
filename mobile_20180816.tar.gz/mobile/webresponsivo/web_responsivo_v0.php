<!DOCTYPE html>
<html >
<head>
<meta charset="utf-8" >
<meta name="author" content="SPFB">
<title>Web Design Responsivo - HTML5 Semantico - Principale</title>
<link rel="stylesheet"  href="css/estilo_principal.css" type="text/css" >
<link rel="stylesheet"  href="fonts/fonts.css" type="text/css" >
</head>
<body>
<header id="topo" >
    <span id="logo" >
        <img src="img/logo_usp.png" alt="Sem Foto">
        <span class="titulo" >Faculdade de Medicina de Ribeir&atilde;o Preto</span>        
    </span>
    <section id="login-carrinho"  >
         <span  id="login" ><a href="#" title="Clicar" ><img src="img/login.png" alt="Sem figura" ></a></span>
         <span id="carrinho" ><a href="#" title="Clicar" ><img src="img/carrinho.png" alt="Sem figura" ></a></span>
         <span id="pesquisar" >
                <form  name="form1">
                    <a href="#search1" style="cursor: pointer;margin: auto 3px auto 3px;">
                       <img src="img/search-icon-2.png" alt="Sem figura"  >
                    </a>
                     <input type="search"  name="search1"  id="search1"  >
                </form>
         </span>
    </section>
</header>
    <section id="menu-container" >
       <nav id="menu" >
           <ul>
              <li><a href="#"  title="Clicar">WEB DESIGN</a></li>
              <li><a href="#"  title="Clicar">DESIGN GR&Aacute;FICO</a></li>
              <li><a href="#"  title="Clicar">&Aacute;UDIO E V&Iacute;DEO</a></li>
              <li><a href="#"  title="Clicar">PROGRAMA&Ccedil;&Atilde;O</a></li>
              <li><a href="#"  title="Clicar">3D</a></li>
              <li><a href="#"  title="Clicar">OFFICE</a></li>
              <li><a href="#"  title="Clicar">CURSOS ADOBE</a></li>
              <li><a href="#"  title="Clicar">FORMA&Ccedil;&Otilde;ES</a></li>                            
           </ul>
       </nav>
</section>

<section id="banner-container" >
    <div id="banner" >
         <img src="img/banner2.jpg" >
    </div>
</section>

<section id="corpo-container" >
 <div id="corpo">
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="img/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  </div>
</section>

<footer  id="rodape-container">
  <section id="rodape1" >
      <ul>
            <h1>ESTUDE CONOSCO</h1>
            <li><a href="#" title="Clicar">10 raz&otilde;es para estudar</a></li>
            <li><a href="#" title="Clicar">Como funciona</a></li>
            <li><a href="#" title="Clicar">Miss&atilde;o e valores</a></li>
      </ul>
      
            <ul>
            <h1>SOBRE</h1>
            <li><a href="#" title="Clicar">IAG, a hist&oacute;ria</a></li>
            <li><a href="#" title="Clicar">Pr&oacute;ximos Cursos</a></li>
            <li><a href="#" title="Clicar">Guia de Carreiras</a></li>
            <li><a href="#" title="Clicar">Bastidores</a></li>
            <li><a href="#" title="Clicar">V&iacute;deo Aulas Gratuitas</a></li>
            <li><a href="#" title="Clicar">Ag&ecirc;ncia originla IAG</a></li>
      </ul>

       <ul>
            <h1>NOSSOS PRODUTOS</h1>
            <li><a href="#" title="Clicar">Cursos Online</a></li>
            <li><a href="#" title="Clicar">Suporte</a></li>
            <li><a href="#" title="Clicar">DVDs/a></li>
            <li><a href="#" title="Clicar">Certificados</a></li>
            <li><a href="#" title="Clicar">Parcerias</a></li>
      </ul>

      <ul>
            <h1>SUPORTE IAG</h1>
            <li><a href="#" title="Clicar">FAQ</a></li>
            <li><a href="#" title="Clicar">Contato</a></li>
            <li><a href="#" title="Clicar">Atendimento Online/a></li>
            <li><a href="#" title="Clicar">Seja um Autor</a></li>
      </ul>

      <ul>
            <h1>MAIS <br />INFORMA&Ccedil;&Otilde;ES</h1>
            <li><a href="#" title="Clicar">Mapa do Site</a></li>
            <li><a href="#" title="Clicar">Termos e Condi&Ccedil;&otilde;es</a></li>
      </ul>

      <span  id="rodape-logo"><img src="img/rodape-logo_pequeno.png"  alt="Sem figura"></span>

      <a href="#" title="Clicar"  class="rodape-topo">IR AO TOPO</a>
      
  </section>

  <section  id="rodape2" >
    <div id="rodape2-facebook" >
          <ul>
                <h1>ACOMPANHE <br />NO FACEBOOK</h1>
                <span class="like" >
                     <div class="arrow_box" ></div>
                     <strong>618</strong>&nbsp;CURTIRAM
                </span>
                <li><a href="#" title="Clicar"><img src="img/facebook-box_new.png"  alt="Sem figura"></a></li>
          </ul>
    </div>
    <div id="rodape2-maisvisitados" >
      <div id="sidebar-plugin" >
              <div class="tabs">
                  <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" >
                  <label for="tab-1" class="tab-label-1" >AREAS</label>  
                  <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" >
                  <label for="tab-2" class="tab-label-2" >MAIS VISTOS</label>  
                  <div class="clear" ></div>
                  <div class="content" >
                 <div id="content-1" >
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-1 -->
                 <div id="content-2" >
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-2 -->
             </div><!-- FINAL CLASS CONTENT -->
        </div>
       </div><!--  FIM SIDEBA-PLUGIN-TABS -->
    </div>  
  </section>
  
  <section  id="rodape3-container" >
      <div id="rodape3">
          <p>E-mail: gemac@servidor.br - TEL: (16) 1234-4321</p>
          <p>Todos os direitos reservados -2008- 2013 Cursos</p>
          <p>
             <img src="img/icon-facebook.png" alt="Sem figura" >
             <img src="img/icon-twitter.png" alt="Sem figura" >
             <img src="img/icon-youtube.png" alt="Sem figura" >
          </p>
      </div>
  </section>
 
</footer>

</body>
</html>
