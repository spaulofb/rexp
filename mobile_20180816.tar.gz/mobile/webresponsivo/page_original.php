<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Cursos IAG</title>
<link rel="stylesheet"  href="css/estilo_principal.css" type="text/css" > 
<link href="css/banner.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet"  href="fonts/fonts.css" type="text/css" >
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<script type="text/jscript" src="js/banner.js"></script>
</head>
<body>
<a name="inicio"></a>
<header id="topo" >
    <span id="logo" >
        <a href="web_responsivo.php" title="Clicar"><img src="imagens/logo_usp.png" alt="Sem Foto"></a>
        <span class="titulo" >Faculdade de Medicina de Ribeir&atilde;o Preto</span>        
    </span>
    <section id="login-carrinho"  >
         <span  id="login" ><a href="#" title="Clicar" ><img src="imagens/login.png" alt="Sem figura" ></a></span>
         <span id="carrinho" ><a href="#" title="Clicar" ><img src="imagens/carrinho.png" alt="Sem figura" ></a></span>
         <span id="pesquisar" >
                <form  name="form1">
                     <a href="#search1" title="Clicar" >
                          <img src="imagens/search-icon-2.png" alt="Sem figura" style="cursor: pointer;"  >
                     </a>
                     <input type="search"  name="search1"  id="search1"  >
                </form>
         </span>
    </section>
</header>

<section id="menu-container" >
       <nav id="menu" >
           <ul>
              <li><a href="categoria.php"  title="Clicar">WEB DESIGN</a></li>
              <li><a href="categoria.php"  title="Clicar">DESIGN GR&Aacute;FICO</a></li>
              <li><a href="categoria.php"  title="Clicar">&Aacute;UDIO E V&Iacute;DEO</a></li>
              <li><a href="categoria.php"  title="Clicar">PROGRAMA&Ccedil;&Atilde;O</a></li>
              <li><a href="categoria.php"  title="Clicar">3D</a></li>
              <li><a href="categoria.php"  title="Clicar">OFFICE</a></li>
              <li><a href="categoria.php"  title="Clicar">CURSOS ADOBE</a></li>
              <li><a href="categoria.php"  title="Clicar">FORMA&Ccedil;&Otilde;ES</a></li>                            
           </ul>
       </nav>
</section>
 
 <section id="page-container">
   <div id="page">
   		<div id="page-titulo">
       		 <h1>10 raz&otilde;es para estudar conosco</h1> 
       </div>
       
       <div id="page-conteudo">
       		<p>Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. </p>
            
       		<p>Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. </p>

       </div>
                
   </div>
 </section>
 
<footer id="rodape-container">

  <section id="rodape1" >
      <ul>
            <h1>ESTUDE CONOSCO</h1>
            <li><a href="page.php" title="Clicar">10 raz&otilde;es para estudar</a></li>
            <li><a href="page.php" title="Clicar">Como funciona</a></li>
            <li><a href="page.php" title="Clicar">Miss&atilde;o e valores</a></li>
      </ul>
      
            <ul>
            <h1>SOBRE</h1>
            <li><a href="#" title="Clicar">IAG, a hist&oacute;ria</a></li>
            <li><a href="#" title="Clicar">Pr&oacute;ximos Cursos</a></li>
            <li><a href="#" title="Clicar">Guia de Carreiras</a></li>
            <li><a href="#" title="Clicar">Bastidores</a></li>
            <li><a href="#" title="Clicar">V&iacute;deo Aulas Gratuitas</a></li>
            <li><a href="#" title="Clicar">Ag&ecirc;ncia originla IAG</a></li>
      </ul>

       <ul>
            <h1>NOSSOS PRODUTOS</h1>
            <li><a href="#" title="Clicar">Cursos Online</a></li>
            <li><a href="#" title="Clicar">Suporte</a></li>
            <li><a href="#" title="Clicar">DVDs/a></li>
            <li><a href="#" title="Clicar">Certificados</a></li>
            <li><a href="#" title="Clicar">Parcerias</a></li>
      </ul>

      <ul>
            <h1>SUPORTE IAG</h1>
            <li><a href="#" title="Clicar">FAQ</a></li>
            <li><a href="#" title="Clicar">Contato</a></li>
            <li><a href="#" title="Clicar">Atendimento Online/a></li>
            <li><a href="#" title="Clicar">Seja um Autor</a></li>
      </ul>

      <ul>
            <h1>MAIS <br />INFORMA&Ccedil;&Otilde;ES</h1>
            <li><a href="#" title="Clicar">Mapa do Site</a></li>
            <li><a href="#" title="Clicar">Termos e Condi&Ccedil;&otilde;es</a></li>
      </ul>

      <span  id="rodape-logo"><img src="imagens/rodape-logo_pequeno.png"  alt="Sem figura"></span>

      <a href="#inicio" title="Clicar"  class="rodape-topo">IR AO TOPO</a>
      
  </section>

    
    <section id="rodape2">
    
		<div id="rodape2-facebook">
         <ul>
        	<h1>ACOMPANHE <br />NO FACEBOOK</h1>
              <?php
                 include("ncurtiram.php");
              ?>
        </ul>

        </div>
        
        <div id="rodape2-maisvistos">
        
        		<div id="sidebar-plugin">
                
                    <div class="tabs">
                    
                    <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" />
                    <label for="tab-1" class="tab-label-1">&Aacute;REAS</label>
            
                    <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" />
                    <label for="tab-2" class="tab-label-2">MAIS VISTOS</label>
                
                    <div class="clear"></div>
                
                    <div class="content">
                    
                        <div id="content-1">
                        
                             <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            
                        </div><!-- CONTENT-1 -->
                        
                        <div id="content-2">
                            
                             <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>

                            
                        </div><!-- CONTENT-2 -->
                        
                    </div>
                        
                    </div><!-- FIM SIDEBAR-PLUGIN-TABS -->
            
            </div><!-- FIM SIDEBAR-PLUGIN --> 
        
        </div>	

    </section>
    
    <section id="rodape3-container">
    	<div id="rodape3">
        		<p>E-mail: atendimento@cursosiag.com.br TEL: (82) 3034-5153</p>
              <p>Todos os direitos reservados - 2008 - 2013 CursosIAG</p>
              <p>
              		<img src="imagens/icon-facebook.png">
                  <img src="imagens/icon-twitter.png">
                  <img src="imagens/icon-youtube.png">
              </p>
        </div>
    </section>


</footer>

<script type="text/jscript" src="js/rodape.js"></script>
</body>
</html>
