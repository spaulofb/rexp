<!DOCTYPE html>
<html >
<head>
<meta name="author" content="SPFB">
<meta charset="UTF-8">
<meta name="viewport" content="device-width, initial-scale=1, maximum-scale=1.5">
<title>Web Design Responsivo - HTML5 Semantico - Principale</title>
<!--  <link rel="stylesheet"  href="css/estilo_principal.css" type="text/css" >  -->
<link rel="stylesheet"  href="css/estilo_principal.css" type="text/css" > 
<link rel="stylesheet"  href="fonts/fonts.css" type="text/css" >
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<script>
// Indentifica o User Agent do navegador cliente

var ua = navigator.userAgent.toLowerCase();
var uMobile = '';

// === REDIRECIONAMENTO PARA iPhone, Windows Phone, Android, etc. ===
// Lista de substrings a procurar para ser identificado como mobile WAP

uMobile = '';
uMobile += 'iphone;ipod;windows phone;android;iemobile 8';

// Sapara os itens individualmente em um array

v_uMobile = uMobile.split(';');

// percorre todos os itens verificando se eh mobile

var boolMovel = false;

for (i=0;i<=v_uMobile.length;i++) {
    if (ua.indexOf(v_uMobile[i]) != -1)    {
        boolMovel = true;
    }
}



if (boolMovel == true) {
        location.href='http://www.adrianogianini.com.br/testeresponsivo/mobile';
}
/// 
</script>
</head>
<body>
<a name="inicio"></a>
<header id="topo" >
    <span id="logo" >
        <a href="web_responsivo.php" title="Clicar"><img src="imagens/logo_usp.png" alt="Sem Foto"></a>
        <span class="titulo" >Faculdade de Medicina de Ribeir&atilde;o Preto</span>        
    </span>
    <section id="login-carrinho"  >
         <span  id="login" ><a href="#" title="Clicar" ><img src="imagens/login.png" alt="Sem figura" ></a></span>
         <span id="carrinho" ><a href="#" title="Clicar" ><img src="imagens/carrinho.png" alt="Sem figura" ></a></span>
         <span id="pesquisar" >
                <form  name="form1">
                    <a href="#search1" style="cursor: pointer;margin: auto 3px auto 3px;">
                       <img src="imagens/search-icon-2.png" alt="Sem figura"  >
                    </a>
                     <input type="search"  name="search1"  id="search1"  >
                </form>
         </span>
    </section>
</header>

<section id="menu-container" >
       <nav id="menu" >
           <ul>
              <li><a href="#"  title="Clicar">WEB DESIGN</a></li>
              <li><a href="#"  title="Clicar">DESIGN GR&Aacute;FICO</a></li>
              <li><a href="#"  title="Clicar">&Aacute;UDIO E V&Iacute;DEO</a></li>
              <li><a href="#"  title="Clicar">PROGRAMA&Ccedil;&Atilde;O</a></li>
              <li><a href="#"  title="Clicar">3D</a></li>
              <li><a href="#"  title="Clicar">OFFICE</a></li>
              <li><a href="#"  title="Clicar">CURSOS ADOBE</a></li>
              <li><a href="#"  title="Clicar">FORMA&Ccedil;&Otilde;ES</a></li>                            
           </ul>
       </nav>
</section>
 
<div id="banner-principal" >
    <div id="callbacks_container" >
        <ul id="banners">
          <li>
            <a href="http://www.fmrp.usp.br" title="Clicar" style="cursor: pointer;" target="_blank" >
               <img src="imagens/banner_fmrp.png" alt="PROMO&Ccedil;&Atilde;O" >
             </a>
          </li>
          <li>
            <a href="http://www.fmrp.usp.br" title="Clicar" style="cursor: pointer;" target="_blank" >
                  <img src="imagens/banner2.jpg"  alt="LAN&Ccedil;AMENTO|CURSO DE ADOBE EDGE ANIMATE" >
              </a>
           </li>
          <li>
            <a href="http://www.rge.fmrp.usp.br" title="Clicar" style="cursor: pointer;" target="_blank" >
                  <img src="imagens/topo_rge_teste.png"  alt="DEPARTAMENTO DE GEN&Eacute;TICA/FMRP" >
              </a>
           </li>
        </ul>
    </div>
</div>  <!-- FIM BANNER-PRINCIPAL  -->

<section id="corpo-container" >
 <div id="corpo">
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura">
     <h2>R$ 120,00</h2>
     <h3><a href="#">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  </div>
</section>

<footer  id="rodape-container">
  <section id="rodape1" >
      <ul>
            <h1>ESTUDE CONOSCO</h1>
            <li><a href="page.php" title="Clicar">10 raz&otilde;es para estudar</a></li>
            <li><a href="page.php" title="Clicar">Como funciona</a></li>
            <li><a href="page.php" title="Clicar">Miss&atilde;o e valores</a></li>
      </ul>
      
            <ul>
            <h1>SOBRE</h1>
            <li><a href="#" title="Clicar">IAG, a hist&oacute;ria</a></li>
            <li><a href="#" title="Clicar">Pr&oacute;ximos Cursos</a></li>
            <li><a href="#" title="Clicar">Guia de Carreiras</a></li>
            <li><a href="#" title="Clicar">Bastidores</a></li>
            <li><a href="#" title="Clicar">V&iacute;deo Aulas Gratuitas</a></li>
            <li><a href="#" title="Clicar">Ag&ecirc;ncia originla IAG</a></li>
      </ul>

       <ul>
            <h1>NOSSOS PRODUTOS</h1>
            <li><a href="#" title="Clicar">Cursos Online</a></li>
            <li><a href="#" title="Clicar">Suporte</a></li>
            <li><a href="#" title="Clicar">DVDs/a></li>
            <li><a href="#" title="Clicar">Certificados</a></li>
            <li><a href="#" title="Clicar">Parcerias</a></li>
      </ul>

      <ul>
            <h1>SUPORTE IAG</h1>
            <li><a href="#" title="Clicar">FAQ</a></li>
            <li><a href="#" title="Clicar">Contato</a></li>
            <li><a href="#" title="Clicar">Atendimento Online/a></li>
            <li><a href="#" title="Clicar">Seja um Autor</a></li>
      </ul>

      <ul>
            <h1>MAIS <br />INFORMA&Ccedil;&Otilde;ES</h1>
            <li><a href="#" title="Clicar">Mapa do Site</a></li>
            <li><a href="#" title="Clicar">Termos e Condi&Ccedil;&otilde;es</a></li>
      </ul>

      <span  id="rodape-logo"><img src="imagens/rodape-logo_pequeno.png"  alt="Sem figura"></span>

      <a href="#inicio" title="Clicar"  class="rodape-topo">IR AO TOPO</a>
      
  </section>

  <section  id="rodape2" >
    <div id="rodape2-facebook" >
          <ul>
                <h1>ACOMPANHE <br />NO FACEBOOK</h1>
                <span class="like" >
                     <div class="arrow_box" ></div>
                     <strong>618</strong>&nbsp;CURTIRAM
                </span>
                <li><a href="#" title="Clicar"><img src="imagens/facebook-box_new.png"  alt="Sem figura"></a></li>
          </ul>
    </div>
    <div id="rodape2-maisvisitados" >
      <div id="sidebar-plugin" >
              <div class="tabs">
                  <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" >
                  <label for="tab-1" class="tab-label-1" >AREAS</label>  
                  <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" >
                  <label for="tab-2" class="tab-label-2" >MAIS VISTOS</label>  
                  <div class="clear" ></div>
                  <div class="content" >
                 <div id="content-1" >
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-1 -->
                 <div id="content-2" >
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-2 -->
             </div><!-- FINAL CLASS CONTENT -->
        </div>
       </div><!--  FIM SIDEBAR-PLUGIN-TABS -->
    </div>  
  </section>
  
  <section  id="rodape3-container" >
      <div id="rodape3">
          <p>E-mail: gemac@servidor.br - TEL: (16) 1234-4321</p>
          <p>Todos os direitos reservados -2008- 2013 Cursos</p>
          <p>
             <img src="imagens/icon-facebook.png" alt="Sem figura" >
             <img src="imagens/icon-twitter.png" alt="Sem figura" >
          </p>
      </div>
  </section>
 
</footer>

<script type="text/javascript">
$(function () {
    $('.box').each(function() {
        var content = $(this).find('.content-2'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

$(document).ready(function () {
$('a[href=#topo]').click(function () {
$('html, body').animate({ scrollTop: 0 }, 'slow');
        return false;
    }); 
});

$(function () {
    
    $("#banners").responsiveSlides({
        
        auto: true,
        pager: false,
        nav: true,
        speed: 800,
        namespace: "callbacks",
        
      });

});

$(function(){
var menuTop = $('#menu-container').offset().top;
$(window).scroll(function(){
    if($(window).scrollTop() > menuTop){
         $('#menu-container').css({position: 'fixed', top: '0px'});
    }else{
         $('#menu-container').css({position: 'static'});
    }
})
});

$(function () {
    $('.box-2').each(function() {
        var content = $(this).find('.content-tab-footer'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

</script>

</body>
</html>
