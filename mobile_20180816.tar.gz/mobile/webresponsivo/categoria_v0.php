<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Cursos IAG</title>
<link href="estilo.css" rel="stylesheet" type="text/css">
<link href="fonts/fonts.css" rel="stylesheet" type="text/css">
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
</head>

<body>
<a name="topo">
<header id="topo">

	<span id="logo">
    	<a href="index.php"><img src="imagens/logo-cursos-iag.png"></a>
    </span>
    
    <section id="login-carrinho">
    	 <span id="login"><a href="#"><img src="imagens/login-header.png"></a></span>
        <span id="carrinho"><a href="#"><img src="imagens/checkout-header.png"></a></span>
        <span id="pesquisar">
        	<form name="form1">
           	<input type="search" name="search1"> 
           </form>
        </span>
    </section>
    
</header>

<section id="menu-container">
	<nav id="menu">
    	<ul>
        	<li><a href="categoria.php">WEB DESIGN</a></li>
           <li><a href="categoria.php">DESIGN GRÁFICO</a></li>
           <li><a href="categoria.php">ÁUDIO E VÍDEO</a></li>
           <li><a href="categoria.php">PROGRAMAÇÃO</a></li>
           <li><a href="categoria.php">3D</a></li>
           <li><a href="categoria.php">OFFICE</a></li>
           <li><a href="categoria.php">CURSOS ADOBE</a></li>
           <li><a href="categoria.php">FORMAÇÕES</a></li>
        </ul>
    </nav>
</section> 
 
 <section id="page-container">
   <div id="page">
   
   		<div id="categoria-titulo">
       		<h1>CATEGORIA: WEB DESIGN</h1> 
       </div>
       
       <div id="categoria-conteudo">
       		
            <ul>
            
            	<li>
              		<a href="#"><img src="imagens/destacadaEDGEANIMATE1.jpg">
                  <span><strong>CURSO DE ADOBE EDGE ANIMATE</strong></span>
                  <p>com Adriano Gianini</p></a>
                  
                  <div id="preco-do-curso">
                  	<span>R$ 100,00</span>
                    	<br>
                      <small>EM ATÉ 3X SEM JUROS</small>
                  </div>
              </li>
              
              <li>
              		<a href="#"><img src="imagens/destacadaEDGEANIMATE1.jpg">
                  <span><strong>CURSO DE ADOBE EDGE ANIMATE</strong></span>
                  <p>com Adriano Gianini</p></a>
                  
                  <div id="preco-do-curso">
                  	<span>R$ 100,00</span>
                    	<br>
                      <small>EM ATÉ 3X SEM JUROS</small>
                  </div>
              </li>
              
            	<li>
              		<a href="#"><img src="imagens/destacadaEDGEANIMATE1.jpg">
                  <span><strong>CURSO DE ADOBE EDGE ANIMATE</strong></span>
                  <p>com Adriano Gianini</p></a>
                  
                  <div id="preco-do-curso">
                  	<span>R$ 100,00</span>
                    	<br>
                      <small>EM ATÉ 3X SEM JUROS</small>
                  </div>
              </li>
              
              <li>
              		<a href="#"><img src="imagens/destacadaEDGEANIMATE1.jpg">
                  <span><strong>CURSO DE ADOBE EDGE ANIMATE</strong></span>
                  <p>com Adriano Gianini</p></a>
                  
                  <div id="preco-do-curso">
                  	<span>R$ 100,00</span>
                    	<br>
                      <small>EM ATÉ 3X SEM JUROS</small>
                  </div>
              </li>              
              
            </ul>

       </div>
                
   </div>
 </section>
 
<footer id="rodape-container">

	<section id="rodape1">
    
    	<ul>
        	<h1>ESTUDE CONOSCO</h1>
           <li><a href="#">10 razões para estudar</a></li>
           <li><a href="#">Como funciona</a></li>
           <li><a href="#">Missão e Valores</a></li>
        </ul>
        
        <ul>
        	<h1>SOBRE <br />NÓS</h1>
           <li><a href="#">IAG, a história</a></li>
           <li><a href="#">Próximos Cursos</a></li>
           <li><a href="#">Guia de Carreiras</a></li>
           <li><a href="#">Bastidores</a></li>
           <li><a href="#">Vídeo Aulas Gratuitas</a></li>
           <li><a href="#">Agência Digital IAG</a></li>
           
        </ul>
        
        <ul>
        	<h1>NOSSOS PRODUTOS</h1>
           <li><a href="#">Cursos Online</a></li>
           <li><a href="#">Suporte</a></li>
           <li><a href="#">DVDs</a></li>
           <li><a href="#">Certificados</a></li>
           <li><a href="#">Parcerias</a></li>
        </ul>
        
        <ul>
        	<h1>SUPORTE <br />IAG</h1>
           <li><a href="#">FAQ</a></li>
           <li><a href="#">Contato</a></li>
           <li><a href="#">Atendimento Online</a></li>
           <li><a href="#">Seja um Autor</a></li>
        </ul>
        
         <ul>
        	<h1>MAIS <br />INFORMAÇÕES</h1>
           <li><a href="#">Mapa do Site</a></li>
           <li><a href="#">Termos e Condições</a></li>
        </ul>
        
        <span id="rodape-logo"><img src="imagens/footer-logo.png"></span>
        
        <a href="#topo" class="rodape-topo">IR AO TOPO</a>
                           
    </section>

    
    <section id="rodape2">
    
		<div id="rodape2-facebook">
         <ul>
        	<h1>ACOMPANHE <br />NO FACEBOOK</h1>
            
            <?php
 
				abstract class ShareNetWork{
					protected $url;
					protected $server;
			 
					public function setUrl($url){
						$this->url = $url;
					}
			 
					public function setServer($server){
						$this->server = $server;
					}
			 
					protected function accessServer($url){
						$ch = curl_init($url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						$result = curl_exec($ch);
						curl_close($ch);
						return $result;
					}
			 
					abstract protected function populate($obj);
			 
					abstract public function execute();
			 
				}
				
				class ShareFacebook extends ShareNetWork{
					private $shareCount;
					private $likeCount;
					private $clickCount;
			 
					public function __construct($url){
						$this->setUrl($url);
						$this->setServer('http://api.facebook.com/restserver.php?method=links.getStats&urls=%s');
					}
			 
					public function execute(){
						$url = sprintf($this->server, $this->url);
						$data = $this->accessServer($url);
						$obj  = simplexml_load_string($data);
						$this->populate($obj);
						return $this;
					}
			 
					protected function populate($obj){
						$this->shareCount = $obj->link_stat->share_count;
						$this->likeCount = $obj->link_stat->like_count;
						$this->clickCount = $obj->link_stat->click_count;
					}
			 
					public function getShareCount(){
						return $this->shareCount;
					}
			 
					public function getLikeCount(){
						return $this->likeCount;
					}
			 
					public function getClickCount(){
						return $this->clickCount;
					}
			 
				}
				
				 $facebook = new ShareFacebook('https://www.facebook.com/cursosiag');
   				 $facebook->execute();
				
			?>
            
            <span class="like"><div class="arrow_box"></div><strong><?php echo $facebook->getLikeCount();?></strong> CURTIRAM</span>
            
            <div id="fb-root"></div>
			<script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1&appId=291255711008650";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
            
            <div class="fb-like-box" data-href="https://www.facebook.com/cursosiag" data-width="365" data-show-faces="true" data-stream="false" data-show-border="true" data-header="true"></div>
        </ul>

        </div>
        
        <div id="rodape2-maisvistos">
        
        		<div id="sidebar-plugin">
                
                    <div class="tabs">
                    
                    <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" />
                    <label for="tab-1" class="tab-label-1">ÁREAS</label>
            
                    <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" />
                    <label for="tab-2" class="tab-label-2">MAIS VISTOS</label>
                
                    <div class="clear"></div>
                
                    <div class="content">
                    
                        <div id="content-1">
                        
                             <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            
                        </div><!-- CONTENT-1 -->
                        
                        <div id="content-2">
                            
                             <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>

                            
                        </div><!-- CONTENT-2 -->
                        
                    </div>
                        
                    </div><!-- FIM SIDEBAR-PLUGIN-TABS -->
            
            </div><!-- FIM SIDEBAR-PLUGIN --> 
        
        </div>	

    </section>
    
    <section id="rodape3-container">
    	<div id="rodape3">
        		<p>E-mail: atendimento@cursosiag.com.br TEL: (82) 3034-5153</p>
              <p>Todos os direitos reservados - 2008 - 2013 CursosIAG</p>
              <p>
              		<img src="imagens/icon-facebook.png">
                  <img src="imagens/icon-twitter.png">
                  <img src="imagens/icon-youtube.png">
              </p>
        </div>
    </section>


</footer>

<script type="text/javascript">
$(function () {
    $('.box').each(function() {
        var content = $(this).find('.content-2'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

$(document).ready(function () {
$('a[href=#topo]').click(function () {
$('html, body').animate({ scrollTop: 0 }, 'slow');
		return false;
	}); 
});

$(function () {
	
	$("#banners").responsiveSlides({
		
		auto: true,
        pager: false,
        nav: true,
        speed: 800,
        namespace: "callbacks",
        
      });

});

$(function(){
var menuTop = $('#menu-container').offset().top;
$(window).scroll(function(){
	if($(window).scrollTop() > menuTop){
		 $('#menu-container').css({position: 'fixed', top: '0px'});
	}else{
		 $('#menu-container').css({position: 'static'});
	}
})
});

$(function () {
    $('.box-2').each(function() {
        var content = $(this).find('.content-tab-footer'),
            tab     = $('> ul li', this);
        $('div', content).eq(0).show();
        tab.click(function () {
            tab.removeClass('active');
            $(this).addClass('active');
            $('div', content).hide().eq($(this).index()).fadeIn(500); 
        });
    });
});

</script>


</body>
</html>
