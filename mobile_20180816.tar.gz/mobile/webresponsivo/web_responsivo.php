<!DOCTYPE html>
<html  lang="pt-br" >
<head>
<meta name="author" content="SPFB">
<meta charset="UTF-8">
<meta name="viewport" content="device-width, initial-scale=1, maximum-scale=1.5">
<title>Web Design Responsivo - HTML5 Semantico - Principal</title>
<!--  <link rel="stylesheet"  href="css/estilo_principal.css" type="text/css" >  -->
<link rel="stylesheet"   href="css/estilo_principal_teste_em_desktop_somente.css" type="text/css"  >  
<!--  <link rel="stylesheet"   href="css/estilo_principal_tablet.css" type="text/css" >  -->
<!--  <link href="css/banner.css" rel="stylesheet" type="text/css" />  -->
<link rel="stylesheet"  href="fonts/fonts.css" type="text/css" >
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
<script type="text/jscript" src="js/banner.js"></script>
<script>
// Indentifica o User Agent do navegador cliente

var ua = navigator.userAgent.toLowerCase();
var uMobile = '';

// === REDIRECIONAMENTO PARA iPhone, Windows Phone, Android, etc. ===
// Lista de substrings a procurar para ser identificado como mobile WAP

uMobile = '';
uMobile += 'iphone;ipod;windows phone;android;iemobile 8';

// Sapara os itens individualmente em um array

v_uMobile = uMobile.split(';');

/// percorre todos os itens verificando se eh mobile
var boolMovel = false;
for (i=0;i<=v_uMobile.length;i++) {
    if (ua.indexOf(v_uMobile[i]) != -1)    {
        boolMovel = true;
    }
}
///  Caso for SmartPhone, celular etc...  Alterar rota
if( boolMovel==true ) {
      ////  location.href='http://www.adrianogianini.com.br/testeresponsivo/mobile';
        location.href='./mobile';
}
/// 
</script>
</head>
<body>
<a name="inicio" style="float: left;  margin: 0;padding: 0;" ></a>
<header id="topo" >
    <span id="logo" >
        <a href="web_responsivo.php" title="Clicar"><img src="imagens/logo_usp.png" alt="Sem Foto">
             <span class="titulo" >Faculdade de Medicina de Ribeir&atilde;o Preto</span> 
        </a>       
    </span>
    <section id="login-carrinho"  >   
         <span  id="login" ><a href="#" title="Clicar" ><img src="imagens/login.png" alt="Sem figura" ></a></span>
         <span id="carrinho" ><a href="#" title="Clicar" ><img src="imagens/carrinho.png" alt="Sem figura" ></a></span>
         <span id="pesquisar" >
              <form  name="form1">
                  <label for="search1" title="Clicar" >
                     <img src="imagens/search-icon-2.png" alt="Sem figura" style="cursor: pointer;">
                  </label>
                  <input type="search"  name="search1"  id="search1" >
              </form>
         </span>   
    </section>
</header>

<section id="menu-container" >
       <nav id="menu" >
           <ul>
              <li><a href="categoria.php"  title="Clicar">WEB DESIGN</a></li>
              <li><a href="categoria.php"  title="Clicar">DESIGN GR&Aacute;FICO</a></li>
              <li><a href="categoria.php"  title="Clicar">&Aacute;UDIO E V&Iacute;DEO</a></li>
              <li><a href="categoria.php"  title="Clicar">PROGRAMA&Ccedil;&Atilde;O</a></li>
              <li><a href="categoria.php"  title="Clicar">3D</a></li>
              <li><a href="categoria.php"  title="Clicar">OFFICE</a></li>
              <li><a href="categoria.php"  title="Clicar">CURSOS ADOBE</a></li>
              <li><a href="categoria.php"  title="Clicar">FORMA&Ccedil;&Otilde;ES</a></li>                            
           </ul>
       </nav>
</section>

<!-- INICIO  BANNER-PRINCIPAL  --> 
<div id="bannerok" class="bannerok">
    <div id="bannerok_img">
       <a href="http://www.fmrp.usp.br" title="Clicar" style="cursor: pointer;border:none;" target="_blank" > 
      <!--     <img src="imagens/banner_fmrp.jpg" width="960px" height="275px"  alt="Banner" >   -->
          <img src="imagens/banner_fmrp.jpg"  alt="Banner" >
          </a>     
    </div>
    
    <div id="botoesok">
            <a href="javascript:void(0);" id="banner_img_1" class="ahover" onclick="mudaImg('0');">1</a>
            <a href="javascript:void(0);" id="banner_img_2" onclick="mudaImg('1');">2</a>
            <a href="javascript:void(0);" id="banner_img_3" onclick="mudaImg('2');">3</a>
    </div>
</div>
<!-- FIM BANNER-PRINCIPAL  -->

<div id="banner-principal">    
    <div class="callbacks_container">   
        <ul id="banners">
               
          <li>             
            <img src="imagens/banner.jpg" alt="PROMO��O">
                      
          </li>         
          <li>            
            <a href="#">           
                <img src="imagens/banner2.jpg" alt="LAN�AMENTO | CURSO DE ADOBE EDGE ANIMATE">              
            </a>            
          </li>         
          <li>            
            <a href="#">           
                <img src="imagens/banner_rge.jpg" alt="RGE">              
            </a>            
          </li>         
        </ul>    
    </div>    
</div>
<!-- FIM BANNER-PRINCIPAL -->


<section id="corpo-container" >
 <div id="corpo">
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>
  <article id="loop-corpo">
     <a href="single.php"><img src="imagens/destacadaPREMIERECS.jpg" alt="Sem figura"></a>
     <h1>CURSO DE PREMIERE PRO CS6</h1>
     <h2>R$ 120,00</h2>
     <span>EM AT� 3X SEM JUROS</span>
     <h3><a href="single.php">+INFORMA&Ccedil;&Otilde;ES</a></h3>
  </article>

  </div>
</section>

<footer  id="rodape-container">
  <section id="rodape1" >
      <ul>
            <h1>ESTUDE CONOSCO</h1>
            <li><a href="page.php" title="Clicar">10 raz&otilde;es para estudar</a></li>
            <li><a href="page.php" title="Clicar">Como funciona</a></li>
            <li><a href="page.php" title="Clicar">Miss&atilde;o e valores</a></li>
      </ul>
      
            <ul>
            <h1>SOBRE</h1>
            <li><a href="#" title="Clicar">IAG, a hist&oacute;ria</a></li>
            <li><a href="#" title="Clicar">Pr&oacute;ximos Cursos</a></li>
            <li><a href="#" title="Clicar">Guia de Carreiras</a></li>
            <li><a href="#" title="Clicar">Bastidores</a></li>
            <li><a href="#" title="Clicar">V&iacute;deo Aulas Gratuitas</a></li>
            <li><a href="#" title="Clicar">Ag&ecirc;ncia originla IAG</a></li>
      </ul>

       <ul>
            <h1>NOSSOS PRODUTOS</h1>
            <li><a href="#" title="Clicar">Cursos Online</a></li>
            <li><a href="#" title="Clicar">Suporte</a></li>
            <li><a href="#" title="Clicar">DVDs</a></li>
            <li><a href="#" title="Clicar">Certificados</a></li>
            <li><a href="#" title="Clicar">Parcerias</a></li>
      </ul>

      <ul>
            <h1>SUPORTE IAG</h1>
            <li><a href="#" title="Clicar">FAQ</a></li>
            <li><a href="#" title="Clicar">Contato</a></li>
            <li><a href="#" title="Clicar">Atendimento Online</a></li>
            <li><a href="#" title="Clicar">Seja um Autor</a></li>
      </ul>

      <ul>
                <h1>MAIS <br />INFORMA&Ccedil;&Otilde;ES</h1>
                <li><a href="#" title="Clicar">Mapa do Site</a></li>
                <li><a href="#" title="Clicar">Termos e Condi&ccedil;&otilde;es</a></li>
                 <span  id="rodape-logo"  ><a href="http://www.usp.br" title="Clicar" style="cursor: pointer;border:none;" target="_blank" ><img  src="imagens/rodape-logo_pequeno.png"  alt="Sem figura"></a></span>
      </ul>
  </section>

  <section  id="rodape2" >
    <div id="rodape2-facebook" >
          <ul>
                <h1>ACOMPANHE <br />NO FACEBOOK</h1>
              <?php
                 include("ncurtiram.php");
              ?>
          </ul>
    </div>
    <div id="rodape2-maisvisitados" >
      <div id="sidebar-plugin" >
              <div class="tabs">
                  <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" >
                  <label for="tab-1" class="tab-label-1" >&Aacute;REAS</label>  
                  <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" >
                  <label for="tab-2" class="tab-label-2" >MAIS VISTOS</label>  
                  <div class="clear" ></div>
                  <div class="content" >
                 <div id="content-1" >
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>WEB DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-1 -->
                 <div id="content-2" >
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                     <ul>
                          <h1>DESIGN</h1>
                          <li><a href="#" title="Clicar">Curso de Adobe Edge Animate</a></li>
                          <li><a href="#" title="Clicar">Curso de Premiere PRO CS6</a></li>
                      </ul>
                 </div><!-- CONTENT-2 -->
             </div><!-- FINAL CLASS CONTENT -->
        </div>
       </div><!--  FIM SIDEBAR-PLUGIN-TABS -->
    </div>  
  </section>
  
  <section  id="rodape3-container" >
      <div id="rodape3">
          <p>E-mail: gemac@servidor.br - TEL: (16) 1234-4321</p>
          <p>Todos os direitos reservados -2008- 2013 Cursos</p>
          <p>
             <img src="imagens/icon-facebook.png" alt="Sem figura" >
             <img src="imagens/icon-twitter.png" alt="Sem figura" >
          </p>
          <span  class="rodape-topo" ><a href="#inicio" title="Clicar" >TOPO</a></span>
      </div>
      
  </section>
 
</footer>

<script type="text/jscript" src="js/rodape.js"></script>
</body>
</html>
