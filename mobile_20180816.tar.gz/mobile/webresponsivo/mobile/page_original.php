<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="device-width, initial-scale=1, maximum-scale=1">
<title>Cursos IAG Mobile</title>
<link href="estiloMobile.css" rel="stylesheet" type="text/css">
<link href="fonts/fonts.css" rel="stylesheet" type="text/css">

<script src="vendor/jquery-1.9.1.js"></script>
<script src="vendor/json2.js"></script>
<script src="src/jquery.collapse.js"></script>
<script src="src/jquery.collapse_storage.js"></script>
<script src="src/jquery.collapse_cookie_storage.js"></script></head>

</head>

<body>

<header id="cabecalho">
	<a href="index.php"><img src="imagens/logo-cursos-iag-mobile.png"></a>
</header>

<nav id="menu-categorias-container">
	<div id="menu-categorias">
    	 <div id="demo" data-collapse="accordion persist">
          <h4><span><img src="imagens/menu-alt.png"></span>CATEGORIAS DE CURSOS</h4>
          <ul>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>WEB DESIGN</a></li>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>DESIGN GRÁFICO</a></li>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>PROGRAMAÇÃO</a></li>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>ÁUDIO E VÍDEO</a></li>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>FORMAÇÕES</a></li>
            <li><a href="categoria.php"><span><img src="imagens/globo-icon.png"></span>CURSOS ADOBE</a></li>            
          </ul>
        </div>
    </div>
</nav>

<section id="menu-compras-container">
	<div id="menu-compras">
    	<span class="icon-search"><img src="imagens/icon-search.png"></span>
       <span class="icon-login"><img src="imagens/icon-login.png"></span>
       <span class="icon-carrinho"><img src="imagens/icon-carrinho.png"></span>
    </div>
</section>

 <section id="page-container">
   <div id="page">
   
   		<div id="page-titulo">
       		<h1>10 razões para estudar conosco</h1> 
       </div>
       
       <div id="page-conteudo">
       		<p>Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. </p>
            
       		<p>Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. Aqui vem o texto que eu quiser. </p>

       </div>
                
   </div>
 </section>

<footer id="rodape-container">

	<section id="rodape1">
    
    	<ul>
        	<h1>ESTUDE CONOSCO</h1>
           <li><a href="page.php">10 razões para estudar</a></li>
           <li><a href="page.php">Como funciona</a></li>
           <li><a href="page.php">Missão e Valores</a></li>
        </ul>
        
        <ul>
        	<h1>SOBRE <br />NÓS</h1>
           <li><a href="page.php">IAG, a história</a></li>
           <li><a href="page.php">Próximos Cursos</a></li>
           <li><a href="page.php">Guia de Carreiras</a></li>
        </ul>
                                   
    </section>

    
    <section id="rodape2">
    
		<div id="rodape2-facebook">
         <ul>
        	<h1>ACOMPANHE <br />NO FACEBOOK</h1>
            
            <?php
 
				abstract class ShareNetWork{
					protected $url;
					protected $server;
			 
					public function setUrl($url){
						$this->url = $url;
					}
			 
					public function setServer($server){
						$this->server = $server;
					}
			 
					protected function accessServer($url){
						$ch = curl_init($url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						$result = curl_exec($ch);
						curl_close($ch);
						return $result;
					}
			 
					abstract protected function populate($obj);
			 
					abstract public function execute();
			 
				}
				
				class ShareFacebook extends ShareNetWork{
					private $shareCount;
					private $likeCount;
					private $clickCount;
			 
					public function __construct($url){
						$this->setUrl($url);
						$this->setServer('http://api.facebook.com/restserver.php?method=links.getStats&urls=%s');
					}
			 
					public function execute(){
						$url = sprintf($this->server, $this->url);
						$data = $this->accessServer($url);
						$obj  = simplexml_load_string($data);
						$this->populate($obj);
						return $this;
					}
			 
					protected function populate($obj){
						$this->shareCount = $obj->link_stat->share_count;
						$this->likeCount = $obj->link_stat->like_count;
						$this->clickCount = $obj->link_stat->click_count;
					}
			 
					public function getShareCount(){
						return $this->shareCount;
					}
			 
					public function getLikeCount(){
						return $this->likeCount;
					}
			 
					public function getClickCount(){
						return $this->clickCount;
					}
			 
				}
				
				 $facebook = new ShareFacebook('https://www.facebook.com/cursosiag');
   				 $facebook->execute();
				
			?>
            
            <span class="like"><div class="arrow_box"></div><strong><?php echo $facebook->getLikeCount();?></strong> CURTIRAM</span>
            
            <div id="fb-root"></div>
			<script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1&appId=291255711008650";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
            
            <div class="fb-like-box" data-href="https://www.facebook.com/cursosiag" data-width="320" data-show-faces="true" data-stream="false" data-show-border="true" data-header="true"></div>

        </ul>

        </div>
                
        </div>	

    </section>
    
    <section id="rodape3-container">
    	<div id="rodape3">
        		<p>E-mail: atendimento@cursosiag.com.br TEL: (82) 3034-5153</p>
              <p>Todos os direitos reservados - 2008 - 2013 CursosIAG</p>
              <p>
              		<img src="imagens/icon-facebook.png">
                  <img src="imagens/icon-twitter.png">
                  <img src="imagens/icon-youtube.png">
              </p>
        </div>
    </section>


</footer>

</body>
</html>