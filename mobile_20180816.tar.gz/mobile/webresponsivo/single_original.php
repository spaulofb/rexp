<!doctype html>
<html lang="pt-br" >
<head>
<meta charset="UTF-8">
<title>Cursos IAG</title>
<link href="estilo.css" rel="stylesheet" type="text/css">
<link href="fonts/fonts.css" rel="stylesheet" type="text/css">
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js?ver=1.9.1'></script>
<script src="js/responsiveslides.min.js" type="text/javascript"></script>
</head>

<body>
<a name="inicio"></a>
<header id="topo" >
    <span id="logo" >
        <a href="web_responsivo.php" title="Clicar"><img src="imagens/logo_usp.png" alt="Sem Foto"></a>
        <span class="titulo" >Faculdade de Medicina de Ribeir&atilde;o Preto</span>        
    </span>
    <section id="login-carrinho"  >
         <span  id="login" ><a href="#" title="Clicar" ><img src="imagens/login.png" alt="Sem figura" ></a></span>
         <span id="carrinho" ><a href="#" title="Clicar" ><img src="imagens/carrinho.png" alt="Sem figura" ></a></span>
         <span id="pesquisar" >
                <form  name="form1">
                     <a href="#search1" title="Clicar" >
                          <img src="imagens/search-icon-2.png" alt="Sem figura" style="cursor: pointer;"  >
                     </a>
                     <input type="search"  name="search1"  id="search1"  >
                </form>
         </span>
    </section>
</header>

<section id="menu-container" >
       <nav id="menu" >
           <ul>
              <li><a href="categoria.php"  title="Clicar">WEB DESIGN</a></li>
              <li><a href="categoria.php"  title="Clicar">DESIGN GR&Aacute;FICO</a></li>
              <li><a href="categoria.php"  title="Clicar">&Aacute;UDIO E V&Iacute;DEO</a></li>
              <li><a href="categoria.php"  title="Clicar">PROGRAMA&Ccedil;&Atilde;O</a></li>
              <li><a href="categoria.php"  title="Clicar">3D</a></li>
              <li><a href="categoria.php"  title="Clicar">OFFICE</a></li>
              <li><a href="categoria.php"  title="Clicar">CURSOS ADOBE</a></li>
              <li><a href="categoria.php"  title="Clicar">FORMA&Ccedil;&Otilde;ES</a></li>                            
           </ul>
       </nav>
</section>
 
<section id="single-container">
   <div id="single">
        <div id="single-header">
        	<h1>CURSO DE ADOBE EDGE ANIMATE</h1>
           <h2>Com Adriano Gianini</h2>
           
       <div id="single-header-prices">
        <span>R$ 100,00</span>
            <small>EM AT� 3X SEM JUROS</small>
       </div> 
	</div> 
        
    <div id="tabs-container">
    <ul id="tabs">
        <li><a href="#" name="#tab1">DESCRI��O</a></li>
        <li><a href="#" name="#tab2">INFORMA��ES</a></li>
        <li><a href="#" name="#tab3">P�BLICO ALVO</a></li>
        <li><a href="#" name="#tab4">PERFIL</a></li>
        <li><a href="#" name="#tab5">AULA DEMO</a></li>
    </ul>
    
    <div class="contenttab">
    <div id="tab1">
    
    O curso ensina como trabalhar com a nova ferramenta Adobe Edge Animate e a criar anima��es com jQuery e CSS3 sem a necessidade de ser um programador jQuery.
    
    Voc� aprender� a criar anima��es para divulga��o de produtos, menus, slideshows, sliders, galerias de fotos, sites responsivos entre v�rias outras situa��es.
    
    Al�m de criar tudo isso o resultado n�o � em FLASH o que torna toda anima��o criada compat�vel com desktops, smartphones e tablets.
    
    </div>
    <div id="tab2">
    
    Tempo de grava��o dos v�deos: 6 horas e 4 minutos
    
    Tempo de acesso: 2 anos
    
    Carga hor�ria certificado: 30 horas
    
    Certificado: Sim (PDF)
    
    Idioma do Software: Ingl�s
    
    Pr�-requisitos: � necess�rio possuir conhecimentos em inform�tica b�sica, internet, no��es de web design e muita vontade para aprender.
    
    Possui DVD? Sim. Enviado em at� 48 horas �teis ap�s a confirma��o de pagamento, exceto em promo��es onde n�o enviamos DVD.
    
    Possui acesso online as aulas? Sim, liberado em at� 24 horas (�teis)
    
    <a href="http://www.adrianogianini.com.br/site/wp-content/uploads/2013/01/conteudo_curso_edge_animate.pdf" target="_blank" data-ob="lightbox" class="pdf">Fa�a o download do conte�do em PDF</a>
    
    </div>
    <div id="tab3">
    
    Esse curso � perfeito para designers que desejam migrar suas anima��es do Flash para CSS3 e jQuery mas n�o desejam se tornar programadores nem tampouco ter como resultado um SWF.
    
    </div>
    <div id="tab4">
    
    Ap�s o curso o aluno estar� apto criar anima��es para divulga��o de produtos, menus, slideshows, sliders, galerias de fotos, sites responsivos entre v�rias outras situa��es.
    
    </div>
    <div id="tab5">
    <iframe height="487" width="100%" src="http://www.youtube.com/embed/6c6Y7jG_oq8" frameborder="0" allowfullscreen></iframe>
    </div>
    </div>
              
    </div>
    </div>
    
       
    <div id="botao-pagseguro">
        <img src="imagens/icon-shop.png">
        <div id="checkout">
            <img src="imagens/checkout.jpg">
        </div>
    </div>

 </section>

 
<footer id="rodape-container">
  <section id="rodape1" >
      <ul>
            <h1>ESTUDE CONOSCO</h1>
            <li><a href="page.php" title="Clicar">10 raz&otilde;es para estudar</a></li>
            <li><a href="page.php" title="Clicar">Como funciona</a></li>
            <li><a href="page.php" title="Clicar">Miss&atilde;o e valores</a></li>
      </ul>
      
            <ul>
            <h1>SOBRE</h1>
            <li><a href="#" title="Clicar">IAG, a hist&oacute;ria</a></li>
            <li><a href="#" title="Clicar">Pr&oacute;ximos Cursos</a></li>
            <li><a href="#" title="Clicar">Guia de Carreiras</a></li>
            <li><a href="#" title="Clicar">Bastidores</a></li>
            <li><a href="#" title="Clicar">V&iacute;deo Aulas Gratuitas</a></li>
            <li><a href="#" title="Clicar">Ag&ecirc;ncia originla IAG</a></li>
      </ul>

       <ul>
            <h1>NOSSOS PRODUTOS</h1>
            <li><a href="#" title="Clicar">Cursos Online</a></li>
            <li><a href="#" title="Clicar">Suporte</a></li>
            <li><a href="#" title="Clicar">DVDs/a></li>
            <li><a href="#" title="Clicar">Certificados</a></li>
            <li><a href="#" title="Clicar">Parcerias</a></li>
      </ul>

      <ul>
            <h1>SUPORTE IAG</h1>
            <li><a href="#" title="Clicar">FAQ</a></li>
            <li><a href="#" title="Clicar">Contato</a></li>
            <li><a href="#" title="Clicar">Atendimento Online/a></li>
            <li><a href="#" title="Clicar">Seja um Autor</a></li>
      </ul>

      <ul>
            <h1>MAIS <br />INFORMA&Ccedil;&Otilde;ES</h1>
            <li><a href="#" title="Clicar">Mapa do Site</a></li>
            <li><a href="#" title="Clicar">Termos e Condi&Ccedil;&otilde;es</a></li>
      </ul>

      <span  id="rodape-logo"><img src="imagens/rodape-logo_pequeno.png"  alt="Sem figura"></span>
      <a href="#inicio" title="Clicar"  class="rodape-topo">IR AO TOPO</a>
      
  </section>
    
    <section id="rodape2">
    
		<div id="rodape2-facebook">
         <ul>
              <h1>ACOMPANHE <br />NO FACEBOOK</h1>
              <?php
                 include("ncurtiram.php");
              ?>
        </ul>

        </div>
        
        <div id="rodape2-maisvistos">
        
        		<div id="sidebar-plugin">
                
                    <div class="tabs">
                    
                    <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked" />
                    <label for="tab-1" class="tab-label-1">&Aacute;REAS</label>
            
                    <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2" />
                    <label for="tab-2" class="tab-label-2">MAIS VISTOS</label>
                
                    <div class="clear"></div>
                
                    <div class="content">
                    
                        <div id="content-1">
                        
                             <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>WEB DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            
                        </div><!-- CONTENT-1 -->
                        
                        <div id="content-2">
                            
                             <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>
                            
                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>


                            <ul>
                               <h1>DESIGN</h1>
                               <li><a href="#">Curso de Adobe Edge Animate</a></li>
                               <li><a href="#">Curso de Premiere PRO CS6</a></li>
                            </ul>

                            
                        </div><!-- CONTENT-2 -->
                        
                    </div>
                        
                    </div><!-- FIM SIDEBAR-PLUGIN-TABS -->
            
            </div><!-- FIM SIDEBAR-PLUGIN --> 
        
        </div>	

    </section>
    
    <section id="rodape3-container">
    	<div id="rodape3">
        		<p>E-mail: atendimento@cursosiag.com.br TEL: (82) 3034-5153</p>
              <p>Todos os direitos reservados - 2008 - 2013 CursosIAG</p>
              <p>
              		<img src="imagens/icon-facebook.png">
                  <img src="imagens/icon-twitter.png">
                  <img src="imagens/icon-youtube.png">
              </p>
        </div>
    </section>


</footer>

<script type="text/jscript" src="js/rodape.js"></script>

<script>

    function resetTabs(){
        $(".contenttab > div").hide();  // Hide all content
        $("#tabs a").attr("id","");  // Reset id's      
    }

    var myUrl = window.location.href;  /// get URL
    var myUrlTab = myUrl.substring(myUrl.indexOf("#")); // For localhost/tabs.html#tab2, myUrlTab = #tab2     
    var myUrlTabName = myUrlTab.substring(0,4); // For the above example, myUrlTabName = #tab

    (function(){
        $(".contenttab > div").fadeOut();  // Initially hide all content
        $("#tabs li:first a").attr("id","current");  // Activate first tab
        $(".contenttab > div:first").fadeIn();  // Show first tab content
        
        $("#tabs a").on("click",function(e) {
            e.preventDefault();
            if ($(this).attr("id") == "current"){  /// detection for current tab
             return       
            }
            else{             
            resetTabs();
            $(this).attr("id","current"); // Activate this
            $($(this).attr('name')).fadeIn(); // Show content for current tab
            }
        });

        for (i = 1; i <= $("#tabs li").length; i++) {
            if( myUrlTab==myUrlTabName+i ) {
                 resetTabs();
                 $("a[name='"+myUrlTab+"']").attr("id","current"); // Activate url tab
                 $(myUrlTab).fadeIn(); // Show url tab content        
            }
        }
    })()
	
</script>


</body>
</html>
