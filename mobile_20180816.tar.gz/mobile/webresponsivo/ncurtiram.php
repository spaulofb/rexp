<?php
 
                abstract class ShareNetWork{
                    protected $url;
                    protected $server;
             
                    public function setUrl($url){
                        $this->url = $url;
                    }
             
                    public function setServer($server){
                        $this->server = $server;
                    }
             
                    protected function accessServer($url){
                        $ch = curl_init($url);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $result = curl_exec($ch);
                        curl_close($ch);
                        return $result;
                    }
             
                    abstract protected function populate($obj);
             
                    abstract public function execute();
             
                }
                
                class ShareFacebook extends ShareNetWork{
                    private $shareCount;
                    private $likeCount;
                    private $clickCount;
             
                    public function __construct($url){
                        $this->setUrl($url);
                        $this->setServer('http://api.facebook.com/restserver.php?method=links.getStats&urls=%s');
                    }
             
                    public function execute(){
                        $url = sprintf($this->server, $this->url);
                        $data = $this->accessServer($url);
                        $obj  = simplexml_load_string($data);
                        $this->populate($obj);
                        return $this;
                    }
             
                    protected function populate($obj){
                        $this->shareCount = $obj->link_stat->share_count;
                        $this->likeCount = $obj->link_stat->like_count;
                        $this->clickCount = $obj->link_stat->click_count;
                    }
             
                    public function getShareCount(){
                        return $this->shareCount;
                    }
             
                    public function getLikeCount(){
                        return $this->likeCount;
                    }
             
                    public function getClickCount(){
                        return $this->clickCount;
                    }
             
                }
                
                 $facebook = new ShareFacebook('https://www.facebook.com/cursosiag');
                    $facebook->execute();
                
            ?>
            
            <span class="like"><div class="arrow_box"></div><strong><?php echo $facebook->getLikeCount();?></strong> CURTIRAM</span>
            
            <div id="fb-root"></div>
            <script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1&appId=291255711008650";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>
            
            <div class="fb-like-box" data-href="https://www.facebook.com/cursosiag" data-width="365" data-show-faces="true" data-stream="false" data-show-border="true" data-header="true"></div>
